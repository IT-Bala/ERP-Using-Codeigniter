$(function() {
    // Side Bar Toggle
    $('.hide-sidebar').click(function() {
	  $('#sidebar').hide('fast', function() {
	  	$('#content').removeClass('span9');
	  	$('#content').addClass('span12');
	  	$('.hide-sidebar').hide();
	  	$('.show-sidebar').show();
	  });
	});

	$('.show-sidebar').click(function() {
		$('#content').removeClass('span12');
	   	$('#content').addClass('span9');
	   	$('.show-sidebar').hide();
	   	$('.hide-sidebar').show();
	  	$('#sidebar').show('fast');
	});
});

$(document).ready(function() { // Export Purpose
     // Add Button 
     $('#add-field').click(function() {  
      return !$('#left-fields option:selected').remove().appendTo('#right-fields');  
     }); 
	 // Remove button 
     $('#remove-field').click(function() {  
      return !$('#right-fields option:selected').remove().appendTo('#left-fields');  
     }); 
	 // Save Button
	 $('#save-fields').click(function(){
		 if($('#right-fields > option').length > 0){			 
			var keys = $("#right-fields > option").map(function() { 
						   return this.value; 
					   }).get().join(',');
			document.setCookie('fields_key', keys);
			$('#closePop').click();
			$("#filter_date_between").click();
		 }else{
			 alert("Please choose atleast one field!");
		 }
	 }); // END
	 $('#reset-cookie').click(function(){
		document.clearCookie('fields_key');
		$("#filter_date_between").click();
	 });
 });  
 
 // COOKIE PREDEFINED //
 
 document.getCookie = function(sName)
{
    sName = sName.toLowerCase();
    var oCrumbles = document.cookie.split(';');
    for(var i=0; i<oCrumbles.length;i++)
    {
        var oPair= oCrumbles[i].split('=');
        var sKey = decodeURIComponent(oPair[0].trim().toLowerCase());
        var sValue = oPair.length>1?oPair[1]:'';
        if(sKey == sName)
            return decodeURIComponent(sValue);
    }
    return '';
}
/*********************************************************
sets the value of a cookie
**********************************************************/
document.setCookie = function(sName,sValue)
{
    var oDate = new Date();
    oDate.setYear(oDate.getFullYear()+1);
    var sCookie = encodeURIComponent(sName) + '=' + encodeURIComponent(sValue) + ';expires=' + oDate.toGMTString() + ';path=/';
    document.cookie= sCookie;
}
/*********************************************************
removes the value of a cookie
**********************************************************/
document.clearCookie = function(sName)
{
    document.setCookie(sName,'');
}


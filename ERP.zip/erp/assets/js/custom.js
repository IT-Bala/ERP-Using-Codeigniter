/* Enquiry Add */
$(document).ready(function (e) {
		$("#form_enquiry").submit(function(e) {
				e.preventDefault();
				$.ajax({
				url: $(location).attr("href")+"/ajax_action", 
				type: "POST",             
				data: new FormData(this), 
				contentType: false,       
				cache: false,             
				processData:false,        
				success: function(data)   
				{
				//$('#loading').hide();
				$("#op_enquiry").html(data);
				}
				});
				
		});
		
});



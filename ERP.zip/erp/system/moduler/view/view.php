<div class="span10" id="content">
                    <!--<div class="row-fluid">
                        	<div class="navbar">
                            	<div class="navbar-inner">
	                                <ul class="breadcrumb">
	                                    <i class="icon-chevron-left hide-sidebar"><a href='#' title="Hide Sidebar" rel='tooltip'>&nbsp;</a></i>
	                                    <i class="icon-chevron-right show-sidebar" style="display:none;"><a href='#' title="Show Sidebar" rel='tooltip'>&nbsp;</a></i>
	                                    <li>
	                                        <a href="<?=$this->config->base_url()?>">Dashboard</a> <span class="divider">/</span>	
	                                    </li>
	                                    <li><a href="<?=$base_url?>"><?=ucfirst($module)?></a> <span class="divider">/</span></li>
                                        <li class="active">Update</li>
	                                </ul>
                            	</div>
                        	</div>
                    	</div>-->
                    
                    <div class="row-fluid">
                        <!-- block  javascript:history.back();-->
                        <div class="block">
                            <div class="navbar navbar-inner block-header">
                                <div class="muted pull-left"><a class="btn btn-default" href="<?=$base_url?>">Back</a></div>
                            </div>
                            <div class="block-content collapse in">
                                <div class="span12 pull-left">
                                <table class="table table-striped table-bordered">
                                     <?php 
										$sql = mysql_query("SELECT * FROM $fieldTable WHERE link_table='".$valueTable."' AND status=1");
										if(mysql_num_rows($sql)>0){
										$fetchVal = fetch_once("$valueTable","`$unique_id`=$edit_id");
										
										?>
                                        <?php 
										while($fetch = mysql_fetch_object($sql)){ $fieldVal = (string)$fetch->field;
										?>
                                        <tr>
                                        <td><?php echo $fetch->label;?></td>
                                        <td><?php echo $fetchVal->$fieldVal;?></td>
                                        </tr>
                                       <?php }}?>
                                 </table>
                                </div> 
                            </div>
                        </div>
                        
                        <!-- /block -->
                    </div>
                    
 </div>
 <?php 
$base_url = $this->config->base_url(); ?>
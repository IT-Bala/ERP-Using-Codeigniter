<?php # 
$msg ='';
if(isset($_POST['SaveControl'])){ extract($_POST);
    $type = (isset($type))?$type:'select';
    if($label!='' && $field!=''){ $column = strtolower(trim(mysql_real_escape_string($field)));
	
		mysql_query("SELECT `$column` FROM `$valueTable`") or $this->db->query("ALTER TABLE `$valueTable` ADD `$column` TEXT NOT NULL");
		
		$chain_table_field = (isset($chain_table_field))?$chain_table_field:'';
		$chain_table = (isset($chain_table))?$chain_table:'';
		$ajax_table = (isset($ajax_table))?$ajax_table:'';
		$ajax_field = (isset($ajax_field))?$ajax_field:'';
		$ajax_call_id = (isset($ajax_call_id))?$ajax_call_id:'';
		$ajax_type = (isset($ajax_type))?$ajax_type:'';
		$thisQue = $this->db->query("SELECT * FROM `$fieldTable` WHERE link_table='".$valueTable."' and field='".$column."'");
		if($thisQue->num_rows()==0){
		$this->db->query("INSERT INTO `$fieldTable` SET link_table='".mysql_real_escape_string($valueTable)."',label='".mysql_real_escape_string($label)."',field='".$column."',required='".$required."',show_on_table='".$show_on_table."',`field_column`='".$field_column."',`field_row`='".$field_row."',type='".$type."',chain_table='".$chain_table."',chain_table_field='".$chain_table_field."',
		ajax_table='".$ajax_table."',ajax_field='".$ajax_field."',ajax_call_id='".$ajax_call_id."',ajax_type='".$ajax_type."'
		
		");
		$field_id = $this->db->insert_id();
		
		if(isset($_POST['value']) && count($_POST['value'])!=0){
			 foreach($_POST['value'] as $value){
			  if($value!=''){
			  $this->db->query("INSERT INTO `$optionTable` SET field_id='".$field_id."',value='".mysql_real_escape_string($value)."'");
			  }
			 }
		 }$msg =  success("New field has been added successfully!");
	   }else{
		   $msg = error("Sorry this column already exist!");
	   }
	}
}
if(isset($_POST['UpdateControl'])){ extract($_POST);
    $type = (isset($type))?$type:'select';
	
	$chain_table_field = (isset($chain_table_field))?$chain_table_field:'';
	$chain_table = (isset($chain_table))?$chain_table:'';
	$ajax_table = (isset($ajax_table))?$ajax_table:'';
	$ajax_field = (isset($ajax_field))?$ajax_field:'';
	$ajax_call_id = (isset($ajax_call_id))?$ajax_call_id:'';
	$ajax_type = (isset($ajax_type))?$ajax_type:'';
	
	// ALTER TABLE  `tbl_students` CHANGE  `students`  `student` TEXT NOT NULL
		
	$this->db->query("UPDATE `$fieldTable` SET label='".mysql_real_escape_string($label)."',type='".$type."',required='".$required."',show_on_table='".$show_on_table."',`field_column`='".$field_column."',`field_row`='".$field_row."',chain_table='".$chain_table."',chain_table_field='".$chain_table_field."', ajax_table='".$ajax_table."',ajax_field='".$ajax_field."',ajax_call_id='".$ajax_call_id."',ajax_type='".$ajax_type."' WHERE field_id=".(int)$_POST['field_id']);
	$this->db->query("DELETE FROM `$optionTable` WHERE field_id=".$_POST['field_id']);
	if(isset($_POST['value']) && count($_POST['value'])!=0){
		 foreach($_POST['value'] as $value){
		  if($value!=''){
		  $this->db->query("INSERT INTO `$optionTable` SET field_id='".$field_id."',value='".mysql_real_escape_string($value)."'");
		  }
		 }
	 } $msg =  success("Field has been updated successfully!");
}
if(isset($_POST['delete_id'])){ 
  $fetch = fetch_once("$fieldTable","link_table='".$valueTable."' AND field_id=".$_POST['delete_id']);
  $this->db->query("ALTER TABLE $valueTable DROP `".$fetch->field."`");
  $this->db->query("DELETE FROM $optionTable WHERE field_id=".$_POST['delete_id']);
  $this->db->query("DELETE FROM $fieldTable WHERE field_id=".$_POST['delete_id']);
  $msg = success("Field has been deleted successfully!");
}
$sqll = $this->db->query("SELECT * FROM $fieldTable WHERE link_table='".$valueTable."'");
if($sqll->num_rows()==0){ 
	$this->db->query("TRUNCATE TABLE $valueTable");
}
if(isset($_POST['active_id'])){
  $this->db->query("UPDATE $fieldTable SET status=1 WHERE field_id=".$_POST['active_id']);
}
if(isset($_POST['inactive_id'])){
  $this->db->query("UPDATE $fieldTable SET status=0 WHERE field_id=".$_POST['inactive_id']);
}
$column = 1;
$moduleSql = $this->db->query("SELECT `column` FROM `tbl_modules` WHERE `table_name`='$valueTable'"); 
if($moduleSql->num_rows()>0){
	$fM = $moduleSql->row();
	$column = $fM->column;
}
$requiredArray = array('No','Yes');
$sotArray = array(1=>'Yes',0=>'No');
?>
<div class="span10" id="content">
                    <?=$msg?>
                    <div class="row-fluid">
                            <div class="navbar">
                               <div class="navbar-inner">
                                <div class="container-fluid">
                                    <div class="nav-collapse collapse">                                        
                                        <ul class="nav">
                                            <li>
                                                <a href="<?=$base_url?>setting"><?=$title;?></a>
                                            </li>
                                        </ul>
                                    </div>
                                    <!--/.nav-collapse -->
                                </div>
                            </div>
                          </div>
                    	</div>
                    <a class="btn btn-primary" data-toggle="modal" href="#myModal">Add New</a>
                    <a class="btn btn-primary" data-toggle="modal" href="#myDesign">Design Fields</a>
                    <div class="modal hide" id="myModal" style="display: none;" aria-hidden="true">
                        <div class="modal-header">
                            <button type="button" class="close" data-dismiss="modal">�</button>
                            <h3><?=$add_title?></h3>
                        </div>
                        <div class="modal-body">
                            <form class="form-horizontal" method="post" enctype="multipart/form-data">
                              <fieldset>
                                <div class="control-group">
                                  <label for="focusedInput" class="control-label">Lable Name</label>
                                  <div class="controls">
                                    <input type="text" required name="label" id="focusedInput" class="input-large focused">
                                  </div>
                                </div>
                                <div class="control-group">
                                  <label for="focusedInput" class="control-label">Field Name</label>
                                  <div class="controls">
                                    <input type="text" required name="field" id="focusedInput" class="input-large focused">
                                  </div>
                                </div>
                                <div class="control-group">
                                  <label for="focusedInput" class="control-label">Field Required</label>
                                  <div class="controls">
                                    <select name="required">
                                    <?php 
foreach($requiredArray as $key=>$value){ ?>
                                    <option value="<?=$key?>"><?=$value?></option>
                                    <?php 
}?>
                                    </select>
                                  </div>
                                </div>
                                <div class="control-group">
                                  <label for="focusedInput" class="control-label">Show On Table?</label>
                                  <div class="controls">
                                    <select name="show_on_table">
                                    <?php 
foreach($sotArray as $key=>$value){ ?>
                                    <option value="<?=$key?>"><?=$value?></option>
                                    <?php 
}?>
                                    </select>
                                  </div>
                                </div>
                                <!-- CHAIN -->
                                <div class="control-group">
                                  <label for="focusedInput" class="control-label">Chain Table</label>
                                  <div class="controls">
                                    <select name="chain_table" onchange="return getChainTableField('ChainTableField',this.value);">
                                    <option value="">Choose Chain Table</option>
                                    <?php 
 $tables = $this->db->list_tables();
									foreach($tables as $table){ ?>
                                    <option value="<?=$table?>"><?=$table?></option>
                                    <?php 
}?>
                                    </select>
                                  </div>
                                </div>
                                
                                <div class="control-group" id="ChainTableField" style="display:none;">
                                  <label for="focusedInput" class="control-label">Chain Table Field</label>
                                  <div class="controls"></div>
                                </div>
                                <!-- AJAX -->
                                <div class="control-group">
                                  <label for="focusedInput" class="control-label">Ajax Table</label>
                                  <div class="controls">
                                    <select name="ajax_table" onchange="return getAjaxTableField('AjaxTableField',this.value);">
                                    <option value="">Choose Ajax Table</option>
                                    <?php 
 $tables = $this->db->list_tables();
									foreach($tables as $table){ ?>
                                    <option value="<?=$table?>"><?=$table?></option>
                                    <?php 
}?>
                                    </select>
                                  </div>
                                </div>
                                <div class="control-group" id="AjaxTableField" style="display:none;">
                                  <label for="focusedInput" class="control-label">Ajax Table Field</label>
                                  <div class="controls"></div>
                                  <label for="focusedInputAjaxID" class="control-label">Ajax Call Div ID</label>
                                  <div class="form-control">
                                    &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<input type="text" name="ajax_call_id" id="focusedInputAjaxID" class="input-large focused">
                                  </div>
                                  <label class="control-label">Type</label>
                                  <div class="">
                                    &nbsp;&nbsp;&nbsp;&nbsp;
                                    <select name="ajax_type">
                                     <?php foreach(ajaxTypes() as $type){ ?>
                                     <option value="<?=$type?>" <?php if($fetch->ajax_type==$type){?>selected="selected"<?php 
}?>><?=$type?></option>
                                     <?php }?>
                                    </select>
                                  </div>
                                </div>
                                
                                
                                
                                
                                <div class="control-group">
                                  <label for="focusedInput" class="control-label">Field Type</label>
                                  <div class="controls">
                                    <select name="type" id="ChainTableFieldType" class="focused" onchange="return getControl(this.value);">
									<?php foreach(control_list() as $type){?>
                                    <option value="<?php echo $type;?>"><?php echo ucfirst($type);?></option>
                                    <?php }?>
                                    </select>
                                  </div>
                                </div>
                                
                                <div class="control-group">
                                  <label for="focusedI" class="control-label">Position/N(th) Column</label>
                                  <div class="controls">
                                    <select name="field_column" class="input-medium" id="focusedI">
									<?php for($i=1;$i<=$column;$i++){?>
                                    <option value="<?php echo $i;?>"><?php echo $i;?></option> 
                                    <?php }?>
                                    </select>
                                    <input type="text" name="field_row" class="input-small" placeholder="Row" />
                                  </div>
                                </div>
                                
                                <span id="showOP"></span>
                                <span id="plug-edit-append"></span>
                                <div class="control-group">
                                <button type="button" id="add-new-position" style="display:none;" class="btn btn-primary offset7">Add New</button>
                                </div>
                                <div class="control-group">
                                <button type="submit" class="btn btn-success offset7" name="SaveControl">Save</button>&nbsp;<button class="btn btn-danger">Cancel</button>
                                </div>
                              </fieldset>                              
                            </form>
                        </div>
                    </div>
                    <div id="plug-edit-append-row" style="display:none;">
                     <div class="wid-form control-group">               
                       <label id="parent-control-label" class="control-label"></label>
                       <div class="controls">                           
                       <input type="text" name="value[]" class="input-large focused" required="required" />
                       &nbsp;&nbsp;&nbsp;<i class="icon-trash tooltip-top" onclick="$(this).parent('.controls').parent('.wid-form').remove()" data-original-title="Remove"></i>
                       </div>
                     </div>
                    </div>
                    <div id="plug-edit-append-row1" style="display:none;">
                     <div class="wid-form control-group">               
                       <label id="parent-control-label1" class="control-label"></label>
                       <div class="controls">                           
                       <input type="text" name="value[]" class="input-large focused" required="required" />
                       &nbsp;&nbsp;&nbsp;<i class="icon-trash tooltip-top" onclick="$(this).parent('.controls').parent('.wid-form').remove()" data-original-title="Remove"></i>
                       </div>
                     </div>
                    </div>
                    <div class="row-fluid">
                        <!-- block -->
                        <div class="block">
                            <div class="navbar navbar-inner block-header">
                                <div class="muted pull-left"><?=ucwords($title)?></div>
                            </div>
                            <div class="block-content collapse in">
                                <div class="span12">
  									<table cellpadding="0" cellspacing="0" border="0" class="table table-striped table-bordered" id="example">
						              <thead>
						                <tr>
						                  <th>#</th>
						                  <th>Labels</th>
						                  <th>Fields</th>
                                          <th width="5%"><i class="icon-star"></i></th>
                                          <th width="15%">Satus</th>
						                  <th width="10%" style="text-align:center;">Action</th>
						                </tr>
						              </thead>
                                      <?php $sql = $this->db->query("SELECT * FROM $fieldTable WHERE link_table='".$valueTable."'"); 
									  if($sql->num_rows()>0){?>
						              <tbody>
                                      <?php $i=0; foreach($sql->result_object() as $fetch){ $i++; ?>
						                <tr>
						                  <td><?=$i?></td>
						                  <td><?php echo $fetch->label;?></td>
						                  <td><?php echo $fetch->field;?></td>
                                          <td><?php echo ($fetch->required==1)?'<i class="star">*</i>':'<i class="star_">*</i>';?></td>
                                          <td><?php echo ($fetch->status==1)?active():inactive();?></td>
						                  <td align="center" style="text-align:center;">
                                          <a data-toggle="modal" href="#myModal<?=$fetch->field_id?>"><i class="icon-edit tooltip-top" data-original-title="Edit"></i></a>&nbsp;&nbsp;
                                          <?php 
if($fetch->status==1){ ?>
                                          <i class="icon-refresh tooltip-top" onclick="return inactiveMe('<?=$fetch->field_id?>');" data-original-title="De-Activate"></i>&nbsp;&nbsp;
                                          <?php 
}else{?>
                                          <i class="icon-refresh tooltip-top" onclick="return activeMe('<?=$fetch->field_id?>');" data-original-title="Activate"></i>&nbsp;&nbsp;
                                          <?php 
}?>
                                          <i class="icon-trash tooltip-top" onclick="return deleteMe('<?=$fetch->field_id?>');" data-original-title="Trash"></i>
                                         <!--  EDIT POPUP  -->
                                        <div class="modal hide" id="myModal<?=$fetch->field_id?>" style="display: none;" aria-hidden="true">
                                            <div class="modal-header">
                                                <button type="button" class="close" data-dismiss="modal">�</button>
                                                <h3 align="left"><?=$edit_title?></h3>
                                            </div>
                                            <div class="modal-body">
                                                <form class="form-horizontal" id="editForm<?=$fetch->field_id?>" method="post" enctype="multipart/form-data">
                                                  <fieldset>
                                                    <div class="control-group">
                                                      <label for="focusedInput" class="control-label">Lable Name</label>
                                                      <div class="controls">
                                                        <input type="text" value="<?=$fetch->label;?>" name="label" id="focusedInput" class="input-large focused">
                                                      </div>
                                                    </div>
                                                    <div class="control-group">
                                                      <label for="focusedInput" class="control-label">Field Name</label>
                                                      <div class="controls">
                                                        <input type="text" readonly="readonly" value="<?=$fetch->field;?>" name="field" id="focusedInput" class="input-large focused">
                                                      </div>
                                                    </div>
                                                    <div class="control-group">
                                                      <label for="focusedInput" class="control-label">Field Required</label>
                                                      <div class="controls">
                                                        <select name="required">
                                                        <?php 
foreach($requiredArray as $key=>$value){ ?>
                                                        <option value="<?=$key?>" <?php 
if($fetch->required==$key){?>selected="selected"<?php 
}?>><?=$value?></option>
                                                        <?php 
}?>
                                                        </select>
                                                      </div>
                                                    </div>
                                                    <div class="control-group">
                                                      <label for="focusedInput" class="control-label">Show On Table?</label>
                                                      <div class="controls">
                                                        <select name="show_on_table">
                                                        <?php 
foreach($sotArray as $key=>$value){ ?>
                                                        <option value="<?=$key?>" <?php 
if($fetch->show_on_table==$key){?>selected="selected"<?php 
}?>><?=$value?></option>
                                                        <?php 
}?>
                                                        </select>
                                                      </div>
                                                    </div>
                                                    <div class="control-group">
                                                      <label for="focusedInput" class="control-label">Chain Table</label>
                                                      <div class="controls">
                                                        <select name="chain_table" onchange="return getChainTableField('ChainTableFieldEdit<?=$fetch->field_id?>',this.value);">
                                                        <option value="">Choose Chain Table</option>
                                                        <?php 
 $tables = $this->db->list_tables();
                                                        foreach($tables as $table){ ?>
                                                        <option value="<?=$table?>" <?php 
if($fetch->chain_table==$table){?>selected="selected"<?php 
}?>><?=$table?></option>
                                                        <?php 
}?>
                                                        </select>
                                                      </div>
                                                    </div>
                                                    
                                                    <?php 
													$displayIt = ($fetch->chain_table!='')?'display:block':'display:none'; 
													echo $disableIt = ($fetch->chain_table!='')?'disabled':'';
													
													$displayAjaxIt = ($fetch->ajax_table!='')?'display:block':'display:none'; 
													$disableAjaxIt = ($fetch->ajax_table!='')?'disabled':'';
													?>
                                                    <div class="control-group" id="ChainTableFieldEdit<?=$fetch->field_id?>" style="<?=$displayIt?>;">
                                                      <label for="focusedInput" class="control-label">Chain Table Field</label>
                                                      <div class="controls">
                                                      <?php if($fetch->chain_table!=''){ 
													  $fields = $this->db->list_fields($fetch->chain_table);
													  ?>
                                                        <select name="chain_table_field" class="form-control">
														<?php foreach($fields as $field){ ?>
                                                        <option value="<?=$field?>" <?php 
if($fetch->chain_table_field==$field){?>selected="selected"<?php 
}?>><?=$field?></option>
                                                        <?php }?>
                                                        </select>
                                                      <?php }?>
                                                      </div>
                                                    </div>
                                                    
                                                    <!-- AJAX -->
                                                    <div class="control-group">
                                                      <label for="focusedInput" class="control-label">Ajax Table</label>
                                                      <div class="controls">
                                                        <select name="ajax_table" onchange="return getAjaxTableField('AjaxTableFieldEdit<?=$fetch->field_id?>',this.value);">
                                                        <option value="">Choose Chain Table</option>
                                                        <?php 
 $tables = $this->db->list_tables();
                                                        foreach($tables as $table){ ?>
                                                        <option value="<?=$table?>" <?php 
if($fetch->ajax_table==$table){?>selected="selected"<?php 
}?>><?=$table?></option>
                                                        <?php 
}?>
                                                        </select>
                                                      </div>
                                                    </div>
                                                    
                                                    
                                                    <div class="control-group" id="AjaxTableFieldEdit<?=$fetch->field_id?>" style="<?=$displayAjaxIt?>;">
                                                      <label for="focusedInput" class="control-label">Ajax Table Field</label>
                                                      <div class="controls">
                                                      <?php if($fetch->ajax_table!=''){ 
													  $fields = $this->db->list_fields($fetch->ajax_table);
													  ?>
                                                        <select name="ajax_field" class="form-control">
														<?php foreach($fields as $field){ ?>
                                                        <option value="<?=$field?>" <?php 
if($fetch->ajax_field==$field){?>selected="selected"<?php 
}?>><?=$field?></option>
                                                        <?php }?>
                                                        </select>
                                                      <?php }?>
                                                      </div>
                                                      <label class="control-label">Ajax Call Div ID</label>
                                                      <div class="">
                                                        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<input type="text" name="ajax_call_id"  value="<?=$fetch->ajax_call_id?>" class="input-large focused">
                                                      </div>
                                                      <label class="control-label">Type</label>
                                                      <div class="">
                                                        &nbsp;&nbsp;&nbsp;&nbsp;
                                                        <select name="ajax_type">
                                                         <?php foreach(ajaxTypes() as $type){ ?>
                                                         <option value="<?=$type?>" <?php if($fetch->ajax_type==$type){?>selected="selected"<?php 
}?>><?=$type?></option>
                                                         <?php }?>
                                                        </select>
                                                      </div>
                                                    </div>
                                                    
                                                    <div class="control-group">
                                                      <label for="focusedInput" class="control-label">Field Type</label>
                                                      <div class="controls">
                                                        <select name="type" <?=$disableIt?> id="ChainTableFieldEdit<?=$fetch->field_id?>Type" class="input-large focused" onchange="return getControl1(this.value,'showOP<?=$fetch->field_id?>');">
                                                        <?php foreach(control_list() as $type){?>
                                                        <option value="<?php echo $type;?>" <?=($fetch->type==$type)?'selected="selected"':'';?>><?php echo ucfirst($type);?></option>
                                                        <?php }?>
                                                        </select>
                                                      </div>
                                                    </div>
                                                    
                                                    <div class="control-group">
                                                      <label for="focusedI" class="control-label">Position/N(th) Column</label>
                                                      <div class="controls">
                                                        <select name="field_column" class="input-medium">
                                                        <?php for($i=1;$i<=$column;$i++){?>
                                                        <option value="<?php echo $i;?>" <?=($fetch->field_column==$i)?'selected="selected"':'';?>><?php echo $i;?></option>
                                                        <?php }?>
                                                        </select>
                                                        <input type="text" name="field_row" class="input-small" value="<?=$fetch->field_row?>" placeholder="Row" />
                                                      </div>
                                                    </div>
                                                    
                                                    <span id="showOP<?=$fetch->field_id?>">
                                                    <?php 

                                                    $display='none;';
                                                    if($fetch->type=='radio' || $fetch->type=='checkbox' || $fetch->type=='select'){ 
                                                    $display='block';
                                                    $sqlF = $this->db->query("SELECT * FROM tbl_field_option WHERE field_id=".$fetch->field_id);
                                                    foreach($sqlF->result_object() as $fetchIt){
                                                    ?>
                                                    <div class="wid-form control-group">    
                                                       <div class="controls">
                                                       <?
                                                            echo ' <input type="text" class="input-large focused" name="value[]" value="'.$fetchIt->value.'">';
                                                       ?>
                                                      <i class="icon-trash tooltip-top" onclick="$(this).parent('.controls').parent('.wid-form').remove()" data-original-title="Remove"></i>
                                                       </div>
                                                     </div>
                                                     <?php 
}}?>
                                                    </span>
                                                    <span id="plug-edit-append<?=$fetch->field_id?>"></span>
                                                    
                                                    <div class="control-group">
                                                    <button type="button" id="ChainTableFieldEdit<?=$fetch->field_id?>addMore" <?=$disableIt?> onclick="appendHtml(<?=$fetch->field_id?>);" class="btn btn-primary offset7">Add New</button>
                                                    </div>
                                                    
                                                    <div class="control-group">
                                                    <input type="hidden" name="field_id" value="<?=$fetch->field_id?>" />
                                                    <input type="hidden" name="UpdateControl" id="UpdateControl" value="submit" />
                                                    <button type="submit" class="btn btn-success offset7" onclick="$('#editForm<?=$fetch->field_id?>').submit();">Save</button>&nbsp;<button class="btn btn-danger">Cancel</button>
                                                    </div>
                                                  </fieldset>                              
                                                </form>
                                            </div>
                                        </div>
                                        </td>
						                </tr>
                                        <?php }?>
						              </tbody>
                                      <?php }?>
						            </table>
                                </div>
                            </div>
                        </div>
                        <!-- /block -->
                    </div>
                    
                    <div class="modal hide" id="myDesign" style="display: none; min-width:80%; left:30%; top:2%;" aria-hidden="true">
                        <div class="modal-header">
                            <button type="button" class="close" data-dismiss="modal">�</button>
                            <h3>Fields Design</h3>
                        </div>
                        <div class="modal-body">
                        	 <div class="dhe-example-section" id="ex-2-1"> 
		
                                <div class="dhe-example-section-content">
                                    <div id="example-2-1">
                        
                                        <p><input type="submit" class="input-button" id="btn-get" value="Save Fields" /></p>
                                        <?php
                                        
                                        $mSSql = $this->db->query("SELECT `column` FROM `tbl_modules` WHERE `table_name`='$valueTable' ");
                                        $fetch = $mSSql->row();
                                        for($i=1;$i<=(int)$fetch->column;$i++){
                                        ?>
                                        <div class="column left <?php echo ($i==1)?'first':'';?>">
                                            <ul class="sortable-list" data-column="<?php echo $i;?>">
                                                <?php
                                                $mySql = $this->db->query("SELECT * FROM `$fieldTable` WHERE `link_table`='$valueTable' AND `field_column`=".$i." ORDER BY `sorting` ASC");                                                                          foreach($mySql->result_object() as $fet){                                                
                                                ?>
                                                <li class="sortable-item" id="<?=$fet->field_id?>"><?=$fet->field?></li>
                                                <?php }?>
                                            </ul>
                                        </div>
                                        <?php }?>
                                    </div>
                                    <div class="clearer">&nbsp;</div> 
                                </div>        
                            </div>
                             <div id="op">    	
                             </div>
                        </div>
                       </div>
                   </div>
                   
                    
 </div>

<?php
$field = array();
if(isset($_REQUEST['table']) && $_REQUEST['table']!=''){ extract($_REQUEST);
	$fields = $this->db->list_fields($table);
	$variable = (isset($_REQUEST['variable']))?$_REQUEST['variable']:'chain_table_field';
?>
<select name="<?=$variable?>" class="form-control">
<?php foreach($fields as $field){ ?>
<option value="<?=$field?>"><?=$field?></option>
<?php }?>
</select>
<?php }?>



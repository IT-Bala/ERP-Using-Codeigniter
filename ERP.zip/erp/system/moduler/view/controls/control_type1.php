<?php
if(isset($_REQUEST['type']) && $_REQUEST['type']!=''){ extract($_REQUEST);
	switch($type){
		case 'radio':
		echo '<div class="control-group"><label id="control-label1" class="control-label"><input type="radio"></label>
                       <div class="controls">                           
                       <input type="text" name="value[]" class="input-large focused" required="required" />
                       </div></div>';
		break;
		case 'checkbox':
		echo '<div class="control-group"><label id="control-label1" class="control-label"><input type="checkbox"></label>
                       <div class="controls">                           
                       <input type="text" name="value[]" class="input-large focused" required="required" />
                       </div></div>';
		break;
		case 'select':
		echo '<div class="control-group"><label id="control-label1" class="control-label"></label>
                       <div class="controls">                
					   <select class="input-large focused"><option>Choose values</option></select>       
                       </div></div>';
		break;
	}
}
?>



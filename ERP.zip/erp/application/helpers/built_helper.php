<?php
#                                                #
# PHP Dev__ framework [ Predefioned functions ]  #
#                                                #
function inc($file){
	if(!empty($file)){
	if(file_exists($file.'.php')){
	$path = pathinfo(__FILE__);
	$que = include(	$file.'.'.$path['extension']);
	}
	else{ $msg = ''; }
	}
	return true;
}
function limit($str,$limit){
	$len = strlen($str);
	if($len > $limit):
	$str =  substr($str,0,$limit)."...";
	else:
	$str =$str;
	endif;
	return $str;
}
function mrequire(){
	$files = func_get_args();
	if(count($files)!=0){
    foreach($files as $file)
        require_once($file);
	}
}
function minclude(){
	$files = func_get_args();
	if(count($files)!=0){
    foreach($files as $file)
        include_once($file);
	}
}
function copy_all($source, $dest){
    if(is_dir($source)) {
        $dir_handle=opendir($source);
        while($file=readdir($dir_handle)){
            if($file!="." && $file!=".."){
                if(is_dir($source."/".$file)){
                    if(!is_dir($dest."/".$file)){
                        mkdir($dest."/".$file);
                    }
                    copy_all($source."/".$file, $dest."/".$file);
                } else {
                    copy($source."/".$file, $dest."/".$file);
                }
            }
        }
        closedir($dir_handle);
    } else {
        copy($source, $dest);
    }
}
function clean($string) {
   $string = str_replace(' ', '-', $string); // Replaces all spaces with hyphens.
   return preg_replace('/[^A-Za-z0-9\-]/', ' ', $string); // Removes special chars.
} 
function check_friendly_url($string){ $checked_url='';
    $string = str_replace(' ', '-', $string); // Replaces all spaces with hyphens.
    $new = preg_replace('/[^A-Za-z0-9\-\.\_]/', '', $string); // Removes special chars.
	$sql = select(DB_PREFIX."posts where friendly_url='".$new."'");
	$sql_ = select(DB_PREFIX."pages where friendly_url='".$new."'");
	if((mysql_num_rows($sql)==0) && (mysql_num_rows($sql_)==0)){
	$checked_url = $new;
	}else{ $checked_url = 'page-'.rand(2,100).'-'.$new; }
	return $checked_url;
}
function front_page_access(){
	$front_page = array('page.php','DEV__.php');
	if(in_array(basename($_SERVER['REQUEST_URI']),$front_page)){
		echo '<p align="center">'.error("Sorry Access Denied!");exit;
	}
}
function incp($file){
	if(!empty($file)){
	$tpl_file = "templates/".$file.".phtml";
	if(file_exists($tpl_file)){
	$que = include(	$tpl_file );
	}else{ $msg = ''; }
	}
	return true;
}
function rrmdir($dir) {
    foreach(glob($dir . '/*') as $file) {
        if(is_dir($file))
            rrmdir($file);
        else
            unlink($file);
    }
    rmdir($dir);
}
function loop($value,$count){
	if($value!='' && $count!='' && $count>0){
		for($i=0;$i<$count;$i++){
			print $value;			
		}
	}
}
function unset_array(){$arg=func_get_args();
	if(count($arg)==2){ $value=$arg[0]; $array=$arg[1];
	if (($key = array_search($value, $array)) !== false) {
      unset($array[$key]);
     }
    }else{
		echo error("unset_array(value,array) should be pass 2 args!");
	}
}
function query($que){
	$que = mysql_query($que);
	return $que;
}
function insert($tbl,$submit){$msg='';
	if(!empty($submit) && !empty($tbl)){
	    $count = 0;
        $fields = '';
		foreach($_POST as $name=>$value){
			if($name!=$submit){
			  if ($count++ != 0) $fields .= ', ';
			  $name = mysql_real_escape_string($name);
			  $value = mysql_real_escape_string($value);
			  $fields .= "`$name` = '$value'";
			}
		} 
		if(isset($_FILES)){
			foreach($_FILES as $array){
				move_uploaded_file($array['tmp_name'],'../uploads/'.$array['name']);
			}
		} query("insert into $tbl set $fields");
	}else{	$msg = error("Invalid insert(tabel,submit) function must be 2 args!");	}
	echo $msg;		
}
function select($que){
	$que = mysql_query("select * from $que");
	return $que;
}
function where($tbl,$field){
	$que = mysql_query("select * from $tbl where $field");
	if($que==true){
	return $que;
	}
}
function truncate(){ $msg='';
	if(count($arg=func_get_args())==1){$tbl = $arg[0];
	query("truncate ".$tbl);
	}else{
		$msg = error("truncate ( ) has 1 arg [pass table name]");
	}
	echo $msg;
}
function currency($from, $to, $price){ $amount=1000;
$url = 'http://finance.yahoo.com/d/quotes.csv?e=.csv&f=sl1d1t1&s='. $from . $to .'=X';
$handle = @fopen($url, 'r');
if ($handle){
$result = fgets($handle, 4096);
fclose($handle);
}
$allData = explode(',',$result);
$dollarValue = $allData[1];
return $dollarValue*$price;
}
function ip_address($ip){
	if(!filter_var($ip, FILTER_VALIDATE_IP)){
		   throw new InvalidArgumentException("IP is not valid");
	}
	$response=@file_get_contents('http://www.netip.de/search?query='.$ip);
	if (empty($response)){
		   throw new InvalidArgumentException("Error Contacting IP-Server");
	}
	$patterns=array();
	$patterns["domain"] = '#Domain: (.*?)&nbsp;#i';
	$patterns["country"] = '#Country: (.*?)&nbsp;#i';
	$patterns["state"] = '#State/Region: (.*?)<br#i';
	$patterns["town"] = '#City: (.*?)<br#i';
	$ipInfo=array();
	foreach ($patterns as $key => $pattern){
		   $ipInfo[$key] = preg_match($pattern,$response,$value) && !empty($value[1]) ? $value[1] : 'Not found';
	}
	return $ipInfo;
}
function number_only(){
	$key = "this.value=this.value.replace(/[^\d-]/,'')";
	echo 'onkeyup="'.$key.'"';
}
function fetch_once(){
	$tbl = ''; $field = '';
	if(count($arg=func_get_args())==2){$tbl = $arg[0]; $field=$arg[1];
	$sql = where($tbl,$field);
	$msg = fetch($sql);
	}else{ $msg = error('fetch_once( ) function must be two values!');}
	return $msg;
}
function fetch_all(){
	$tbl = '';
	if(count($arg=func_get_args())==1){$tbl = $arg[0];
		$sql = select($tbl);
		while($_ = fetch($sql)){
			$_[] = $_;
		}
	}else{
		$_ = error('fetch_all( ) function must have table name !');
	}
	return $_;
}
function fetch($que){ $fet='';
	$fet = mysql_fetch_object($que);
	return $fet;
}
function view($fun){
	if(!empty($fun)){
	  echo $fun;
	}
}
function req($var){$req='';
	if(isset($_REQUEST[$var])&&!empty($_REQUEST[$var])){
		$req = $_REQUEST[$var];
	}
	echo $req;
}
function is_req($var){$r=false;
    $args = func_get_args();
    if(count($args)!=0){ $cnt =array();
		$count = count($args);
		foreach($args as $val){
			if(isset($_REQUEST[$val])&&!empty($_REQUEST[$val])){
			$cnt[]='true';
		   }
		}
		if($count==count($cnt)){
			$r=true;
		}
	}
	return $r;
}
function location(){ $location = error("location() must be 1 arg!");
    $args = func_get_args(); 
    if(count($args)!=0){
    $location=$args[0]; 
	if(!empty($location)){ 
	 echo '<script>document.location.href="'.$location.'"</script>';
	 $location='';
	}
	}
	return $location;
}
function php_location(){ $location = error("php_location() must be 1 arg!");
    $args = func_get_args(); 
    if(count($args)!=0){
    $location=$args[0];
	header("location:".$location);
	$location = '';
	}
	return $location;
}
function get_between($content,$start,$end){ $str='';
    $r = explode($start, $content);
    if (isset($r[1])){
        $r = explode($end, $r[1]);
        return $str = $r[0];
    }
    return $str;
}

function plug_replace($begin,$end,$str){
	foreach($end as $v) { $my[] = base64_decode($v); }
	echo str_replace($begin,$my,$str);
}

function get_inner($string, $start, $end){
    $string = " ".$string;
    $ini = strpos($string,$start);
    if ($ini == 0) return "";
    $ini += strlen($start);
    $len = strpos($string,$end,$ini) - $ini;
    return $a[] = substr($string,$ini,$len);
}

function plug_between($start, $end, $str){
    $matches = array();
	$regex = "/$start([a-zA-Z0-9_\=]*)$end/";
    preg_match_all($regex, $str, $matches);
    return $matches[1]; # $matches[0] : Means return @@str@@,  $matches[1]: Means return str
}
function plug_between_at($start, $end, $str){
    $matches = array();
	$regex = "/$start([a-zA-Z0-9_\=]*)$end/";
    preg_match_all($regex, $str, $matches);
    return $matches[0]; # $matches[0] : Means return @@str@@,  $matches[1]: Means return str
}
function check_plugin_structure($plug_base){$msg=''; # [PLUGIN:ISSA]
	         $plug = '../partition/plugins/'.$plug_base;
			 $plug_files = array('index.php','status.php','short_code.txt');
	         if(is_dir($plug)){
				 foreach(glob($plug.'*',GLOB_ONLYDIR) as $files_){
					 $files = basename($files_);
					 if(in_array($files,$plug_files)){ #PLUGIN RETURN TRUE
					   $msg = true;
					 }else{
						rrmdir($plug); # DELETE FILES
						$msg = error("Sorry plugin structure invalid!"); 
					 }
				 }
			 }
			 return $msg;
}
function check_theme_structure($theme_base){$msg='';  # [THEME:IPSA]
	         $theme = '../partition/themes/'.$theme_base;
			 $theme_files = array('index.php','page.php','sub_page.php');
	         if(is_dir($theme)){
				 foreach(glob($theme.'*',GLOB_ONLYDIR) as $files_){
					 $files = basename($files_);
					 if(in_array($files,$theme_files)){ #THEME RETURN TRUE
					   $msg = true;
					 }else{
						rrmdir($theme); # DELETE FILES
						$msg = error("Sorry theme structure invalid!"); 
					 }
				 }
			 }
			 return $msg;
}
function extension_status($var){ $ext = false;
	if(num(DB_PREFIX."extensions where extension='".$var."' and status=1")==1){
		$ext = true;
	}
	return $ext;
}
function fwrite_stream($fp, $string) {
    for ($written = 0; $written < strlen($string); $written += $fwrite) {
        $fwrite = fwrite($fp, substr($string, $written));
        if ($fwrite === false) {
            return $written;
        }
    }
    return $written;
}
function smtp_mail($a,$b,$c,$d){
	if($_SERVER['HTTP_HOST']=='localhost'){
	$send = error("Sorry mail() function does't work in localhost!");
	}else{
		$send = mail($a,$b,$c,$d);
	}
	return $send;
}
function security(){
 $secure = '<p>HOSTNAME: '.HOSTNAME;$secure .= '<p>USERNAME: '.USERNAME;$secure .= '<p>PASSWORD: '.PASSWORD;
 return $secure;
}
function language(){ $lan='';
	$lan = '
<div id="translate-this"><a style="width:180px;height:18px;display:block;" class="translate-this-button" href="http://www.translatecompany.com/">Translate Company</a></div>

<script type="text/javascript" src="http://x.translateth.is/translate-this.js"></script>
<script type="text/javascript">
TranslateThis();
</script>';
return $lan;
}
function checkbox(){ // 3 args ===> Name , Id , Value , Onclick
    $name=$id=$value=$onc='';
    $arg = func_get_args();
	if(count($arg)!=0){ 
	$id=$arg[0];
	if(count($arg)==2){$name='name="'.$arg[1].'"'; }
	if(count($arg)==3){$value='value="'.$arg[2].'"';}
	if(count($arg)==4){$onc='Onclick="'.$arg[3].'"';}
	
	$check = "<style>
	.ondisplay{ padding:0px;}
    .ondisplay section{
	  width:100px;
	  height:100px;
	  background: #555;
	  display:inline-block;
	  border: 1px solid gray;
	  text-align: center;
	  margin-top:5px;
	  border-radius:5px;
	  box-shadow: 0 1px 4px
		 rgba(0, 0, 0, 0.3), 0 0 40px
		 rgba(0, 0, 0, 0.1) inset;}
	.ondisplay section::before{
	  content:'click it'; 
	  color: #bbb;
		font: 15px Arial, sans-serif;
		-webkit-font-smoothing: antialiased;
		text-shadow: 0px 1px black;}
	input[type=checkbox] {	visibility: hidden;	}
	/* SQUARED THREE */
	.squaredThree {
		width: 20px;	
		margin: 10px auto;
		position: relative;
	}
	.squaredThree label {
		cursor: pointer;
		position: absolute;
		width: 20px;
		height: 20px;
		top: 0;
	  left: 0;
		border-radius: 4px;
		-webkit-box-shadow: inset 0px 1px 1px rgba(0,0,0,0.5), 0px 1px 0px rgba(255,255,255,.4);
		-moz-box-shadow: inset 0px 1px 1px rgba(0,0,0,0.5), 0px 1px 0px rgba(255,255,255,.4);
		box-shadow: inset 0px 1px 1px rgba(0,0,0,0.5), 0px 1px 0px rgba(255,255,255,.4);
	
		background: -webkit-linear-gradient(top, #222 0%, #45484d 100%);
		background: -moz-linear-gradient(top, #222 0%, #45484d 100%);
		background: -o-linear-gradient(top, #222 0%, #45484d 100%);
		background: -ms-linear-gradient(top, #222 0%, #45484d 100%);
		background: linear-gradient(top, #222 0%, #45484d 100%);
		filter: progid:DXImageTransform.Microsoft.gradient( startColorstr='#222', endColorstr='#45484d',GradientType=0 );
	}

.squaredThree label:after {
	-ms-filter: 'progid:DXImageTransform.Microsoft.Alpha(Opacity=0)';
	filter: alpha(opacity=0);
	opacity: 0;
	content: '';
	position: absolute;
	width: 9px;
	height: 5px;
	background: transparent;
	top: 4px;
	left: 4px;
	border: 3px solid #fcfff4;
	border-top: none;
	border-right: none;
	-webkit-transform: rotate(-45deg);
	-moz-transform: rotate(-45deg);
	-o-transform: rotate(-45deg);
	-ms-transform: rotate(-45deg);
	transform: rotate(-45deg);
}
.squaredThree label:hover::after {
	-ms-filter: 'progid:DXImageTransform.Microsoft.Alpha(Opacity=30)';
	filter: alpha(opacity=30);
	opacity: 0.3;
}
.squaredThree input[type=checkbox]:checked + label:after {
	-ms-filter: 'progid:DXImageTransform.Microsoft.Alpha(Opacity=100)';
	filter: alpha(opacity=100);
	opacity: 1;
}
	</style>";
	$check .= '<div class="ondisplay"><div class="squaredThree">
  	 <input type="checkbox" id="'.$id.'" '.$name.' '.$onc.' '.$value.' />
	 <label for="'.$id.'"></label>
    </div></div>';
	}else{
		$check = error("Function checkbox( ) must be atleast 1 arg , Ex: [ Id,Name,Value,Onclick ]");
	}
	return $check;
}
function checkall(){$form=''; // form name must be
	if(count(func_get_args())==1){$arg=func_get_args();
	$form= $arg[0];
	$check = "<script type='application/javascript'>
      checked = false;
      function checkall() {
        if (checked == false){checked = true}else{checked = false}
	for (var i = 0; i < document.getElementById('".$form."').elements.length; i++) {
	  document.getElementById('".$form."').elements[i].checked = checked;
	}
      }
    </script>";
	}else{
		$check = error("Function checkall( ) must be 1 arg, [I ==> FORM ID]");
	}
	return $check;
}
function autocomplete(){
	$arg = func_get_args();
    $search_value='';
	if(count($arg)==2){
	$array=$arg[0]; 
	$inputid=$arg[1];
	foreach($array as $a){
		$search_value .= "{ value: '".$a."', data: '".$a."' },";
	}
	$msg = '<!--<script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jquery/1.10.2/jquery.min.js"></script>--><script type="text/javascript" src="'.site_base().'/frame/autocomplete.js"></script>'."<script>
  $(function(){
  var currencies = [  
    ".$search_value."
  ];
  $('#".$inputid."').autocomplete({
    lookup: currencies,
    onSelect: function (suggestion) {
      var thehtml = '<strong>Name:</strong> ' + suggestion.value + ' <br> <strong>Symbol:</strong> ' + suggestion.data;
      $('#outputcontent').html(thehtml);
    }
  });
});
  </script><style>
  /*#".$inputid." {
  padding: 0 5px 0 5px;
  background-color: #fff;
  border: 1px solid #c8c8c8;
  border-radius: 3px;
  color: #aeaeae;
  font-weight:normal;
  font-size: 1.5em;
  -webkit-transition: all 0.2s linear;
  -moz-transition: all 0.2s linear;
  transition: all 0.2s linear;
  display: block; 
}*/
#".$inputid." {
  width:93% !important;
}
#".$inputid.":focus {
  color: #858585;
}
.flatbtn {
  -webkit-box-sizing: border-box;
  -moz-box-sizing: border-box;
  box-sizing: border-box;
  display: inline-block;
  outline: 0;
  border: 0;
  color: #f3faef;
  text-decoration: none;
  background-color: #6bb642;
  border-color: rgba(0, 0, 0, 0.1) rgba(0, 0, 0, 0.1) rgba(0, 0, 0, 0.25);
  font-weight: bold;
  line-height: normal;
  text-align: center;
  vertical-align: middle;
  cursor: pointer;
  text-transform: uppercase;
  text-shadow: 0 1px 0 rgba(0,0,0,0.3);
  -webkit-border-radius: 3px;
  -moz-border-radius: 3px;
  border-radius: 3px;
  -webkit-box-shadow: 0 1px 0 rgba(15, 15, 15, 0.3);
  -moz-box-shadow: 0 1px 0 rgba(15, 15, 15, 0.3);
  box-shadow: 0 1px 0 rgba(15, 15, 15, 0.3);
}
.flatbtn:hover {
  color: #fff;
  background-color: #73c437;
}
.flatbtn:active {
  -webkit-box-shadow: inset 0 1px 5px rgba(0, 0, 0, 0.1);
  -moz-box-shadow:inset 0 1px 5px rgba(0, 0, 0, 0.1);
  box-shadow:inset 0 1px 5px rgba(0, 0, 0, 0.1);
}
.autocomplete-suggestions { border: 1px solid #999; background: #fff; cursor: default; overflow: auto; }
.autocomplete-suggestion { padding: 5px 5px; font-size: 1.2em; white-space: nowrap; overflow: hidden; }
/*.autocomplete-selected { background: #f0f0f0; }*/
.autocomplete-suggestions strong { font-weight: normal; color: #3399ff; }</style>";
}else{
	$msg = error("<p>Function auto_complete must be 2 args [I=>array values, II=>input id]</p>");
}
  return $msg;
}
function site_base(){
	$base = basename(getcwd());
	if($_SERVER['HTTP_HOST']=='localhost'){
       $host = 'http://'.$_SERVER['HTTP_HOST'].'/'.$base; 
	}else{
	   $host = 'http://'.$_SERVER['HTTP_HOST'];
	} return $host;
}
function plugin_base(){
	return site_base().'/partition/plugins/';
}
function mail_server(){
	if($_SERVER['HTTP_HOST']=='localhost'){
		$msg = '<span class="error">Email not accessible in localhost !</span>';
	}else{
		$msg = true;
	}
	return $msg;
}
function check_extension_status($ext){ $status = '0';
	$status = num(DB_PREFIX."extensions where extension='".$ext."' and status=1");
	return $status;
}
function check_plugin_status($plugin){ $status = '0';
	$status = num(DB_PREFIX."plugins where plugin='".$plugin."' and status=1");
	return $status;
}
function insert_extension_data($data = array()){ # array ==> array('url_link'=>'file_path','url_link'=>'file_path')
	    $extension = '';
		foreach($data as $page=>$file){
		   $ext = explode('/',$file);
			if(is_array($ext)){
			$extension = $ext[0];
			}
		 if(num(DB_PREFIX."pages where extension_file='".$file."' and friendly_url='".$page."'")==0){
		  query("insert into ".DB_PREFIX."pages set friendly_url='".$page."',extension_file='".$file."',extension='".$extension."'");
		 }
		}
}
function insert_plugin_data($data = array()){ # array ==> array('url_link'=>'file_path','url_link'=>'file_path')
	    $extension = '';
		foreach($data as $page=>$file){
		   $ext = explode('/',$file);
			if(is_array($ext)){
			$extension = $ext[0];
			}
		 if(num(DB_PREFIX."pages where plugin_file='".$file."' and friendly_url='".$page."'")==0){
		  query("insert into ".DB_PREFIX."pages set friendly_url='".$page."',plugin_file='".$file."',plugin='".$extension."'");
		 }
		}
}
function getpage(){ global $plug; 
    $partition_base = 'partition/themes/'; 
    $ext_base = 'partition/extensions/';
	$plug_base= 'partition/plugins/';
    $page_url = basename($_SERVER['REQUEST_URI']);
	if(strpos($page_url,'?')==true){
			$exp = explode('?',$page_url); $page_url = $exp[0];
		}

	$sort = 'order by page_id desc limit 1';
	$sql_ex = select(DB_PREFIX."pages where friendly_url='".$page_url."' and extension_file!='' $sort"); # I st
	$ext = fetch($sql_ex);
	
	$sql_pl = select(DB_PREFIX."pages where friendly_url='".$page_url."' and plugin_file!='' $sort");# II nd
	$plug = fetch($sql_pl);
	
	$sql_tpl = select(DB_PREFIX."pages where friendly_url='".$page_url."' and tpl!='' and extension_file='' and plugin_file='' $sort");# III rd
	$tp = fetch($sql_tpl);
	if(mysql_num_rows($sql_ex)>0 && check_extension_status($ext->extension)=='1'){ 
	if($ext->extension_file!=''){  
		if(file_exists($ext_base.$ext->extension_file)){
			 ob_start();
			 require $ext_base.$ext->extension_file;
			 $tpl = ob_get_clean();
			}else{ $tpl = error($ext->extension_file." File not found !"); }
	}
	}
	elseif(mysql_num_rows($sql_pl)>0 && check_plugin_status($plug->plugin)=='1'){ 
	if($plug->plugin_file!=''){ 
		if(file_exists($plug_base.$plug->plugin_file)){
			 ob_start();
			 require $plug_base.$plug->plugin_file;
			 $tpl = ob_get_clean();
			}else{ $tpl = error($plug->plugin_file." File not found !"); }
	}}
	elseif(mysql_num_rows($sql_tpl)>0){
		if(file_exists($partition_base.THEME_BASE().'/templates/'.$tp->tpl)){
			 ob_start();
			 require $partition_base.THEME_BASE().'/templates/'.$tp->tpl;
			 $tpl = ob_get_clean();
			}else{ $tpl = error($tp->tpl." File not found !"); }
	}else{ 
	  $tpl = false;
	}
	return $tpl;
}
function getpost(){ global $plug; 
    $partition_base = 'partition/themes/'; 
	$ext_base = 'partition/extensions/';
	$plug_base= 'partition/plugins/';
    $page_url = basename($_SERVER['REQUEST_URI']);
	if(strpos($page_url,'?')==true){
			$exp = explode('?',$page_url); $page_url = $exp[0];
		}
	$sort = 'order by post_id desc limit 1';
	$sql_ex = select(DB_PREFIX."posts where friendly_url='".$page_url."' and extension_file!='' $sort"); # I st
	$ext = fetch($sql_ex);
	
	$sql_pl = select(DB_PREFIX."posts where friendly_url='".$page_url."' and plugin_file!='' $sort");# II nd
	$plug = fetch($sql_pl);
	
	$sql_tpl = select(DB_PREFIX."posts where friendly_url='".$page_url."' and tpl!='' and extension_file='' and plugin_file='' $sort");# III rd
	$tp = fetch($sql_tpl);
	if(mysql_num_rows($sql_ex)>0 && check_extension_status($ext->extension)=='1'){ 
	if($ext->extension_file!=''){  
		if(file_exists($ext_base.$ext->extension_file)){
			 ob_start();
			 require $ext_base.$ext->extension_file;
			 $tpl = ob_get_clean();
			}else{ $tpl = error($ext->extension_file." File not found !"); }
	}
	}
	elseif(mysql_num_rows($sql_pl)>0 && check_plugin_status($plug->plugin)=='1'){ 
	if($plug->plugin_file!=''){ 
		if(file_exists($plug_base.$plug->plugin_file)){
			 ob_start();
			 require $plug_base.$plug->plugin_file;
			 $tpl = ob_get_clean();
			}else{ $tpl = error($plug->plugin_file." File not found !"); }
	}}
	elseif(mysql_num_rows($sql_tpl)>0){
		if(file_exists($partition_base.THEME_BASE().'/templates/'.$tp->tpl)){ 
			 ob_start();
			 require $partition_base.THEME_BASE().'/templates/'.$tp->tpl;
			 $tpl = ob_get_clean();
			}else{ $tpl = error($tp->tpl." File not found !"); }
	}else{ 
	  $tpl = false;
	}
	return $tpl;
}
function gettpl(){
	$files = '';
	$tpl = '../partition/themes/'.THEME_BASE().'/templates/';
	if(is_dir($tpl)){
	foreach(glob($tpl.'*.php') as $file){
		$files[]=$file;
	}}
	return $files;
}
function check_page($page_id){
	$ur = $_SERVER['REQUEST_URI'];
    $pageurl = basename($ur);
	$que = mysql_query("select * from ".DB_PREFIX."pages where page_link='".$pageurl."'");
	$page = mysql_num_rows($que);
	if($page==1){ return true;	}
}
function home(){ $return = false;
	    $website_home = basename($_SERVER['REQUEST_URI']); 
		if(strpos($website_home,'?')===false){ 
		}else{ $exp = explode('?',$website_home); $website_home = $exp[0]; }
	    $home = basename(getcwd());
		$home_ = 'index.php';
		if($website_home==$home or $website_home==$home_ or $website_home==''){
				$return = true;	
		}
		return $return;
}
function theme_page(){ $page=true;
    if(home()==false){
		$page_url = basename($_SERVER['REQUEST_URI']);
		if(strpos($page_url,'?')==true){
			$exp = explode('?',$page_url); $page_url = $exp[0];
		}
		
		$sql = select(DB_PREFIX."posts where friendly_url='".$page_url."'");
		$sql_ = select(DB_PREFIX."pages where friendly_url='".$page_url."'");
		if((mysql_num_rows($sql)>0)){  
		   echo $page = getpost();
		}elseif(mysql_num_rows($sql_)>0){
		   echo $page = getpage();
		}/*else{		  
		     require_once 'frame/404.php';		   
		}*/
	}
	return $page;
}
function current_theme(){
	$current = '';
	$q = select(DB_PREFIX."themes where status=1");
	$count = num(DB_PREFIX."themes where status=1");
	if($count==1){
	$ft = fetch($q);	
	$current = THEME_PATH.$ft->theme.'/index.php';
	$data = file_get_contents($current);
	$regex = '/connect_theme()/'; // Find out the function in index page
	if (preg_match($regex, $data)) {
		$current = THEME_PATH.$ft->theme.'/index.php';
	} else {
		$current = 'frame/theme_error.php';
	}
	}
	return $current;
}
function current_theme_path(){
	$q = select(DB_PREFIX."themes where status=1");
	$count = num(DB_PREFIX."themes where status=1");
	if($count==1){
	$ft = fetch($q);
	return $current = THEME_PATH_PREFIX().$ft->theme.'/';
	}
}
function theme_empty(){
	if(admin_is_login()==true){ display_top_menu();} # User Panel Top Menu Is Admin Login #
	echo "<p style='padding:20px; border:1px #eee solid; box-shadow:1px 1px 6px #ccc; color:#F00; margin:auto; text-align:center;'>PLEASE INSTALL AND ACTIVATE THEME</p>";
}
function connect_plugin(){$Plug=$short=''; $dev_plugin='';
    $P_ARG = func_get_args();
	if(count($P_ARG)!=''){$short = $P_ARG[0];}
	if($short!=''){
	$PL = explode('/',INTER);
    $Plug_path = $inter = $PL[0].'/plugins/';
	if(is_dir($Plug_path)){
		foreach(glob($Plug_path.'*') as $file){
		$current = $file.'/short_code.txt';
		if(file_exists($current)){
			$data = file_get_contents($current);			
			if(num(DB_PREFIX."plugins where plugin='".basename($file)."' and status=1")==1){ 
			 if(strpos($data,$short)===false){ # Sorry short code is not found!
				
				 }else{  require($file.'/index.php'); }
			 }else{	/*PLUG INACTIVE*/}
		}else{ /* Plugin Struture Invalid*/ }
		}
	  }
	}
	return $dev_plugin;
}
function connect_module($module_name){ $msg='';
	       $md = explode('/',INTER);
		   $module_path = $inter = $md[0].'/modules/';
		   if(is_dir($module_path)){
			   foreach(glob($module_path.'*') as $file){
				$config = $file.'/config.xml';
				$index = $file.'/module.php';				
				if(file_exists($config)&&file_exists($index)){
					 $view = simplexml_load_file($config);
			         if($view->module->name==$module_name){
						 if($view->module->status=='true'){
							 if($view->module->name==$module_name){
								    require($index);
									$object = (string)$view->module->name;
                                    $msg = new $object;							 
							 }
						 }else{
						 echo error("Module status is false in '".$config."' file"); exit;
						 }
					 }else{
						 echo error("Sorry module class does not match in '".$config."' file"); exit;
					 }
				}else{
					echo error('Module Structure Invalid!'); exit;
				}
				}
		   }
		   return $msg;
}
function __secure__(){
	$_32 = '32';$_d = 'deva';
	$_m = 'mail';$_c = 'com';
	return $_32.$_d.'@g'.$_m.'.'.$_c;
	}
function THEME_PATH_PREFIX(){ return 'partition/themes/'; }

function THEME_BASE(){
	$THEME = '';
	$q = select(DB_PREFIX."themes where status=1");
	if(mysql_num_rows($q)>0){
    $ft = fetch($q);
    $THEME = $ft->theme;	
	}return $THEME;
}
function connect_theme(){
	define('THEME_BASE',THEME_BASE());
	function __autoload($theme){
	if(file_exists('partition/load/'.$theme.'.php')){
	  require 'partition/load/'.$theme.'.php';
	}}
	new dev__theme();
}
function smtp(){
	if(count(func_get_args())==4){ $fun=func_get_args();
	$smtp_to = $fun[0];
	$smtp_sub = $fun[1];
	$smtp_msg = $fun[2];
	$headers = "MIME-Version: 1.0" . "\r\n";
    $headers .= "Content-type:text/html;charset=iso-8859-1" . "\r\n";
    $headers .= 'From: <'.$fun[3].'>' . "\r\n";
    $headers .= 'Cc: '.$fun[3]. "\r\n";
	$mail_status = smtp_mail($smtp_to,$smtp_sub,$smtp_msg,$headers);
    }else{
	$mail_status = error("smtp() function should be 4 args! Example: [ From,To,Subject,Message ]");
	}
	return $mail_status;
}
function encode($code){	return base64_encode($code);}
function decode($code){	return base64_decode($code);}
function encrypt($text){
	define('SALT','plugins/');
        return trim(base64_encode(mcrypt_encrypt(MCRYPT_RIJNDAEL_256, SALT, $text, MCRYPT_MODE_ECB, mcrypt_create_iv(mcrypt_get_iv_size(MCRYPT_RIJNDAEL_256, MCRYPT_MODE_ECB), MCRYPT_RAND))));
    }
define('SALT','plugins/');
function decrypt($text){
        return trim(mcrypt_decrypt(MCRYPT_RIJNDAEL_256, SALT, base64_decode($text), MCRYPT_MODE_ECB, mcrypt_create_iv(mcrypt_get_iv_size(MCRYPT_RIJNDAEL_256, MCRYPT_MODE_ECB), MCRYPT_RAND)));
    }
function num($tbl){
	if($gg = mysql_query("select * from $tbl")){
	return mysql_num_rows($gg);
	}
}
function date_count($from,$to){
	$startTimeStamp = strtotime($from);
	$endTimeStamp = strtotime($to);
	$timeDiff = abs($endTimeStamp - $startTimeStamp);
	$numberDays = $timeDiff/86400; 
	return intval($numberDays);
}

/* backup the db OR just a table */
function backup_db($host,$user,$pass,$name,$tables = '*'){ // host, user, pass,dbname
     error_reporting(0);
	//get all of the tables
	if($tables == '*'){
		$tables = array();
		$result = mysql_query('SHOW TABLES');
		while($row = mysql_fetch_row($result))
		{
			$tables[] = $row[0];
		}
	}
	else
	{
		$tables = is_array($tables) ? $tables : explode(',',$tables);
	}
	
	//cycle through
	foreach($tables as $table)
	{
		$result = mysql_query('SELECT * FROM '.$table);
		$num_fields = mysql_num_fields($result);
		
		$return.= 'DROP TABLE '.$table.';';
		$row2 = mysql_fetch_row(mysql_query('SHOW CREATE TABLE '.$table));
		$return.= "\n\n".$row2[1].";\n\n";
		
		for ($i = 0; $i < $num_fields; $i++) 
		{
			while($row = mysql_fetch_row($result))
			{
				$return.= 'INSERT INTO '.$table.' VALUES(';
				for($j=0; $j<$num_fields; $j++) 
				{
					$row[$j] = addslashes($row[$j]);
					$row[$j] = ereg_replace("\n","\\n",$row[$j]);
					if (isset($row[$j])) { $return.= '"'.$row[$j].'"' ; } else { $return.= '""'; }
					if ($j<($num_fields-1)) { $return.= ','; }
				}
				$return.= ");\n";
			}
		}
		$return.="\n\n\n";
	}
	
	//save file
	$file_ = 'db-backup-'.time().'-'.(md5(implode(',',$tables))).'.sql';
	$handle = fopen('db/db-backup-'.time().'-'.(md5(implode(',',$tables))).'.sql','w+');
	fwrite($handle,$return);
	fclose($handle);
	download('db',$file_);	
}
function ajax_pagination(){ #
    $args = func_get_args(); $table=$limit=$func_name='';
	if(count($args)==3){ $table = $args[0];$limit = $args[1];$func_name = $args[2];
	echo '<script type="text/javascript">
$(document).ready(function(){
changePagination("0");    
});
function changePagination(pageId){
	 var tbl = "'.$table.'";
	 var lim = "'.$limit.'";
	 var func_name = "'.$func_name.'";
     $(".pageFlash").show();
     $(".pageFlash").fadeIn(400).html
                ("<img src='."'".site_base()."/frame/loading.gif'".' />");
     var dataString = "pageId="+ pageId +"&table="+tbl+"&limit="+lim+"&loop_design_func="+func_name;
     $.ajax({
           type: "POST",
           url: "'.site_base().'/frame/ajax_pagination_load.php",
           data: dataString,
           cache: false,
           success: function(result){
           $(".pageFlash").hide();
                 $("#pageData").html(result);
           }
      });
}
</script>
<style>
span.pageFlash{ bottom:300px; left:600px;position:absolute;}
div.pagination {padding: 3px;margin: 3px;}
div.pagination a {padding: 2px 5px 2px 5px;	margin: 2px;border: 1px solid #D7E5EF;text-decoration: none;color: #000099;}
div.pagination a:hover, div.pagination a:active {border: 1px solid #D7E5EF;color: #000;}
div.pagination span.current {padding: 2px 5px 2px 5px;margin: 2px;border: 1px solid #D7E5EF;font-weight: bold;background-color: #5B8FB5;color: #FFF;}
div.pagination span.disabled {padding: 2px 5px 2px 5px;margin: 2px;border: 1px solid #D7E5EF;color: #DDD;}	
</style><div id="pageData"></div><span class="pageFlash"></span>';
	}else{
		echo error('ajax_pagination($table,$limit,$loop_function) should be 3 args!');
	}
}
function pagination($tbl,$lim){
		echo "
		<style>
		div.pagination {
	padding: 3px;
	margin: 3px;
}

div.pagination a {
	padding: 2px 5px 2px 5px;
	margin: 2px;
	border: 1px solid #AAAADD;
	
	text-decoration: none; /* no underline */
	color: #000099;
}
div.pagination a:hover, div.pagination a:active {
	border: 1px solid #000099;

	color: #000;
}
div.pagination span.current {
	padding: 2px 5px 2px 5px;
	margin: 2px;
		border: 1px solid #000099;
		
		font-weight: bold;
		background-color: #000099;
		color: #FFF;
	}
	div.pagination span.disabled {
		padding: 2px 5px 2px 5px;
		margin: 2px;
		border: 1px solid #EEE;
	
		color: #DDD;
	}
	
		</style>
		";
		// edit deva		
		$que = mysql_query("select * from ".$tbl);
		$My = mysql_num_rows($que);
		if($My > $lim){
		$tbl_name=$tbl;	
		$adjacents = 3;
		$query = "SELECT COUNT(*) as num FROM $tbl_name";
		$total_pages = mysql_fetch_array(mysql_query($query));
		$total_pages = $total_pages['num'];
		
		/* Setup vars for query. */
		$urlBase = basename($_SERVER['REQUEST_URI']);
		if(strpos($urlBase,'?')===false){
			$targetpage = $urlBase;
		}else{
			$ex = explode('?',$urlBase);
			$targetpage = $ex[0];
		} 
		
		$limit = $lim; 
		if(!empty($_GET['page'])){							//how many items to show per page
		$page = $_GET['page'];
		}else{
			$page = 1;
		}
		if($page) 
			$start = ($page - 1) * $limit; 			//first item to display on this page
		else
			$start = 0;								//if no page var is given, set start to 0
		
		/* Get data. */
		$sql = "SELECT * FROM $tbl_name LIMIT $start, $limit";
		$result = mysql_query($sql);
		
		/* Setup page vars for display. */
		if ($page == 0) $page = 1;					//if no page var is given, default to 1.
		$prev = $page - 1;							//previous page is page - 1
		$next = $page + 1;							//next page is page + 1
		$lastpage = ceil($total_pages/$limit);		//lastpage is = total pages / items per page, rounded up.
		$lpm1 = $lastpage - 1;						//last page minus 1
		
		$pagination = "";
		if($lastpage > 1)
		{	
			$pagination .= "<div class=\"pagination\">";
			//previous button
			if ($page > 1) 
				$pagination.= "<a href=\"$targetpage?page=$prev\">Previous</a>";
			else
				$pagination.= "<span class=\"disabled\">Previous</span>";	
			
			//pages	
			if ($lastpage < 7 + ($adjacents * 2))	//not enough pages to bother breaking it up
			{	
				for ($counter = 1; $counter <= $lastpage; $counter++)
				{
					if ($counter == $page)
						$pagination.= "<span class=\"current\">$counter</span>";
					else
						$pagination.= "<a href=\"$targetpage?page=$counter\">$counter</a>";					
				}
			}
			elseif($lastpage > 5 + ($adjacents * 2))	//enough pages to hide some
			{
				//close to beginning; only hide later pages
				if($page < 1 + ($adjacents * 2))		
				{
					for ($counter = 1; $counter < 4 + ($adjacents * 2); $counter++)
					{
						if ($counter == $page)
							$pagination.= "<span class=\"current\">$counter</span>";
						else
							$pagination.= "<a href=\"$targetpage?page=$counter\">$counter</a>";					
					}
					$pagination.= "...";
					$pagination.= "<a href=\"$targetpage?page=$lpm1\">$lpm1</a>";
					$pagination.= "<a href=\"$targetpage?page=$lastpage\">$lastpage</a>";		
				}
				//in middle; hide some front and some back
				elseif($lastpage - ($adjacents * 2) > $page && $page > ($adjacents * 2))
				{
					$pagination.= "<a href=\"$targetpage?page=1\">1</a>";
					$pagination.= "<a href=\"$targetpage?page=2\">2</a>";
					$pagination.= "...";
					for ($counter = $page - $adjacents; $counter <= $page + $adjacents; $counter++)
					{
						if ($counter == $page)
							$pagination.= "<span class=\"current\">$counter</span>";
						else
							$pagination.= "<a href=\"$targetpage?page=$counter\">$counter</a>";					
					}
					$pagination.= "...";
					$pagination.= "<a href=\"$targetpage?page=$lpm1\">$lpm1</a>";
					$pagination.= "<a href=\"$targetpage?page=$lastpage\">$lastpage</a>";		
				}
				//close to end; only hide early pages
				else
				{
					$pagination.= "<a href=\"$targetpage?page=1\">1</a>";
					$pagination.= "<a href=\"$targetpage?page=2\">2</a>";
					$pagination.= "...";
					for ($counter = $lastpage - (2 + ($adjacents * 2)); $counter <= $lastpage; $counter++)
					{
						if ($counter == $page)
							$pagination.= "<span class=\"current\">$counter</span>";
						else
							$pagination.= "<a href=\"$targetpage?page=$counter\">$counter</a>";					
					}
				}
			}
			
			//next button
			if ($page < $counter - 1) 
				$pagination.= "<a href=\"$targetpage?page=$next\">Next</a>";
			else
				$pagination.= "<span class=\"disabled\">Next</span>";
			$pagination.= "</div>\n";
			$re_result = array($result,$pagination);		
		}
		}
		else
		{
			$re_result = array($que,"");
		}
		return $re_result;
	}

function sub_pagination($tbl,$lim,$var){
		echo "
		<style>
		div.pagination {
	padding: 3px;
	margin: 3px;
}

div.pagination a {
	padding: 2px 5px 2px 5px;
	margin: 2px;
	border: 1px solid #AAAADD;
	
	text-decoration: none; /* no underline */
	color: #000099;
}
div.pagination a:hover, div.pagination a:active {
	border: 1px solid #000099;

	color: #000;
}
div.pagination span.current {
	padding: 2px 5px 2px 5px;
	margin: 2px;
		border: 1px solid #000099;
		
		font-weight: bold;
		background-color: #000099;
		color: #FFF;
	}
	div.pagination span.disabled {
		padding: 2px 5px 2px 5px;
		margin: 2px;
		border: 1px solid #EEE;
	
		color: #DDD;
	}
	
		</style>
		";
		// edit deva		
		$que = mysql_query("select * from $tbl");
		$My = mysql_num_rows($que);
		if($My > $lim)
		{
		$tbl_name=$tbl;	
		$adjacents = 3;
		$query = "SELECT COUNT(*) as num FROM $tbl_name";
		$total_pages = mysql_fetch_array(mysql_query($query));
		$total_pages = $total_pages['num'];
		
		/* Setup vars for query. */
		#$targetpage = $_SERVER['PHP_SELF']."?$var"; 	//your file name  (the name of this file)
		
		$urlBase = basename($_SERVER['REQUEST_URI']);
		if(strpos($urlBase,'?')===false){
			$targetpage = $urlBase;
		}else{
			$ex = explode('?',$urlBase);
			$targetpage = $ex[0]."?$var";
		} 
		
		$limit = $lim; 
		if(!empty($_GET['page'])){							//how many items to show per page
		$page = $_GET['page'];
		}else{
			$page = 1;
		}
		if($page) 
			$start = ($page - 1) * $limit; 			//first item to display on this page
		else
			$start = 0;								//if no page var is given, set start to 0
		
		/* Get data. */
		$sql = "SELECT * FROM $tbl_name LIMIT $start, $limit";
		$result = mysql_query($sql);
		
		/* Setup page vars for display. */
		if ($page == 0) $page = 1;					//if no page var is given, default to 1.
		$prev = $page - 1;							//previous page is page - 1
		$next = $page + 1;							//next page is page + 1
		$lastpage = ceil($total_pages/$limit);		//lastpage is = total pages / items per page, rounded up.
		$lpm1 = $lastpage - 1;						//last page minus 1
		
		$pagination = "";
		if($lastpage > 1)
		{	
			$pagination .= "<div class=\"pagination\">";
			//previous button
			if ($page > 1) 
				$pagination.= "<a href=\"$targetpage&page=$prev\">Previous</a>";
			else
				$pagination.= "<span class=\"disabled\">Previous</span>";	
			
			//pages	
			if ($lastpage < 7 + ($adjacents * 2))	//not enough pages to bother breaking it up
			{	
				for ($counter = 1; $counter <= $lastpage; $counter++)
				{
					if ($counter == $page)
						$pagination.= "<span class=\"current\">$counter</span>";
					else
						$pagination.= "<a href=\"$targetpage&page=$counter\">$counter</a>";					
				}
			}
			elseif($lastpage > 5 + ($adjacents * 2))	//enough pages to hide some
			{
				//close to beginning; only hide later pages
				if($page < 1 + ($adjacents * 2))		
				{
					for ($counter = 1; $counter < 4 + ($adjacents * 2); $counter++)
					{
						if ($counter == $page)
							$pagination.= "<span class=\"current\">$counter</span>";
						else
							$pagination.= "<a href=\"$targetpage&page=$counter\">$counter</a>";					
					}
					$pagination.= "...";
					$pagination.= "<a href=\"$targetpage&page=$lpm1\">$lpm1</a>";
					$pagination.= "<a href=\"$targetpage&page=$lastpage\">$lastpage</a>";		
				}
				//in middle; hide some front and some back
				elseif($lastpage - ($adjacents * 2) > $page && $page > ($adjacents * 2))
				{
					$pagination.= "<a href=\"$targetpage&page=1\">1</a>";
					$pagination.= "<a href=\"$targetpage&page=2\">2</a>";
					$pagination.= "...";
					for ($counter = $page - $adjacents; $counter <= $page + $adjacents; $counter++)
					{
						if ($counter == $page)
							$pagination.= "<span class=\"current\">$counter</span>";
						else
							$pagination.= "<a href=\"$targetpage&page=$counter\">$counter</a>";					
					}
					$pagination.= "...";
					$pagination.= "<a href=\"$targetpage&page=$lpm1\">$lpm1</a>";
					$pagination.= "<a href=\"$targetpage&page=$lastpage\">$lastpage</a>";		
				}
				//close to end; only hide early pages
				else
				{
					$pagination.= "<a href=\"$targetpage&page=1\">1</a>";
					$pagination.= "<a href=\"$targetpage&page=2\">2</a>";
					$pagination.= "...";
					for ($counter = $lastpage - (2 + ($adjacents * 2)); $counter <= $lastpage; $counter++)
					{
						if ($counter == $page)
							$pagination.= "<span class=\"current\">$counter</span>";
						else
							$pagination.= "<a href=\"$targetpage&page=$counter\">$counter</a>";					
					}
				}
			}
			
			//next button
			if ($page < $counter - 1) 
				$pagination.= "<a href=\"$targetpage&page=$next\">Next</a>";
			else
				$pagination.= "<span class=\"disabled\">Next</span>";
			$pagination.= "</div>\n";
			$re_result = array($result,$pagination);		
		}
		}else{	$re_result = array($que,"");}
		return $re_result;
	}

function hash_pagination($tbl,$lim,$var){
		echo "<style>
		div.pagination {
	padding: 3px;
	margin: 3px;
}

div.pagination a {
	padding: 2px 5px 2px 5px;
	margin: 2px;
	border: 1px solid #AAAADD;
	
	text-decoration: none; /* no underline */
	color: #000099;
}
div.pagination a:hover, div.pagination a:active {
	border: 1px solid #000099;

	color: #000;
}
div.pagination span.current {
	padding: 2px 5px 2px 5px;
	margin: 2px;
		border: 1px solid #000099;
		
		font-weight: bold;
		background-color: #000099;
		color: #FFF;
	}
	div.pagination span.disabled {
		padding: 2px 5px 2px 5px;
		margin: 2px;
		border: 1px solid #EEE;
	
		color: #DDD;
	}</style>";
		// edit deva		
		$que = mysql_query("select * from $tbl");
		$My = mysql_num_rows($que);
		if($My > $lim)
		{
		$tbl_name=$tbl;	
		$adjacents = 3;
		$query = "SELECT COUNT(*) as num FROM $tbl_name";
		$total_pages = mysql_fetch_array(mysql_query($query));
		$total_pages = $total_pages['num'];
		
		/* Setup vars for query. */
		#$targetpage = $_SERVER['PHP_SELF']."?$var"; 	//your file name  (the name of this file)
		
		$urlBase = basename($_SERVER['REQUEST_URI']);
		/*if(strpos($urlBase,'?')===false){
			$targetpage = $urlBase;
		}else{*/
			$ex = explode('?',$urlBase);
			$targetpage = $ex[0]."$var";
		#} 
		
		$limit = $lim; 
		if(!empty($_GET['page'])){							//how many items to show per page
		$page = $_GET['page'];
		}else{
			$page = 1;
		}
		if($page) 
			$start = ($page - 1) * $limit; 			//first item to display on this page
		else
			$start = 0;								//if no page var is given, set start to 0
		
		/* Get data. */
		$sql = "SELECT * FROM $tbl_name LIMIT $start, $limit";
		$result = mysql_query($sql);
		
		/* Setup page vars for display. */
		if ($page == 0) $page = 1;					//if no page var is given, default to 1.
		$prev = $page - 1;							//previous page is page - 1
		$next = $page + 1;							//next page is page + 1
		$lastpage = ceil($total_pages/$limit);		//lastpage is = total pages / items per page, rounded up.
		$lpm1 = $lastpage - 1;						//last page minus 1
		
		$pagination = "";
		if($lastpage > 1)
		{	
			$pagination .= "<div class=\"pagination\">";
			//previous button
			if ($page > 1) 
				$pagination.= "<a href=\"?page=$prev&$targetpage\">Previous</a>";
			else
				$pagination.= "<span class=\"disabled\">Previous</span>";	
			
			//pages	
			if ($lastpage < 7 + ($adjacents * 2))	//not enough pages to bother breaking it up
			{	
				for ($counter = 1; $counter <= $lastpage; $counter++)
				{
					if ($counter == $page)
						$pagination.= "<span class=\"current\">$counter</span>";
					else
						$pagination.= "<a href=\"?page=$counter&$targetpage\">$counter</a>";					
				}
			}
			elseif($lastpage > 5 + ($adjacents * 2))	//enough pages to hide some
			{
				//close to beginning; only hide later pages
				if($page < 1 + ($adjacents * 2))		
				{
					for ($counter = 1; $counter < 4 + ($adjacents * 2); $counter++)
					{
						if ($counter == $page)
							$pagination.= "<span class=\"current\">$counter</span>";
						else
							$pagination.= "<a href=\"?page=$counter&$targetpage\">$counter</a>";					
					}
					$pagination.= "...";
					$pagination.= "<a href=\"?page=$lpm1&$targetpage\">$lpm1</a>";
					$pagination.= "<a href=\"?page=$lastpage&$targetpage\">$lastpage</a>";		
				}
				//in middle; hide some front and some back
				elseif($lastpage - ($adjacents * 2) > $page && $page > ($adjacents * 2))
				{
					$pagination.= "<a href=\"?page=1&$targetpage\">1</a>";
					$pagination.= "<a href=\"?page=2&$targetpage\">2</a>";
					$pagination.= "...";
					for ($counter = $page - $adjacents; $counter <= $page + $adjacents; $counter++)
					{
						if ($counter == $page)
							$pagination.= "<span class=\"current\">$counter</span>";
						else
							$pagination.= "<a href=\"?page=$counter&$targetpage\">$counter</a>";					
					}
					$pagination.= "...";
					$pagination.= "<a href=\"?page=$lpm1&$targetpage\">$lpm1</a>";
					$pagination.= "<a href=\"?page=$lastpage&$targetpage\">$lastpage</a>";		
				}
				//close to end; only hide early pages
				else
				{
					$pagination.= "<a href=\"?page=1&$targetpage\">1</a>";
					$pagination.= "<a href=\"?page=2&$targetpage\">2</a>";
					$pagination.= "...";
					for ($counter = $lastpage - (2 + ($adjacents * 2)); $counter <= $lastpage; $counter++)
					{
						if ($counter == $page)
							$pagination.= "<span class=\"current\">$counter</span>";
						else
							$pagination.= "<a href=\"?page=$counter&$targetpage\">$counter</a>";					
					}
				}
			}
			
			//next button
			if ($page < $counter - 1) 
				$pagination.= "<a href=\"?page=$next&$targetpage\">Next</a>";
			else
				$pagination.= "<span class=\"disabled\">Next</span>";
			$pagination.= "</div>\n";
			$re_result = array($result,$pagination);		
		}
		}else{	$re_result = array($que,"");}
		return $re_result;
	}

function css(){
	$fun = func_get_args();
	if(!empty($fun)){
	foreach($fun as $style){
	 //echo '@import url("'.BASE_URL.'/css/'.$style.'")';
	 echo '<link href="'.BASE_URL.'/css/'.$style.'" rel="stylesheet"><br>';
	}
	}
}
function url($id,$type){$link='#';
	if($type=='post'){
		if(num(DB_PREFIX."posts where post_id=".decode($id))==1){
		$p=fetch_once(DB_PREFIX."posts","post_id=".decode($id));
		$link = $p->friendly_url;
		if($link==''){ $link='page.php?p_id='.decode($id); }
		}
	}else{
		if(num(DB_PREFIX."pages where page_id=".decode($id))==1){
		$p=fetch_once(DB_PREFIX."pages","page_id=".decode($id));
		$link = $p->friendly_url;
		if($link==''){ $link='page.php?page_id='.decode($id); }
		}
	}	
	echo $link;
}
function rurl($id,$type){$link='';
	if($type=='post'){
		if(num(DB_PREFIX."posts where post_id=".decode($id))==1){
		$p=fetch_once(DB_PREFIX."posts","post_id=".decode($id));
		$link = $p->friendly_url;
		if($link==''){ $link='page.php?p_id='.decode($id); }
		}
	}else{
		if(num(DB_PREFIX."pages where page_id=".decode($id))==1){
		$p=fetch_once(DB_PREFIX."pages","page_id=".decode($id));
		$link = $p->friendly_url;
		if($link==''){ $link='page.php?page_id='.decode($id); }
		}
	}	
	return $link;
}
function startform(){
	$n = 'myform';
	$m = 'post';
	$val = func_get_args();  
	if(!empty($val)){ 
	if(count($val)==2){ $m = $val[1]; }
	$n = $val[0]; 
	 	$b = '<form name="'.$n.'" method="'.$m.'" enctype="multipart/form-data">';	}else{
		$b = '<form name="'.$n.'" method="'.$m.'" enctype="multipart/form-data">';
	}
	return $b;
}
function js(){
	$fun = func_get_args();
	if(!empty($fun)){
	foreach($fun as $js){
	echo '<script src="'.BASE_URL.'/js/'.$js.'"></script>';
	}
	}
}
function closeform(){
	return '</form>';
}
function back(){
	$val = func_get_args();
	if(!empty($val)){ $val=$val[0]; $b= '<input type="button" onclick="history.go(-1);" value="'.$val.'">';}else{
		$b= '<input type="button" onclick="history.go(-1);" value="Back">';
	}
	return $b;
}
function reset_(){
	$val = func_get_args(); 
	if(!empty($val)){ $val=$val[0];	$b = '<input type="reset" name="" value="'.$val.'">';	}else{
		$b = '<input type="reset" name="" value="Reset">';
	}
	return $b;
}
function button(){
	$oncl = '';
	$val = func_get_args();  
	if(!empty($val)){ 
	if(count($val)==2){	$oncl = $val[1]; }
	$val = $val[0]; 	
	$b = '<input type="button" name="button" value="'.$val.'" onclick="'.$oncl.'">';	
	}else{
	$b = '<input type="button" name="button" value="Button">';
	}
	return $b;
}
function text(){
	$oncl = '';
	$val = func_get_args();  
	if(!empty($val)){ 
	    if(count($val)==2){	$oncl = $val[1]; }
     	$val = $val[0];
		$b = '<input type="text" name="'.$val.'" value="'.$oncl.'">';	}else{
		$b = '<input type="text" name="text" value="">';
	}
	return $b;
}
function email(){
	$oncl = '';
	$val = func_get_args();  
	if(!empty($val)){ 
	    if(count($val)==2){	$oncl = $val[1]; }
     	$val = $val[0];
		$b = '<input type="email" name="'.$val.'" value="'.$oncl.'">';	}else{
		$b = '<input type="email" name="email" value="">';
	}
	return $b;
}
function hidden(){
	$oncl = '';
	$val = func_get_args();  
	if(!empty($val)){ 
	    if(count($val)==2){	$oncl = $val[1]; }
     	$val = $val[0];
		$b = '<input type="hidden" name="'.$val.'" value="'.$oncl.'">';	}else{
		$b = '<input type="hidden" name="hidden" value="">';
	}
	return $b;
}
function file_(){
	$val = func_get_args();  
	if(!empty($val)){ $n=$val[0];	$b = '<input type="file" name="'.$n.'" value="">';	}else{
		$b = '<input type="file" name="file" value="">';
	}
	return $b;
}
function submit(){  // value 1, value 2 
    $oncl = '';
	$val = func_get_args(); 
	if(!empty($val)){ 
	if(count($val)==2){	$oncl = $val[1]; }
	$n=$val[0];
	$b = '<input type="submit" name="submit" onclick="'.$oncl.'" value="'.$n.'">';	}else{
	$b = '<input type="submit" name="submit" value="Submit">';
	}
	return $b;
}

function compress($source, $destination, $quality) { $info = getimagesize($source); if ($info['mime'] == 'image/jpeg') $image = imagecreatefromjpeg($source); elseif ($info['mime'] == 'image/gif') $image = imagecreatefromgif($source); elseif ($info['mime'] == 'image/png') $image = imagecreatefrompng($source); imagejpeg($image, $destination, $quality); return $destination;
 }
function popup(){
	$button_value = 'Click Me';
	$pop_desc = 'Welcome to dev__ popup';
	$arg = func_get_args();	
	if(!empty($arg[0])){$button_value = $arg[0];}
	if(!empty($arg[1])){$pop_desc = $arg[1];}
	$button = '<div id="my_modal" class="pbg" style="display:none;margin:1em;">
    <a href="#" class="my_modal_close" style="float:right;padding:0 0.4em;">X</a>
	'.$pop_desc.'
	<button class="pbut btn-alert my_modal_close">Close</button>
    </div><input type="button" class="my_modal_open pbut" value="'.$button_value.'">';
	$button .= '<script type="text/javascript" charset="utf-8">
$(document).ready(function() {$(".my_modal_open").click(function(){$("#my_modal").popup({"autoopen": true});});});
</script>';	
	return $button;
}
// image resize
function resizeimage($filename, $max_width, $max_height){
          $imagepath = $filename;
          $save = $imagepath; //This is the new file you saving
          $file = $imagepath; //This is the original file

          list($width, $height) = getimagesize($file) ; 


          $tn = imagecreatetruecolor($width, $height) ; 
          $image = imagecreatefromjpeg($file) ; 
          imagecopyresampled($tn, $image, 0, 0, 0, 0, $width, $height, $width, $height) ; 

          imagejpeg($tn, $save, 100) ; 
          #$save = 'thumb_img/'.$imagepath;
		  
          $save = $imagepath; //This is the new file you saving
          $file = $imagepath; //This is the original file

          list($width, $height) = getimagesize($file) ; 

          $modwidth = $max_width; 
          $diff = $width / $modwidth;
          $modheight = $max_height; 
          $tn = imagecreatetruecolor($modwidth, $modheight) ; 
          $image = imagecreatefromjpeg($file) ; 
          imagecopyresampled($tn, $image, 0, 0, 0, 0, $modwidth, $modheight, $width, $height) ; 
          imagejpeg($tn, $save, 100) ; 
}
function extension($file_name) {
	return substr(strrchr($file_name,'.'),1);
}
function download($folder, $name){
	$file = $folder.'/'.$name;
	$mime_type='';
 if(!is_readable($file)) die('File not found or inaccessible!');
 
 $size = filesize($file);
 $name = rawurldecode($name);
 
 $known_mime_types=array(
 	"pdf" => "application/pdf",
 	"txt" => "text/plain",
 	"html" => "text/html",
 	"htm" => "text/html",
	"exe" => "application/octet-stream",
	"zip" => "application/zip",
	"doc" => "application/msword",
	"xls" => "application/vnd.ms-excel",
	"ppt" => "application/vnd.ms-powerpoint",
	"gif" => "image/gif",
	"png" => "image/png",
	"jpeg"=> "image/jpg",
	"jpg" =>  "image/jpg",
	"php" => "text/plain"
 );
 
 if($mime_type==''){
	 $file_extension = strtolower(substr(strrchr($file,"."),1));
	 if(array_key_exists($file_extension, $known_mime_types)){
		$mime_type=$known_mime_types[$file_extension];
	 } else {
		$mime_type="application/force-download";
	 };
 };
 
 //turn off output buffering to decrease cpu usage
 @ob_end_clean(); 
 
 // required for IE, otherwise Content-Disposition may be ignored
 if(ini_get('zlib.output_compression'))
  ini_set('zlib.output_compression', 'Off');
 
 header('Content-Type: ' . $mime_type);
 header('Content-Disposition: attachment; filename="'.$name.'"');
 header("Content-Transfer-Encoding: binary");
 header('Accept-Ranges: bytes');
 
 header("Cache-control: private");
 header('Pragma: private');
 header("Expires: Mon, 26 Jul 1997 05:00:00 GMT");
 
 if(isset($_SERVER['HTTP_RANGE']))
 {
	list($a, $range) = explode("=",$_SERVER['HTTP_RANGE'],2);
	list($range) = explode(",",$range,2);
	list($range, $range_end) = explode("-", $range);
	$range=intval($range);
	if(!$range_end) {
		$range_end=$size-1;
	} else {
		$range_end=intval($range_end);
	}
	
	$new_length = $range_end-$range+1;
	header("HTTP/1.1 206 Partial Content");
	header("Content-Length: $new_length");
	header("Content-Range: bytes $range-$range_end/$size");
 } else {
	$new_length=$size;
	header("Content-Length: ".$size);
 }
 
 /* Will output the file itself */
 $chunksize = 1*(1024*1024); //you may want to change this
 $bytes_send = 0;
 if ($file = fopen($file, 'r'))
 {
	if(isset($_SERVER['HTTP_RANGE']))
	fseek($file, $range);
 
	while(!feof($file) && 
		(!connection_aborted()) && 
		($bytes_send<$new_length)
	      )
	{
		$buffer = fread($file, $chunksize);
		print($buffer); //echo($buffer); // can also possible
		flush();
		$bytes_send += strlen($buffer);
	}
 fclose($file);
 } else
 //If no permissiion
 die('Error - can not open file.');
 //die
die();
}
function month(){
	       echo '<select name="month" id="month"><option value="">Select Month</option>';
	       for($i = 1; $i <= 12; $i++){
                $month_name = date('F', mktime(0, 0, 0, $i, 1, 2011));
                echo '<option value="'.$month_name.'">'.$month_name.'</option>';
            }
		   echo '</select>';
}
function country(){ $fetch='';
	$arg = func_get_args(); if(count($arg)!=0){ $fetch = $arg[0]; }
	$country = <<< EOF
	<select id="country" name="country">
<option value="">Country...</option>
<option value="Afganistan">Afghanistan</option>
<option value="Albania">Albania</option>
<option value="Algeria">Algeria</option>
<option value="American Samoa">American Samoa</option>
<option value="Andorra">Andorra</option>
<option value="Angola">Angola</option>
<option value="Anguilla">Anguilla</option>
<option value="Antigua &amp; Barbuda">Antigua &amp; Barbuda</option>
<option value="Argentina">Argentina</option>
<option value="Armenia">Armenia</option>
<option value="Aruba">Aruba</option>
<option value="Australia">Australia</option>
<option value="Austria">Austria</option>
<option value="Azerbaijan">Azerbaijan</option>
<option value="Bahamas">Bahamas</option>
<option value="Bahrain">Bahrain</option>
<option value="Bangladesh">Bangladesh</option>
<option value="Barbados">Barbados</option>
<option value="Belarus">Belarus</option>
<option value="Belgium">Belgium</option>
<option value="Belize">Belize</option>
<option value="Benin">Benin</option>
<option value="Bermuda">Bermuda</option>
<option value="Bhutan">Bhutan</option>
<option value="Bolivia">Bolivia</option>
<option value="Bonaire">Bonaire</option>
<option value="Bosnia &amp; Herzegovina">Bosnia &amp; Herzegovina</option>
<option value="Botswana">Botswana</option>
<option value="Brazil">Brazil</option>
<option value="British Indian Ocean Ter">British Indian Ocean Ter</option>
<option value="Brunei">Brunei</option>
<option value="Bulgaria">Bulgaria</option>
<option value="Burkina Faso">Burkina Faso</option>
<option value="Burundi">Burundi</option>
<option value="Cambodia">Cambodia</option>
<option value="Cameroon">Cameroon</option>
<option value="Canada">Canada</option>
<option value="Canary Islands">Canary Islands</option>
<option value="Cape Verde">Cape Verde</option>
<option value="Cayman Islands">Cayman Islands</option>
<option value="Central African Republic">Central African Republic</option>
<option value="Chad">Chad</option>
<option value="Channel Islands">Channel Islands</option>
<option value="Chile">Chile</option>
<option value="China">China</option>
<option value="Christmas Island">Christmas Island</option>
<option value="Cocos Island">Cocos Island</option>
<option value="Colombia">Colombia</option>
<option value="Comoros">Comoros</option>
<option value="Congo">Congo</option>
<option value="Cook Islands">Cook Islands</option>
<option value="Costa Rica">Costa Rica</option>
<option value="Cote DIvoire">Cote DIvoire</option>
<option value="Croatia">Croatia</option>
<option value="Cuba">Cuba</option>
<option value="Curaco">Curacao</option>
<option value="Cyprus">Cyprus</option>
<option value="Czech Republic">Czech Republic</option>
<option value="Denmark">Denmark</option>
<option value="Djibouti">Djibouti</option>
<option value="Dominica">Dominica</option>
<option value="Dominican Republic">Dominican Republic</option>
<option value="East Timor">East Timor</option>
<option value="Ecuador">Ecuador</option>
<option value="Egypt">Egypt</option>
<option value="El Salvador">El Salvador</option>
<option value="Equatorial Guinea">Equatorial Guinea</option>
<option value="Eritrea">Eritrea</option>
<option value="Estonia">Estonia</option>
<option value="Ethiopia">Ethiopia</option>
<option value="Falkland Islands">Falkland Islands</option>
<option value="Faroe Islands">Faroe Islands</option>
<option value="Fiji">Fiji</option>
<option value="Finland">Finland</option>
<option value="France">France</option>
<option value="French Guiana">French Guiana</option>
<option value="French Polynesia">French Polynesia</option>
<option value="French Southern Ter">French Southern Ter</option>
<option value="Gabon">Gabon</option>
<option value="Gambia">Gambia</option>
<option value="Georgia">Georgia</option>
<option value="Germany">Germany</option>
<option value="Ghana">Ghana</option>
<option value="Gibraltar">Gibraltar</option>
<option value="Great Britain">Great Britain</option>
<option value="Greece">Greece</option>
<option value="Greenland">Greenland</option>
<option value="Grenada">Grenada</option>
<option value="Guadeloupe">Guadeloupe</option>
<option value="Guam">Guam</option>
<option value="Guatemala">Guatemala</option>
<option value="Guinea">Guinea</option>
<option value="Guyana">Guyana</option>
<option value="Haiti">Haiti</option>
<option value="Hawaii">Hawaii</option>
<option value="Honduras">Honduras</option>
<option value="Hong Kong">Hong Kong</option>
<option value="Hungary">Hungary</option>
<option value="Iceland">Iceland</option>
<option value="India">India</option>
<option value="Indonesia">Indonesia</option>
<option value="Iran">Iran</option>
<option value="Iraq">Iraq</option>
<option value="Ireland">Ireland</option>
<option value="Isle of Man">Isle of Man</option>
<option value="Israel">Israel</option>
<option value="Italy">Italy</option>
<option value="Jamaica">Jamaica</option>
<option value="Japan">Japan</option>
<option value="Jordan">Jordan</option>
<option value="Kazakhstan">Kazakhstan</option>
<option value="Kenya">Kenya</option>
<option value="Kiribati">Kiribati</option>
<option value="Korea North">Korea North</option>
<option value="Korea Sout">Korea South</option>
<option value="Kuwait">Kuwait</option>
<option value="Kyrgyzstan">Kyrgyzstan</option>
<option value="Laos">Laos</option>
<option value="Latvia">Latvia</option>
<option value="Lebanon">Lebanon</option>
<option value="Lesotho">Lesotho</option>
<option value="Liberia">Liberia</option>
<option value="Libya">Libya</option>
<option value="Liechtenstein">Liechtenstein</option>
<option value="Lithuania">Lithuania</option>
<option value="Luxembourg">Luxembourg</option>
<option value="Macau">Macau</option>
<option value="Macedonia">Macedonia</option>
<option value="Madagascar">Madagascar</option>
<option value="Malaysia">Malaysia</option>
<option value="Malawi">Malawi</option>
<option value="Maldives">Maldives</option>
<option value="Mali">Mali</option>
<option value="Malta">Malta</option>
<option value="Marshall Islands">Marshall Islands</option>
<option value="Martinique">Martinique</option>
<option value="Mauritania">Mauritania</option>
<option value="Mauritius">Mauritius</option>
<option value="Mayotte">Mayotte</option>
<option value="Mexico">Mexico</option>
<option value="Midway Islands">Midway Islands</option>
<option value="Moldova">Moldova</option>
<option value="Monaco">Monaco</option>
<option value="Mongolia">Mongolia</option>
<option value="Montserrat">Montserrat</option>
<option value="Morocco">Morocco</option>
<option value="Mozambique">Mozambique</option>
<option value="Myanmar">Myanmar</option>
<option value="Nambia">Nambia</option>
<option value="Nauru">Nauru</option>
<option value="Nepal">Nepal</option>
<option value="Netherland Antilles">Netherland Antilles</option>
<option value="Netherlands">Netherlands (Holland, Europe)</option>
<option value="Nevis">Nevis</option>
<option value="New Caledonia">New Caledonia</option>
<option value="New Zealand">New Zealand</option>
<option value="Nicaragua">Nicaragua</option>
<option value="Niger">Niger</option>
<option value="Nigeria">Nigeria</option>
<option value="Niue">Niue</option>
<option value="Norfolk Island">Norfolk Island</option>
<option value="Norway">Norway</option>
<option value="Oman">Oman</option>
<option value="Pakistan">Pakistan</option>
<option value="Palau Island">Palau Island</option>
<option value="Palestine">Palestine</option>
<option value="Panama">Panama</option>
<option value="Papua New Guinea">Papua New Guinea</option>
<option value="Paraguay">Paraguay</option>
<option value="Peru">Peru</option>
<option value="Phillipines">Philippines</option>
<option value="Pitcairn Island">Pitcairn Island</option>
<option value="Poland">Poland</option>
<option value="Portugal">Portugal</option>
<option value="Puerto Rico">Puerto Rico</option>
<option value="Qatar">Qatar</option>
<option value="Republic of Montenegro">Republic of Montenegro</option>
<option value="Republic of Serbia">Republic of Serbia</option>
<option value="Reunion">Reunion</option>
<option value="Romania">Romania</option>
<option value="Russia">Russia</option>
<option value="Rwanda">Rwanda</option>
<option value="St Barthelemy">St Barthelemy</option>
<option value="St Eustatius">St Eustatius</option>
<option value="St Helena">St Helena</option>
<option value="St Kitts-Nevis">St Kitts-Nevis</option>
<option value="St Lucia">St Lucia</option>
<option value="St Maarten">St Maarten</option>
<option value="St Pierre &amp; Miquelon">St Pierre &amp; Miquelon</option>
<option value="St Vincent &amp; Grenadines">St Vincent &amp; Grenadines</option>
<option value="Saipan">Saipan</option>
<option value="Samoa">Samoa</option>
<option value="Samoa American">Samoa American</option>
<option value="San Marino">San Marino</option>
<option value="Sao Tome & Principe">Sao Tome &amp; Principe</option>
<option value="Saudi Arabia">Saudi Arabia</option>
<option value="Senegal">Senegal</option>
<option value="Seychelles">Seychelles</option>
<option value="Sierra Leone">Sierra Leone</option>
<option value="Singapore">Singapore</option>
<option value="Slovakia">Slovakia</option>
<option value="Slovenia">Slovenia</option>
<option value="Solomon Islands">Solomon Islands</option>
<option value="Somalia">Somalia</option>
<option value="South Africa">South Africa</option>
<option value="Spain">Spain</option>
<option value="Sri Lanka">Sri Lanka</option>
<option value="Sudan">Sudan</option>
<option value="Suriname">Suriname</option>
<option value="Swaziland">Swaziland</option>
<option value="Sweden">Sweden</option>
<option value="Switzerland">Switzerland</option>
<option value="Syria">Syria</option>
<option value="Tahiti">Tahiti</option>
<option value="Taiwan">Taiwan</option>
<option value="Tajikistan">Tajikistan</option>
<option value="Tanzania">Tanzania</option>
<option value="Thailand">Thailand</option>
<option value="Togo">Togo</option>
<option value="Tokelau">Tokelau</option>
<option value="Tonga">Tonga</option>
<option value="Trinidad &amp; Tobago">Trinidad &amp; Tobago</option>
<option value="Tunisia">Tunisia</option>
<option value="Turkey">Turkey</option>
<option value="Turkmenistan">Turkmenistan</option>
<option value="Turks &amp; Caicos Is">Turks &amp; Caicos Is</option>
<option value="Tuvalu">Tuvalu</option>
<option value="Uganda">Uganda</option>
<option value="Ukraine">Ukraine</option>
<option value="United Arab Erimates">United Arab Emirates</option>
<option value="United Kingdom">United Kingdom</option>
<option value="United States of America">United States of America</option>
<option value="Uraguay">Uruguay</option>
<option value="Uzbekistan">Uzbekistan</option>
<option value="Vanuatu">Vanuatu</option>
<option value="Vatican City State">Vatican City State</option>
<option value="Venezuela">Venezuela</option>
<option value="Vietnam">Vietnam</option>
<option value="Virgin Islands (Brit)">Virgin Islands (Brit)</option>
<option value="Virgin Islands (USA)">Virgin Islands (USA)</option>
<option value="Wake Island">Wake Island</option>
<option value="Wallis &amp; Futana Is">Wallis &amp; Futana Is</option>
<option value="Yemen">Yemen</option>
<option value="Zaire">Zaire</option>
<option value="Zambia">Zambia</option>
<option value="Zimbabwe">Zimbabwe</option>
</select>
EOF;
return $country;
}
function success(){
    $arg ='Success !';
	if($arg = func_get_args()){$arg = $arg[0];}
	return '<div class="alert alert-success">
			<button type="button" class="close" data-dismiss="alert">&times;</button>
            '.$arg.'
			</div>';
}
function error(){
	$arg ='Error !';
	if($arg = func_get_args()){$arg = $arg[0];}
	return '<div class="alert alert-danger">
			<button type="button" class="close" data-dismiss="alert">&times;</button>
            '.$arg.'
			</div>';
}
function warning(){
	$arg ='Error !';
	if($arg = func_get_args()){$arg = $arg[0];}
	return '<div class="alert alert-warning">
			<button type="button" class="close" data-dismiss="alert">&times;</button>
            '.$arg.'
			</div>';
}
function active(){
	return '<span class="label label-success">Active</span>';
}
function inactive(){
	return '<span class="label">In-Active</span>';
}
function control_list(){
   return array("text","number","password","textarea","radio","checkbox","select","file","date","time","datetime","phone","multiple-select");
}
function dynamicAjax(){ 
	
}
function showControl(){ $args = func_get_args();
    $type=$args[0];$field=$args[1]; $label=$args[2]; $field_id=$args[3]; $value=(isset($args[4]))?$args[4]:'';
	$class=(isset($args[6]))?$args[6]:'input-xlarge';
	
	$fet = fetch_once("tbl_fields","field_id=".(int)$field_id);
	$ajaxThisValue = ($value!='')?"'".$value."'":'this.value';
	$ajaxArgs = "'".$fet->ajax_table."','".$fet->ajax_field."',".$ajaxThisValue.",'".$fet->ajax_call_id."'";
	$ajaxType = ($fet->ajax_type!='')?$fet->ajax_type.'="return dynamicAjax('.$ajaxArgs.');"':'';
	$required=(isset($args[5]) && $args[5]==1)?'required '.$ajaxType:' '.$ajaxType;
	$chain_table = $fet->chain_table; $chain_table_field = $fet->chain_table_field;
	
	$value = (isset($_POST[$field]))?$_POST[$field]:$value;
	switch($type){ 
		case 'text':
		echo '<input type="text" class="'.$class.' focused" '.$required.' name="'.$field.'" id="'.$field.'" value="'.$value.'">';
		break;
		case 'date':
		echo '<input type="text" class="'.$class.' datepicker focused" '.$required.' name="'.$field.'" id="'.$field.'" value="'.$value.'">';
		break;
		case 'time':
		echo '<input type="text" class="'.$class.' timepicker focused" '.$required.' name="'.$field.'" id="'.$field.'" value="'.$value.'">';
		break;
		case 'datetime':
		echo '<div class="input-append date form_datetime" data-date="2012-12-21T15:25:00Z">
			<input size="16" type="text" '.$required.' name="'.$field.'" id="'.$field.'" value="'.$value.'" readonly>
			<span class="add-on"><i class="icon-remove"></i></span>
			<span class="add-on"><i class="icon-th"></i></span>
		</div>
		';
		break;
		case 'number':
		echo '<input type="number" class="'.$class.' focused" '.$required.' name="'.$field.'" id="'.$field.'" value="'.$value.'">';
		break;
		case 'phone':
		echo '<input type="tel" pattern="\d*" minlength="10" maxlength="10" class="'.$class.' focused" '.$required.'  name="'.$field.'" id="'.$field.'" value="'.$value.'">';
		break;
		case 'password':
		echo '<input type="password" class="'.$class.' focused" '.$required.' name="'.$field.'" id="'.$field.'" value="'.$value.'">';
		break;
		case 'textarea':
		echo '<textarea class="'.$class.' focused" '.$required.' id="'.$field.'" name="'.$field.'">'.$value.'</textarea>';
		break;
		case 'file':
		if($value!=''){ echo '<input type="hidden" name="_'.$field.'" value="'.$value.'">'; echo '<img src="'.site_base().'/upload/'.$value.'" width="85" height="85">'; $required=0;}
		echo '<input class="'.$class.' '.$required.' focused" type="file" name="'.$field.'">';
		break;
		case 'radio':
		$sql = mysql_query("SELECT * FROM tbl_field_option WHERE field_id=".$field_id);
        while($fetch = mysql_fetch_object($sql)){ $chk = ($fetch->value==$value)?'checked':'';
		echo ' <input type="radio" '.$required.' class="'.$class.' focused" '.$chk.' name="'.$field.'[]" value="'.$fetch->value.'"> '.$fetch->value;
		}
		break;
		case 'checkbox':
		$sql = mysql_query("SELECT * FROM tbl_field_option WHERE field_id=".$field_id);
        while($fetch = mysql_fetch_object($sql)){ $chk = ($fetch->value==$value)?'checked':'';
		echo ' <input type="checkbox" '.$required.' class="'.$class.' focused" '.$chk.' name="'.$field.'[]" value="'.$fetch->value.'"> '.$fetch->value;
		}
		break;
		case 'select':
		$table = 'tbl_field_option'; $where = "WHERE field_id=".$field_id; $star='*'; $thisField = 'value';
		if($chain_table!=''){ $table = $chain_table; $star=$thisField = $chain_table_field; $where='';	}
		
		echo '<select class="'.$class.' focused" '.$required.' name="'.$field.'" id="'.$field.'"><option value=""></option>';
		$sql = mysql_query("SELECT ".$star." FROM ".$table." ".$where);
        while($fetch = mysql_fetch_object($sql)){ $chk = ($fetch->$thisField==$value)?'selected':'';
		echo '<option value="'.$fetch->$thisField.'" '.$chk.'>'.ucwords($fetch->$thisField).'</option>';
		}
		echo '</select>';
		break;
		
		case 'multiple-select':
		$table = 'tbl_field_option'; $where = "WHERE field_id=".$field_id; $star='*'; $thisField = 'value';
		if($chain_table!=''){ $table = $chain_table; $star=$thisField = $chain_table_field; $where='';	}
		$selectedValueArray = explode(',',$value);
		$sql = mysql_query("SELECT ".$star." FROM ".$table." ".$where);
		echo '<select multiple="multiple" class="'.$class.' focused" '.$required.' name="'.$field.'[]" id="'.$field.'"><option value=""></option>'; 		
        while($fetch = mysql_fetch_object($sql)){ 
		#strpos($fetch->$thisField);
		$chk = (in_array($fetch->$thisField,$selectedValueArray))?'selected':'';
		
		echo '<option value="'.$fetch->$thisField.'" '.$chk.'>'.ucwords($fetch->$thisField).'</option>';
		}
		echo '</select>';
		break;
	}
}
function show_on_table($field){
		$query = mysql_query("SELECT `field`,`show_on_table` FROM tbl_fields WHERE field='".$field."'");
		if(mysql_num_rows($query)>0){
			$result=mysql_fetch_object($query);
			return $result->show_on_table;
		}
}
function ajaxTypes(){
	return array("onchange","onkeyup","onkeypress","onselect","onblur","onfocus","onkeydown");
}
function void(){ return 'javascript:void(0);';}
function cancelButton(){ $href="''";
	return '<input type="button" onclick="document.location.href='.$href.';" class="btn btn-default" value="Clear" />';
} // 
function searchButton(){
	return '<input type="submit" name="filter_date_between" id="filter_date_between" class="btn btn-primary" value="Search" />';
}


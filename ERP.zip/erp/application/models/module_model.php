<?php
class Module_model extends CI_Model{
	public function index($datas){ extract($datas);
			if(isset($_POST['delete_id']) && $_POST['delete_id']!=''){
			   $query = $this->db->get_where($valueTable, array('module_id' => $_POST['delete_id']));			
			   $result= $query->row_object();
			   			   
			  if(file_exists('application/controllers/'.$result->controller.'.php') && file_exists('application/models/'.$result->controller.'_model.php') && is_dir('application/views/'.$result->controller)){
				  unlink('application/controllers/'.$result->controller.'.php');
				  unlink('application/models/'.$result->controller.'_model.php');
				  rrmdir('application/views/'.$result->controller);
				  
			  }
			  $this->db->query("drop table IF EXISTS `".$result->table_name."` ");
			  mysql_query("DELETE FROM $valueTable WHERE $unique_id=".$_POST['delete_id']);
			  $F = mysql_fetch_assoc(mysql_query("SELECT GROUP_CONCAT(`field_id`) as field_ids FROM `$fieldTable` WHERE `link_table`='".$result->table_name."'"));
			  # Field Option table Delete
			  mysql_query("DELETE FROM `$optionTable` WHERE `field_id` IN(".$F['field_ids'].")");			  			  
			  # FINAL DELETE
			  mysql_query("DELETE FROM `$fieldTable` WHERE `link_table`='".$result->table_name."'");
			  
			  $_SESSION['msg'] = success($delete_msg);
			}
			if(isset($_POST['active_id'])){
			  mysql_query("UPDATE $valueTable SET status=1 WHERE $unique_id=".$_POST['active_id']);
			  $_SESSION['msg'] = success($active_msg);
			}
			if(isset($_POST['inactive_id'])){
			  mysql_query("UPDATE $valueTable SET status=0 WHERE $unique_id=".$_POST['inactive_id']);
			  $_SESSION['msg'] = success($deactive_msg);
			}
	}
	 public function add($datas){ extract($datas);
		 	$msg='';
			$fields = $types = array();
			$select = mysql_query("SELECT * FROM `$fieldTable` WHERE link_table='".$valueTable."' and status=1"); while($fet = mysql_fetch_object($select)){ $fields[] = $fet->field; $types[] = $fet->type;}
			if(isset($_POST['SaveStudent'])){ $fieldsVal=array();
			   foreach($fields as $key=>$field){
				   if($types[$key]=='file'){  
					if($_FILES[$field]['name']!=''){
					$file = rand(100,10).time().$_FILES[$field]['name'];
					move_uploaded_file($_FILES[$field]['tmp_name'],'upload/'.$file);
					$fieldsVal[] = "`$field`='".mysql_real_escape_string($file)."'";
					}
				   }elseif($types[$key]=='radio'){  
					$fieldsVal[] = "`$field`='".implode(',',$_POST[$field])."'";
					
				   }elseif($types[$key]=='checkbox'){
					$fieldsVal[] = "`$field`='".implode(',',$_POST[$field])."'";
					
				   }else{
					$fieldsVal[] = "`$field`='".mysql_real_escape_string($_POST[$field])."'";
				   }
			   }
			
			$query = $this->db->get_where('tbl_module_creator', array('creator_id' => 1));
			
			$result= $query->row_object();
			if((!file_exists('application/controllers/'.$_REQUEST['controller'].'.php')) && (!file_exists('application/models/'.$_REQUEST['controller'].'_model.php')) && (!is_dir('application/views/'.$_REQUEST['controller']))){
				# Dynamic Controller File
				$fp=fopen('application/controllers/'.$_REQUEST['controller'].'.php','w');			
					
				$controllerTitle = ucwords(clean($_REQUEST['controller']));
				$replacer_code = str_replace('Sample_c', strtolower($_REQUEST['controller']),$result->controller_code);
				$replacer_code = str_replace('Sample_t', $controllerTitle,$replacer_code);
				$replacer_code = str_replace('put_table_name', $_REQUEST['table_name'],$replacer_code);
				$replacer_code = str_replace('put_table_id', $_REQUEST['table_id'],$replacer_code);
				fwrite($fp,$replacer_code);
				
				# Dynamic Model File
				$fm=fopen('application/models/'.strtolower($_REQUEST['controller']).'_model.php','w');			
				$model_code = str_replace('Sample_model', strtolower($_REQUEST['controller']).'_model',$result->model_code);			
				fwrite($fm,$model_code);
				fclose($fm);
				fclose($fp);
				# Dynamic View Files				
				mkdir('application/views/'.$_REQUEST['controller'],0777) or die('MVC Folders could not create!');
				copy_all('system/moduler/view/','application/views/'.$_REQUEST['controller'].'/');			
			   
			   mysql_query("INSERT INTO `$valueTable` set ".implode(',',$fieldsVal));
			   if(!mysql_query("SELECT * FROM `".$_REQUEST['table_name']."`")){
					$this->db->query("CREATE TABLE `".$_REQUEST['table_name']."` (
								 `".$_REQUEST['table_id']."` bigint(20) NOT NULL AUTO_INCREMENT,
								 `last_modified_date` datetime NOT NULL,
								 `create_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
								 `status` tinyint(4) NOT NULL DEFAULT '1',
								 PRIMARY KEY (`".$_REQUEST['table_id']."`)
								) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1");
				   $_SESSION['msg'] = success($message);
				   header("location:".$base_url);
			   }else{
				   $_SESSION['msg'] = error("Sorry `".$_REQUEST['table_name']."` already exist!");
			   }
			}else{
				   $_SESSION['msg'] = error("Sorry `".$_REQUEST['controller']."` module already exist!");
			}
			   
			} 
	 }
	 public function update($datas){ extract($datas);
		    $msg='';
			$fields = $types = array();
			$select = mysql_query("SELECT * FROM `$fieldTable` WHERE link_table='".$valueTable."' and status=1"); while($fet = mysql_fetch_object($select)){ $fields[] = $fet->field; $types[] = $fet->type;}
			if(isset($_POST['UpdateStudent'])){ $fieldsVal=array();
			   foreach($fields as $key=>$field){
				   if($types[$key]=='file'){  
					if($_FILES[$field]['name']!=''){
					$file = rand(100,10).time().$_FILES[$field]['name'];
					move_uploaded_file($_FILES[$field]['tmp_name'],'upload/'.$file);
					$fieldsVal[] = "`$field`='".mysql_real_escape_string($file)."'";
					}else{
					 $file = $_POST['_'.$field];
					 $fieldsVal[] = "`$field`='".mysql_real_escape_string($file)."'";
					}
				   }elseif($types[$key]=='radio'){  
					$fieldsVal[] = "`$field`='".implode(',',$_POST[$field])."'";
					
				   }elseif($types[$key]=='checkbox'){
					$fieldsVal[] = "`$field`='".implode(',',$_POST[$field])."'";
					
				   }else{
					$fieldsVal[] = "`$field`='".mysql_real_escape_string($_POST[$field])."'";
				   }
			   }
			   mysql_query("UPDATE `$valueTable` SET ".implode(',',$fieldsVal)." WHERE $unique_id=".$edit_id);
			   $_SESSION['msg'] = success($message);
			   header("location:".$base_url);
			}
	 }
}
?>
<?php 

$base_url = $this->config->base_url(); 
session_start();
$this->load->helper('form');
$this->load->helper('url');
$this->load->helper('built');
$this->load->helper('general');
if(!isset($_SESSION['user'])){ header("location:".$base_url."index.php/login"); }
// DataTables\media\css
$_SESSION['hide_field']='';
?>
<!DOCTYPE html>
<html class="no-js">
    <head>
        <title><?=strtoupper($title)?></title>
        <!-- Bootstrap -->
        <link href="<?=$base_url?>bootstrap/css/bootstrap.min.css" rel="stylesheet" media="screen">
        
        <link href="<?=$base_url?>bootstrap/css/bootstrap-responsive.min.css" rel="stylesheet" media="screen">
        <link href="<?=$base_url?>vendors/easypiechart/jquery.easy-pie-chart.css" rel="stylesheet" media="screen">
        <link href="<?=$base_url?>assets/styles.css" rel="stylesheet" media="screen">
        <link href="<?=$base_url?>assets/DT_bootstrap.css" rel="stylesheet" media="screen">
        <link href="<?=$base_url?>vendors/jGrowl/jquery.jgrowl.css" rel="stylesheet" media="screen">
        
        <link href="<?=$base_url?>DataTables/media/css/jquery.dataTables.css" rel="stylesheet" media="screen">
        <link href="<?=$base_url?>DataTables/media/css/jquery.dataTables.min.css" rel="stylesheet" media="screen">
        <link href="<?=$base_url?>DataTables/media/css/jquery.dataTables_themeroller.css" rel="stylesheet" media="screen">
        <!-- Export Print  -->
        <link href="<?=$base_url?>DataTables/media/css/dataTables.tableTools.css" rel="stylesheet" media="screen">
        <link href="<?=$base_url?>DataTables/media/css/dataTables.bootstrap.css" rel="stylesheet" media="screen">
        <!-- HTML5 shim, for IE6-8 support of HTML5 elements -->
        <!--[if lt IE 9]>
            <script src="http://html5shim.googlecode.com/svn/trunk/html5.js"></script>
        <![endif]-->        
        <!--<script src="<?=$base_url?>vendors/modernizr-2.6.2-respond-1.1.0.min.js"></script>-->
        
        <script src="<?=$base_url?>vendors/jquery-1.11.1.js"></script>
        <style> /* Export Button */
		div.DTTT { margin-bottom: 0.5em; float: right; }
		div.dataTables_wrapper { clear: both; }
		</style>
        
    </head>
    
    <body class="dt-example">
        <div class="navbar navbar-fixed-top">
            <div class="navbar-inner">
                <div class="container-fluid">
                    <a class="btn btn-navbar" data-toggle="collapse" data-target=".nav-collapse"> <span class="icon-bar"></span>
                     <span class="icon-bar"></span>
                     <span class="icon-bar"></span>
                    </a>
                    <a class="brand" href="<?=base_url();?>">Dev__ ERP</a>
                    <div class="nav-collapse collapse">
                        <ul class="nav pull-right">
                            <li class="dropdown">
                                <a href="#" role="button" class="dropdown-toggle" data-toggle="dropdown"> 
                                <span class="badge badge-info pull-left"><?=currentVisitors()?></span>
                                <i class="icon-user"></i> <?=$_SESSION['user']->username?> <i class="caret"></i>
                                </a>
                                <ul class="dropdown-menu">
                                    <li>
                                        <a tabindex="-1" href="#myProfile" role="button" data-backdrop="static" data-toggle="modal">Profile</a>
                                    </li>
                                    <li class="divider"></li>
                                    <li>
                                        <a tabindex="-1" href="<?=$base_url?>index.php/login/logout">Logout</a>
                                    </li>
                                </ul>
                            </li>
                        </ul>
                        <ul class="nav">
                            <li class="active">
                                <a href="<?=base_url();?>">Dashboard</a>
                            </li>
                            <?php if(isset($_SESSION['user']->type) && $_SESSION['user']->type==1){ ?>
                            <li class="dropdown">
                                <a href="#" data-toggle="dropdown" class="dropdown-toggle">Modules Handler<b class="caret"></b>

                                </a>
                                <ul class="dropdown-menu" id="menu1">
                                <?php 
									$sql = mysql_query("SELECT * FROM tbl_modules WHERE `left_menu`!='' order by `sorting` asc");
									while($fetch = mysql_fetch_object($sql)){
										$active = ($fetch->controller==$this->router->fetch_class())?'class="active"':'';
									?> 
									<li <?=$active?>>
										<a href="<?=$base_url?>index.php/<?=$fetch->controller?>/setting"><?=$fetch->module?></a>
									</li>
                                    <?php }?>
                                </ul>
                            </li>
                            <li class="dropdown">
                                <a href="#" role="button" class="dropdown-toggle" data-toggle="dropdown">Users <i class="caret"></i>

                                </a>
                                <ul class="dropdown-menu">
                                    <li>
                                        <a tabindex="-1" href="<?=$base_url?>index.php/user">All Users</a>
                                    </li>
                                    <li>
                                        <a tabindex="-1" href="<?=$base_url?>index.php/user/setting">Users Controls</a>
                                    </li>
                                </ul>
                            </li>
                            <li class="dropdown">
                                <a href="#" role="button" class="dropdown-toggle" data-toggle="dropdown">Settings <i class="caret"></i>

                                </a>
                                <ul class="dropdown-menu">
                                    <li>
                                        <a tabindex="-1" href="<?=$base_url?>index.php/module">All Modules</a>
                                    </li>
                                    <li>
                                        <a tabindex="-1" href="<?=$base_url?>index.php/module/setting">Module Controls</a>
                                    </li>
                                </ul>
                            </li> 
                            <?php }?>
                        </ul>
                    </div>
                    <!--/.nav-collapse -->
                </div>
            </div>
        </div>
        <!--  LEFT SIDE MENUS -->
        <div class="container-fluid">
            <div class="row-fluid">
                <div class="span2 margin-right-30" id="sidebar">
                    <ul class="nav nav-list bs-docs-sidenav nav-collapse collapse">
                        <li <?php if($this->router->fetch_class()=='home'){?>class="active"<?php }?>>
                            <a href="<?=$base_url?>index.php"><i class="icon-chevron-right"></i> Dashboard</a>
                        </li>
                        <?php 
						if(isset($_SESSION['user']->type)){				
						$sql = mysql_query("SELECT * FROM tbl_modules WHERE `left_menu`!='' order by `sorting` asc");
						while($fetch = mysql_fetch_object($sql)){
							$active = ($fetch->controller==$this->router->fetch_class())?'class="active"':'';
						?> 
						<li <?=$active?>>
                            <a href="<?=$base_url?>index.php/<?=$fetch->controller?>"><i class="icon-chevron-right"></i> <?=$fetch->module?></a>
                        </li> 
						<?php } }else{ 
						$sql = mysql_query("SELECT * FROM tbl_user WHERE user_id=".$_SESSION['user']->user_id);
						$fetch = mysql_fetch_object($sql);
						foreach(explode(',',$fetch->access_module) as $module){
							$ft = fetch_once("tbl_modules","module='".$module."'");
							$active = ($ft->controller==$this->router->fetch_class())?'class="active"':'';
							//$modules = explode(',',$fetch->module);
							
						?> 
						<li <?=$active?>>
                            <a href="<?=$base_url?>index.php/<?=$ft->controller?>"><i class="icon-chevron-right"></i> <?=$module?></a>
                        </li> 
                        <?php }}?>
                    </ul>
                </div>
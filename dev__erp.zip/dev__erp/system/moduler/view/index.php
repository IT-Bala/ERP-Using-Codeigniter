<?php # Employee
$fetchAssoc = $unsetFields=array();
$start_date = (isset($_POST['start_date']))?$_POST['start_date']:'';
$end_date = (isset($_POST['end_date']))?$_POST['end_date']:'';

$dateBetween='';
if($start_date!='' && $end_date!=''){ 
    $start_date = date('Y-m-d',strtotime($start_date)).'';
	$end_date = date('Y-m-d',strtotime('+1 day'.$end_date)).'';
	$dateBetween = " WHERE create_date >= '".$start_date."' AND create_date < '".$end_date."'";
}

$dateBetween = ($dateBetween=='')?" WHERE DATE(create_date)='".date('Y-m-d')."' ":$dateBetween;

$sql = mysql_query("SELECT *,DATE_FORMAT(create_date, '%d-%m-%Y') create_date FROM $valueTable ".$dateBetween);
while($fetch = mysql_fetch_assoc($sql)){ $fetchAssoc[] = $fetch; }
unset($fetchAssoc[0]['status']);

$column = 1;
$moduleSql = mysql_query("SELECT `column` FROM `tbl_modules` WHERE `table_name`='$valueTable'");
if(mysql_num_rows($moduleSql)>0){
	$fM = mysql_fetch_object($moduleSql);
	$column = $fM->column;
}
?>
<div class="span10" id="content">
                    <div class="row-fluid">
                    <?=(isset($_SESSION['msg']))?$_SESSION['msg']:''?>
                    	</div>
                     <div class="row-fluid">
                            <div class="navbar">
                               <div class="navbar-inner">
                                <div class="container-fluid">
                                    <div class="nav-collapse collapse">                                        
                                        <ul class="nav">
                                            <li>
                                                <a href="<?=$base_url?>"><?=$title?></a>
                                            </li>
                                        </ul>
                                    </div>
                                    <!--/.nav-collapse -->
                                </div>
                            </div>
                          </div>
                    	</div>
              <!--<button class="btn btn-primary" onclick="document.location.href='<?=$base_url?>add'"><?=$add_button?></button>-->
              <form method="post">
                <div style="margin: 0;" class="btn-toolbar">
                  <div class="btn-group">                    
                    <input type="text" class="input-medium datepicker" placeholder="Start Date" name="start_date" value="<?=req('start_date')?>" />
                  </div>
                  <div class="btn-group">                    
                    <input type="text" class="input-medium datepicker" placeholder="End Date" name="end_date" value="<?=req('end_date')?>" />
                  </div>
                  <div class="btn-group">
                  	<?=searchButton();?>
                   </div>
                   <div class="btn-group">
                   <?=cancelButton()?>
                  </div>
              </div> 
              </form>
                    <!--<div class="pull-right right-45" style="display:flex;">
                    <form method="post">
                    <?=searchButton();?>
                    <?=cancelButton()?>                    
                    </form>
                    </div>--> <div class="clearfix"></div>
                    <div class="row-fluid">
                        <!-- block -->
                        <div class="block">
                            <div class="navbar navbar-inner block-header">
                            	<div class="muted pull-left">
                                  <h6><?=$title?></h6>
                                </div>
                                <div class="muted pull-right">
                                <a href="#add_new_pop" role="button" data-backdrop="static" data-toggle="modal" class="btn btn-primary"><i class="icon-plus-sign"></i>&nbsp;<?=$add_button?></a>
                                </div>
                            </div>
                            <?php $imageExt = array('jpg','png','jpeg','gif','svg','bmp'); 
							
							#print_r($fetchAssoc[0]);
							?>
                            <div class="block-content collapse in">
                                <div class="span12">
  									<table cellpadding="0" cellspacing="0" border="0" class="table table-striped table-bordered" id="example">
										<thead>
											<tr>
                                                <?php if(isset($fetchAssoc[0]) && count($fetchAssoc[0])>0){
												foreach($fetchAssoc[0] as $field=>$obj){
												if(show_on_table($field)==1){
												?>
												<th><?=_field_($field)?></th>                                               
                                                <?php }}}?>
                                                <th>Action</th>
											</tr>
										</thead>
                                        
										<tbody>
                                            <?php $status=''; for($i=0; $i<count($fetchAssoc); $i++){ ?>
											<tr class="odd gradeX">
                                                <?php foreach($fetchAssoc[$i] as $field=>$values){
												 $sql = mysql_query("SELECT type FROM $fieldTable WHERE link_table='".$valueTable."' and field='".$field."'");
												 if($field=='status'){ $status=$values;
												   $values = ($values==1)?active():inactive();
												 }
												 if(mysql_num_rows($sql)>0 && $values!=''){
												   $fet = mysql_fetch_object($sql);
												   if($fet->type=='file'){
												   $ext = extension($values);
												   $icon = '<i class="icon-file">';
												   if(in_array($ext,$imageExt)){ $icon = '<i class="icon-picture">';  }
												   $values = '<a target="_blank" href="'.$this->config->base_url().'upload/'.$values.'">
												   '.$icon.'</a>';
												   }
												 }
												 $edit_id = $fetchAssoc[$i][$unique_id];
												 if($field!='status' && (show_on_table($field)==1)){
												?>
												<td><?=$values?></td>
                                                <?php  }}?>
                                                <td>
                                                                                               
                                                <a href="<?php echo $base_url.'view/'.($fetchAssoc[$i][$unique_id])?>" data-toggle="modal" data-backdrop="static" role="button"><i class="icon-list tooltip-top" data-original-title="View"></i></a>&nbsp;&nbsp;
                                               
                                                                                               
                                                <a data-toggle="modal" data-backdrop="static" href="#editPop<?=$fetchAssoc[$i][$unique_id]?>"><i class="icon-edit tooltip-top" data-original-title="Edit"></i></a>&nbsp;&nbsp;
                                                
                                                <i class="icon-trash tooltip-top" onclick="return deleteMe('<?=$fetchAssoc[$i][$unique_id]?>');" data-original-title="Trash"></i>
                                                
                                                <div class="fade modal" id="editPop<?=$fetchAssoc[$i][$unique_id]?>" <?php if($column!=1){ $minWidth=$column*20; $left=70-($column*10);?>style="min-width:<?=$minWidth?>%;left:<?=$left?>%"<?php }?>>
                                                                       
													<div class="modal-dialog">                        
                                                        <div class="modal-content">                        
                                                            <div class="modal-header">                        
                                                                <button type="button" id="closePop" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>                <h4 class="modal-title">Edi Information</h4>
                                                            </div>
                                                            <form action="<?=$base_url?>edit/<?php echo($fetchAssoc[$i][$unique_id])?>" method="post" enctype="multipart/form-data">
                                                            <div class="modal-body" id="add_new_ajax">
                                                                <div class="block-content collapse in">
                                                                	<?php
																	$total  = 12; $span  = $total/$column;
																	for($j=1;$j<=$column;$j++){
																		if ($j%1 == 0){ echo '<div class="span'.$span.'">';
																																				
                                                                        $sql = mysql_query("SELECT * FROM $fieldTable WHERE link_table='".$valueTable."' AND `field_column`=".$j." AND status=1 order by `field_row` ASC");
                                                                        if(mysql_num_rows($sql)>0){
                                                                        $fetchVal = fetch_once("$valueTable","`$unique_id`=$edit_id");
                                                                        
                                                                        ?>
                                                                        <?php 
                                                                        while($fetch = mysql_fetch_object($sql)){ $fieldVal = (string)$fetch->field;
                                                                        ?>
                                                                        <div class="control-group">
                                                                          <label for="focusedInput" class="control-label"><?php echo $fetch->label;if($fetch->required==1){?><i class="star">*</i><?php }?></label>
                                                                          <div class="controls">
                                                                          <?php echo showControl($fetch->type,$fetch->field,$fetch->label,$fetch->field_id,$fetchVal->$fieldVal,$fetch->required,'');?>
                                                                          </div>
                                                                        </div>
                                                                        <?php }} echo '</div>'; }}?>
                                                                        
                                                                        <div class="clearfix"></div>
                                                                       <div class="form-actions">
                                                                          <button class="btn btn-primary" name="UpdateStudent" type="submit">Save changes</button>
                                                                          <a href="<?=$base_url?>" class="btn">Back</a>
                                                                        </div>
                                                                        
                           								         </div>
                                                               </div> 
                                                            </form>    
                                                              </div>
                                                            </div>                                   
                                                        </div>
                                                </td>
											</tr>
                                            <?php }?>
										</tbody>
									</table>
                              </div>
                            </div>
                        </div>
                        <!-- /block -->
                    </div>
                    
 </div>
 <?php if(isset($_SESSION['msg'])){ unset($_SESSION['msg']);} ?>

 
 <div id="add_new_pop" class="modal fade" <?php if($column!=1){ $minWidth=$column*20; $left=70-($column*10);?>style="min-width:<?=$minWidth?>%;left:<?=$left?>%"<?php }?>>                      
    <div class="modal-dialog">                        
        <div class="modal-content">                        
            <div class="modal-header">                        
                <button type="button" id="closePop" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>                <h4 class="modal-title"><?=$add_title?></h4>
            </div>
            <form action="<?=$base_url?>add" method="post" enctype="multipart/form-data">
            <div class="modal-body" id="add_new_ajax">
                <div class="block-content collapse in">                
                	<?php
					$total  = 12;$span  = $total/$column;
					for($i=1;$i<=$column;$i++){
						if ($i%1 == 0){ echo '<div class="span'.$span.'">';
					?>
                    	                    	                          
                            <?php
                            $sql = mysql_query("SELECT * FROM $fieldTable WHERE link_table='".$valueTable."' AND `field_column`=".$i." and status=1 order by `field_row` ASC");
                            if(mysql_num_rows($sql)>0){
                            ?>
                            <?php 
                            while($fetch = mysql_fetch_object($sql)){
                            ?>
                            <div class="control-group">
                              <label for="focusedInput" class="control-label"><?php echo $fetch->label; if($fetch->required==1){?><i class="star">*</i><?php }?></label>
                              <div class="controls">
                              <?php echo showControl($fetch->type,$fetch->field,$fetch->label,$fetch->field_id,'',$fetch->required,'');?>
                              </div>
                             </div>
                            <?php }} echo '</div>';}?>   
                                                   
                    <?php }?>
                    <div class="clearfix"></div>
                    <div class="form-actions">
                      <button class="btn btn-primary" name="SaveStudent" type="submit">Save changes</button>
                      <a href="<?=$base_url?>" class="btn">Back</a>
                    </div>
                    
            </div>
        	</div>
            </form>
      </div>
 </div>
</div>
<?php
function currentVisitors(){
	return num("tbl_visitors WHERE time_out='' or time_out='0' or time_out='0:00' or time_out='00:00'");
}
function _field_($field){
	return ucfirst(str_replace('_',' ',$field));
}
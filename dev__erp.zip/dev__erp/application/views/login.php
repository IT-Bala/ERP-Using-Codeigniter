<?php $base_url = $this->config->base_url(); ?>
<!DOCTYPE html>
<html>
  <head>
    <title>Dev__ ERP</title>
    <!-- Bootstrap -->
    <link href="<?=$base_url?>bootstrap/css/bootstrap.min.css" rel="stylesheet" media="screen">
    <link href="<?=$base_url?>bootstrap/css/bootstrap-responsive.min.css" rel="stylesheet" media="screen">
    <link href="<?=$base_url?>assets/styles.css" rel="stylesheet" media="screen">
  </head>
  <body id="login">
    <div class="container">    
      <form class="form-signin" method="post"><p class="text-center"><?=(isset($msg))?$msg:''?></p>
        <h2 class="form-signin-heading text-center">Login</h2>
        <input type="text" class="input-block-level" required name="username" placeholder="Username">
        <input type="password" class="input-block-level" required name="password" placeholder="Password">
        <label class="checkbox">
          <input type="checkbox" value="remember-me"> Remember me
        </label>
        <button class="btn btn-large btn-primary" name="Login" type="submit">Sign in</button>
      </form>

    </div> <!-- /container -->
  </body>
</html>
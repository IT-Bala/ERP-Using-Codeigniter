<?php
$msg ='';
if(isset($_POST['SaveControl'])){ extract($_POST);
    if($label!='' && $field!=''){ $column = strtolower(trim(mysql_real_escape_string($field)));
	
		mysql_query("SELECT `$column` FROM `$valueTable`") or mysql_query("ALTER TABLE `$valueTable` ADD `$column` TEXT NOT NULL");
		
		$thisQue = mysql_query("SELECT * FROM `$fieldTable` WHERE link_table='".$valueTable."' and field='".$column."'");
		if(mysql_num_rows($thisQue)==0){
		mysql_query("INSERT INTO `$fieldTable` SET link_table='".mysql_real_escape_string($valueTable)."',label='".mysql_real_escape_string($label)."',field='".$column."',required='".$required."',type='".$type."'");
		$field_id = mysql_insert_id();
		
		if(isset($_POST['value']) && count($_POST['value'])!=0){
			 foreach($_POST['value'] as $value){
			  mysql_query("INSERT INTO `$optionTable` SET field_id='".$field_id."',value='".mysql_real_escape_string($value)."'");
			 }
		 }$msg =  success("New field has been added successfully!");
	   }else{
		   $msg = error("Sorry this column already exist!");
	   }
	}
}
if(isset($_POST['UpdateControl'])){ extract($_POST);
	// ALTER TABLE  `tbl_students` CHANGE  `students`  `student` TEXT NOT NULL
	mysql_query("UPDATE `$fieldTable` SET label='".mysql_real_escape_string($label)."',type='".$type."',required='".$required."' WHERE field_id=".(int)$_POST['field_id']);
	mysql_query("DELETE FROM `$optionTable` WHERE field_id=".$_POST['field_id']);
	if(isset($_POST['value']) && count($_POST['value'])!=0){
		 foreach($_POST['value'] as $value){
		  mysql_query("INSERT INTO `$optionTable` SET field_id='".$field_id."',value='".mysql_real_escape_string($value)."'");
		 }
	 } $msg =  success("Field has been updated successfully!");
}
if(isset($_POST['delete_id'])){ 
  $fetch = fetch_once("$fieldTable","link_table='".$valueTable."' AND field_id=".$_POST['delete_id']);
  mysql_query("ALTER TABLE $valueTable DROP `".$fetch->field."`");
  mysql_query("DELETE FROM $optionTable WHERE field_id=".$_POST['delete_id']);
  mysql_query("DELETE FROM $fieldTable WHERE field_id=".$_POST['delete_id']);
  $msg = success("Field has been deleted successfully!");
}
$sqll = mysql_query("SELECT * FROM $fieldTable WHERE link_table='".$valueTable."'");
if(mysql_num_rows($sqll)==0){ 
	mysql_query("TRUNCATE TABLE $valueTable");
}
if(isset($_POST['active_id'])){
  mysql_query("UPDATE $fieldTable SET status=1 WHERE field_id=".$_POST['active_id']);
}
if(isset($_POST['inactive_id'])){
  mysql_query("UPDATE $fieldTable SET status=0 WHERE field_id=".$_POST['inactive_id']);
}
$requiredArray = array('No','Yes');
?>
<div class="span10" id="content">
                    <?=$msg?>
                    <div class="row-fluid">
                            <div class="navbar">
                               <div class="navbar-inner">
                                <div class="container-fluid">
                                    <div class="nav-collapse collapse">
                                        
                                        <ul class="nav">
                                            <li class="active">
                                                <a href="<?=$base_url?>setting">User List</a>
                                            </li>
                                        </ul>
                                    </div>
                                    <!--/.nav-collapse -->
                                </div>
                            </div>
                          </div>
                    	</div>
                    <a class="btn btn-primary" data-toggle="modal" href="#myModal">Add New</a>
                    <div class="modal hide" id="myModal" style="display: none;" aria-hidden="true">
                        <div class="modal-header">
                            <button type="button" class="close" data-dismiss="modal">�</button>
                            <h3>Student Field</h3>
                        </div>
                        <div class="modal-body">
                            <form class="form-horizontal" method="post" enctype="multipart/form-data">
                              <fieldset>
                                <div class="control-group">
                                  <label for="focusedInput" class="control-label">Lable Name</label>
                                  <div class="controls">
                                    <input type="text" required value="<?=req('label')?>" name="label" id="focusedInput" class="input-large focused">
                                  </div>
                                </div>
                                <div class="control-group">
                                  <label for="focusedInput" class="control-label">Field Name</label>
                                  <div class="controls">
                                    <input type="text" required value="<?=req('field')?>" name="field" id="focusedInput" class="input-large focused">
                                  </div>
                                </div>
                                <div class="control-group">
                                  <label for="focusedInput" class="control-label">Field Required</label>
                                  <div class="controls">
                                    <select name="required">
                                    <? foreach($requiredArray as $key=>$value){ ?>
                                    <option value="<?=$key?>"><?=$value?></option>
                                    <? }?>
                                    </select>
                                  </div>
                                </div>
                                <div class="control-group">
                                  <label for="focusedInput" class="control-label">Field Type</label>
                                  <div class="controls">
                                    <select name="type" class="focused" onchange="return getControl(this.value);">
									<?php foreach(control_list() as $type){?>
                                    <option value="<?php echo $type;?>"><?php echo ucfirst($type);?></option>
                                    <?php }?>
                                    </select>
                                  </div>
                                </div>
                                <span id="showOP"></span>
                                <span id="plug-edit-append"></span>
                                <div class="control-group">
                                <button type="button" id="add-new-position" style="display:none;" class="btn btn-primary offset7">Add New</button>
                                </div>
                                <div class="control-group">
                                <button type="submit" class="btn btn-success offset7" name="SaveControl">Save</button>&nbsp;<button class="btn btn-danger">Cancel</button>
                                </div>
                              </fieldset>                              
                            </form>
                        </div>
                    </div>
                    <div id="plug-edit-append-row" style="display:none;">
                     <div class="wid-form control-group">               
                       <label id="parent-control-label" class="control-label"></label>
                       <div class="controls">                           
                       <input type="text" name="value[]" class="input-large focused" required="required" />
                       &nbsp;&nbsp;&nbsp;<i class="icon-trash tooltip-top" onclick="$(this).parent('.controls').parent('.wid-form').remove()" data-original-title="Remove"></i>
                       </div>
                     </div>
                    </div>
                    <div id="plug-edit-append-row1" style="display:none;">
                     <div class="wid-form control-group">               
                       <label id="parent-control-label1" class="control-label"></label>
                       <div class="controls">                           
                       <input type="text" name="value[]" class="input-large focused" required="required" />
                       &nbsp;&nbsp;&nbsp;<i class="icon-trash tooltip-top" onclick="$(this).parent('.controls').parent('.wid-form').remove()" data-original-title="Remove"></i>
                       </div>
                     </div>
                    </div>
                    <div class="row-fluid">
                        <!-- block -->
                        <div class="block">
                            <div class="navbar navbar-inner block-header">
                                <div class="muted pull-left">Admission Controls</div>
                            </div>
                            <div class="block-content collapse in">
                                <div class="span12">
  									<table cellpadding="0" cellspacing="0" border="0" class="table table-striped table-bordered" id="example">
						              <thead>
						                <tr>
						                  <th>#</th>
						                  <th>Labels</th>
						                  <th>Fields</th>
                                          <th width="5%"><i class="icon-star"></i></th>
                                          <th width="15%">Satus</th>
						                  <th width="10%" style="text-align:center;">Action</th>
						                </tr>
						              </thead>
                                      <?php $sql = mysql_query("SELECT * FROM $fieldTable WHERE link_table='".$valueTable."'"); 
									  if(mysql_num_rows($sql)>0){?>
						              <tbody>
                                      <?php $i=0; while($fetch = mysql_fetch_object($sql)){ $i++; ?>
						                <tr>
						                  <td><?=$i?></td>
						                  <td><?php echo $fetch->label;?></td>
						                  <td><?php echo $fetch->field;?></td>
                                          <td><?php echo ($fetch->required==1)?'<i class="star">*</i>':'<i class="star_">*</i>';?></td>
                                          <td><?php echo ($fetch->status==1)?active():inactive();?></td>
						                  <td align="center" style="text-align:center;">
                                          <a data-toggle="modal" href="#myModal<?=$fetch->field_id?>"><i class="icon-edit tooltip-top" data-original-title="Edit"></i></a>&nbsp;&nbsp;
                                          <? if($fetch->status==1){ ?>
                                          <i class="icon-refresh tooltip-top" onclick="return inactiveMe('<?=$fetch->field_id?>');" data-original-title="De-Activate"></i>&nbsp;&nbsp;
                                          <? }else{?>
                                          <i class="icon-refresh tooltip-top" onclick="return activeMe('<?=$fetch->field_id?>');" data-original-title="Activate"></i>&nbsp;&nbsp;
                                          <? }?>
                                          <i class="icon-trash tooltip-top" onclick="return deleteMe('<?=$fetch->field_id?>');" data-original-title="Trash"></i>
                                          
                                        <div class="modal hide" id="myModal<?=$fetch->field_id?>" style="display: none;" aria-hidden="true">
                                            <div class="modal-header">
                                                <button type="button" class="close" data-dismiss="modal">�</button>
                                                <h3 align="left">Edit Student Field</h3>
                                            </div>
                                            <div class="modal-body">
                                                <form class="form-horizontal" method="post" enctype="multipart/form-data">
                                                  <fieldset>
                                                    <div class="control-group">
                                                      <label for="focusedInput" class="control-label">Lable Name</label>
                                                      <div class="controls">
                                                        <input type="text" value="<?=$fetch->label;?>" name="label" id="focusedInput" class="input-large focused">
                                                      </div>
                                                    </div>
                                                    <div class="control-group">
                                                      <label for="focusedInput" class="control-label">Field Name</label>
                                                      <div class="controls">
                                                        <input type="text" readonly="readonly" value="<?=$fetch->field;?>" name="field" id="focusedInput" class="input-large focused">
                                                      </div>
                                                    </div>
                                                    <div class="control-group">
                                                      <label for="focusedInput" class="control-label">Field Required</label>
                                                      <div class="controls">
                                                        <select name="required">
                                                        <? foreach($requiredArray as $key=>$value){ ?>
                                                        <option value="<?=$key?>" <? if($fetch->required==$key){?>selected="selected"<? }?>><?=$value?></option>
                                                        <? }?>
                                                        </select>
                                                      </div>
                                                    </div>
                                                    <div class="control-group">
                                                      <label for="focusedInput" class="control-label">Field Type</label>
                                                      <div class="controls">
                                                        <select name="type" class="input-large focused" onchange="return getControl1(this.value,'showOP<?=$fetch->field_id?>');">
                                                        <?php foreach(control_list() as $type){?>
                                                        <option value="<?php echo $type;?>" <?=($fetch->type==$type)?'selected="selected"':'';?>><?php echo ucfirst($type);?></option>
                                                        <?php }?>
                                                        </select>
                                                      </div>
                                                    </div>
                                                    <span id="showOP<?=$fetch->field_id?>">
                                                    <? 
													$display='none;';
													if($fetch->type=='radio' || $fetch->type=='checkbox' || $fetch->type=='select'){ 
													$display='block';
													$sqlF = mysql_query("SELECT * FROM tbl_field_option WHERE field_id=".$fetch->field_id);
													while($fetchIt = mysql_fetch_object($sqlF)){
													?>
                                                    <div class="wid-form control-group">    
                                                       <div class="controls">
                                                       <?
														echo ' <input type="text" class="input-large focused" name="value[]" value="'.$fetchIt->value.'">';
													   ?>
                                                      <i class="icon-trash tooltip-top" onclick="$(this).parent('.controls').parent('.wid-form').remove()" data-original-title="Remove"></i>
                                                       </div>
                                                     </div>
                                                     <? }}?>
                                                    </span>
                                                    <span id="plug-edit-append<?=$fetch->field_id?>"></span>
                                                    
                                                    <div class="control-group">
                                                    <button type="button" onclick="appendHtml(<?=$fetch->field_id?>);" style="display:<?=$display?>" class="btn btn-primary offset7">Add New</button>
                                                    </div>
                                                    
                                                    <div class="control-group">
                                                    <input type="hidden" name="field_id" value="<?=$fetch->field_id?>" />
                                                    <button type="submit" class="btn btn-success offset7" name="UpdateControl">Save</button>&nbsp;<button class="btn btn-danger">Cancel</button>
                                                    </div>
                                                  </fieldset>                              
                                                </form>
                                            </div>
                                        </div>
                                        </td>
						                </tr>
                                        <?php }?>
						              </tbody>
                                      <?php }?>
						            </table>
                                </div>
                            </div>
                        </div>
                        <!-- /block -->
                    </div>
                    
 </div>
 
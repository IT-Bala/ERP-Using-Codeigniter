<?php 
$fetchAssoc = array();
$sql = mysql_query("SELECT * FROM $valueTable");
while($fetch = mysql_fetch_assoc($sql)){ $fetchAssoc[] = $fetch; }

$unsetFields = array();
if(isset($unsetFields) && $unsetFields!=null){
foreach($unsetFields as $unsetField){
 unset($fetchAssoc[0][$unsetField]);
} }
?>
<div class="span10" id="content">
                    <div class="row-fluid">
                    <?=(isset($_SESSION['msg']))?$_SESSION['msg']:''?>
                        	<div class="navbar">
                            	<div class="navbar-inner">
	                                <ul class="breadcrumb">
	                                    <i class="icon-chevron-left hide-sidebar"><a href='#' title="Hide Sidebar" rel='tooltip'>&nbsp;</a></i>
	                                    <i class="icon-chevron-right show-sidebar" style="display:none;"><a href='#' title="Show Sidebar" rel='tooltip'>&nbsp;</a></i>
	                                    <li>
	                                        <a href="<?=$this->config->base_url()?>">Dashboard</a> <span class="divider">/</span>	
	                                    </li>
	                                    <li class="active"><?=ucfirst($module)?></li>
	                                </ul>
                            	</div>
                        	</div>
                    	</div>
                    <button class="btn btn-primary" onclick="document.location.href='<?=$base_url?>add'"><?=$add_button?></button>
                    <div class="row-fluid">
                        <!-- block -->
                        <div class="block">
                            <div class="navbar navbar-inner block-header">
                                <div class="muted pull-left"><?=$title?></div>
                            </div>
                            <?php $imageExt = array('jpg','png','jpeg','gif','svg','bmp'); ?>
                            <div class="block-content collapse in">
                                <div class="span12">
  									<table cellpadding="0" cellspacing="0" border="0" class="table table-striped table-bordered" id="example">
										<thead>
											<tr>
                                                <?php if(isset($fetchAssoc[0]) && count($fetchAssoc[0])>0){ foreach($fetchAssoc[0] as $field=>$obj){
													
												if(show_on_table($field)==1){	
												?>
												<th><?=$field?></th>                                                
                                                <?php }}}?>
                                                <th>Action</th>
											</tr>
										</thead>
										<tbody>
                                            <?php $status=''; for($i=0; $i<count($fetchAssoc); $i++){?>
											<tr class="odd gradeX">
                                                <?php 
												foreach($fetchAssoc[$i] as $field=>$values){
												 $sql = mysql_query("SELECT type FROM $fieldTable WHERE link_table='".$valueTable."' and field='".$field."'");
												 if($field=='status'){ $status=$values;
												   $values = ($values==1)?active():inactive();
												 }
												 if(mysql_num_rows($sql)>0 && $values!=''){
												   $fet = mysql_fetch_object($sql);
												   if($fet->type=='file'){
												   $ext = extension($values);
												   $icon = '<i class="icon-file">';
												   if(in_array($ext,$imageExt)){ $icon = '<i class="icon-picture">';  }
												   $values = '<a target="_blank" href="'.$this->config->base_url().'upload/'.$values.'">
												   '.$icon.'</a>';
												   }
												 }
												 if(!in_array($field,$unsetFields) && show_on_table($field)==1){
												?>
												<td><?=$values?></td>
                                                <?php }}?>
                                                <td>
                                                <? if($status==1){ ?>
                                                <i class="icon-refresh tooltip-top" onclick="return inactiveMe('<? echo($fetchAssoc[$i][$unique_id])?>');" data-original-title="De-Activate"></i>			<? }else{?>
                                                <i class="icon-refresh tooltip-top" onclick="return activeMe('<? echo($fetchAssoc[$i][$unique_id])?>');" data-original-title="Activate"></i>
                                                <? } ?>
                                                
                                                <a href="<?=$base_url?>edit/<? echo($fetchAssoc[$i][$unique_id])?>"><i class="icon-edit tooltip-top" data-original-title="Edit"></i></a>
                                                <i class="icon-trash tooltip-top" onclick="return deleteMe('<? echo($fetchAssoc[$i][$unique_id])?>');" data-original-title="Trash"></i>
                                                </td>
											</tr>
                                            <?php }?>
										</tbody>
									</table>
                              </div>
                            </div>
                        </div>
                        <!-- /block -->
                    </div>
                    
 </div>
 <?php if(isset($_SESSION['msg'])){ unset($_SESSION['msg']);} ?>
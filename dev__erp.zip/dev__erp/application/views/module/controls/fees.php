<div class="span10" id="content">
                    <div class="row-fluid">
                            <div class="navbar">
                               <div class="navbar-inner">
                                <div class="container-fluid">
                                    <div class="nav-collapse collapse">
                                        
                                        <ul class="nav">
                                            <li>
                                                <a href="<?=$base_url?>setting">Student Form</a>
                                            </li>
                                            <li class="active">
                                                <a href="<?=$base_url?>fees">Fees Form</a>
                                            </li>
                                        </ul>
                                    </div>
                                    <!--/.nav-collapse -->
                                </div>
                            </div>
                                            </div>
                    	</div>
                    <a class="btn btn-primary" data-toggle="modal" href="#myModal">Add New</a>
                    <div class="modal hide" id="myModal" style="display: none;" aria-hidden="true">
                        <div class="modal-header">
                            <button type="button" class="close" data-dismiss="modal">�</button>
                            <h3>Fees Field</h3>
                        </div>
                        <div class="modal-body">
                            <form class="form-horizontal">
                              <fieldset>
                                <div class="control-group">
                                  <label for="focusedInput" class="control-label">Lable Name</label>
                                  <div class="controls">
                                    <input type="text" value="" id="focusedInput" class="input-xlarge focused">
                                  </div>
                                </div>
                                <div class="control-group">
                                  <label for="focusedInput" class="control-label">Field Name</label>
                                  <div class="controls">
                                    <input type="text" value="" id="focusedInput" class="input-xlarge focused">
                                  </div>
                                </div>
                                <div class="control-group">
                                  <label for="focusedInput" class="control-label">Field Type</label>
                                  <div class="controls">
                                    <input type="text" value="" id="focusedInput" class="input-xlarge focused">
                                  </div>
                                </div>
                                <div class="control-group">
                                <button class="btn btn-success offset7">Save</button>&nbsp;<button class="btn btn-danger">Cancel</button>
                                </div>
                              </fieldset>
                              
                            </form>
                        </div>
                    </div>
                    <div class="row-fluid">
                        <!-- block -->
                        <div class="block">
                            <div class="navbar navbar-inner block-header">
                                <div class="muted pull-left">Admission Controls</div>
                            </div>
                            <div class="block-content collapse in">
                                <div class="span12">
  									<table class="table table-hover">
						              <thead>
						                <tr>
						                  <th>#</th>
						                  <th>Labels</th>
						                  <th>Fields</th>
						                  <th width="10%">Action</th>
						                </tr>
						              </thead>
						              <tbody>
						                <tr>
						                  <td>1</td>
						                  <td>Mark</td>
						                  <td>Otto</td>
						                  <td><i class="icon-edit tooltip-top" data-original-title="Edit"></i>&nbsp;&nbsp;<i class="icon-trash tooltip-top" data-original-title="Trash"></i></td>
						                </tr>
						              </tbody>
						            </table>
                                </div>
                            </div>
                        </div>
                        <!-- /block -->
                    </div>
                    
 </div>
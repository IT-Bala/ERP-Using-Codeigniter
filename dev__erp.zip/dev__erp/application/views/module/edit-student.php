<div class="span10" id="content">
                    <div class="row-fluid">
                        	<div class="navbar">
                            	<div class="navbar-inner">
	                                <ul class="breadcrumb">
	                                    <i class="icon-chevron-left hide-sidebar"><a href='#' title="Hide Sidebar" rel='tooltip'>&nbsp;</a></i>
	                                    <i class="icon-chevron-right show-sidebar" style="display:none;"><a href='#' title="Show Sidebar" rel='tooltip'>&nbsp;</a></i>
	                                    <li>
	                                        <a href="<?=$this->config->base_url()?>">Dashboard</a> <span class="divider">/</span>	
	                                    </li>
	                                    <li><a href="<?=$base_url?>"><?=ucfirst($module)?></a> <span class="divider">/</span></li>
                                        <li class="active">Update</li>
	                                </ul>
                            	</div>
                        	</div>
                    	</div>
                    
                    <div class="row-fluid">
                        <!-- block -->
                        <div class="block">
                            <div class="navbar navbar-inner block-header">
                                <div class="muted pull-left"><?=$title?></div>
                            </div>
                            <div class="block-content collapse in">
                                <div class="span12">
                                     <form class="form-horizontal" method="post" enctype="multipart/form-data">
                                      <fieldset>
                                        <legend><?=$subtitle?></legend>
                                        <?php 
										$sql = mysql_query("SELECT * FROM $fieldTable WHERE link_table='".$valueTable."' AND status=1");
										if(mysql_num_rows($sql)>0){
										$fetchVal = fetch_once("$valueTable","`$unique_id`=$edit_id");
										
										?>
                                        <?php 
										while($fetch = mysql_fetch_object($sql)){ $fieldVal = (string)$fetch->field;
										?>
                                        <div class="control-group">
                                          <label for="focusedInput" class="control-label"><?php echo $fetch->label;if($fetch->required==1){?><i class="star">*</i><?php }?></label>
                                          <div class="controls">
                                          <?php echo showControl($fetch->type,$fetch->field,$fetch->label,$fetch->field_id,$fetchVal->$fieldVal,$fetch->required);?>
                                          </div>
                                        </div>
                                        <?php }}?>
                                        <div class="form-actions">
                                          <button class="btn btn-primary" name="UpdateStudent" type="submit">Save changes</button>
                                          <a href="<?=$base_url?>" class="btn">Back</a>
                                        </div>
                                      </fieldset>
                                    </form>

                                </div>
                            </div>
                        </div>
                        <!-- /block -->
                    </div>
                    
 </div>
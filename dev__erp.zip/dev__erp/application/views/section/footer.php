</div>
<hr>
<footer>
    <p class="text-center">&copy; Dev__ Frame. 2016</p>
</footer>
<div id="myProfile" class="modal fade" role="dialog">
  <div class="modal-dialog">

    <!-- Modal content-->
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal">&times;</button>
        <h4 class="modal-title">Edit Profile</h4>
      </div>
      <div class="modal-body">
        <input type="text" name="username" placeholder="Enter Username..." />
        <input type="password" name="password" placeholder="Enter Password..." />
        <input type="email" name="email" placeholder="Enter Email..." />
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
      </div>
    </div>

  </div>
</div>
<form method="post">
<input type="hidden" name="delete_id" id="delete_id" />
<input type="submit" style="display:none" id="submit_delete" />
</form>
<form method="post">
<input type="hidden" name="active_id" id="active_id" />
<input type="submit" style="display:none" id="submit_active" />
</form>
<form method="post">
<input type="hidden" name="inactive_id" id="inactive_id" />
<input type="submit" style="display:none" id="submit_inactive" />
</form>             
</div>
<?php $base_url = $this->config->base_url();  ?>
<script src="<?=$base_url?>vendors/jquery-1.11.1.js"></script>
<script src="<?=$base_url?>assets/js/custom.js"></script>
<script>
$('.number').keyup(function() {
    $('span.error-keyup-1').hide();
    var inputVal = $(this).val();
    var numericReg = /^\d*[0-9](|.\d*[0-9]|,\d*[0-9])?$/;
    if(!numericReg.test(inputVal)) {
        $(this).after('<span class="error error-keyup-1">Numeric characters only.</span>');
    }
});
function makeAjax(){
	var xml = null;
	if(window.XMLHttpRequest){
		xml = new XMLHttpRequest;
	}else{// code for IE6, IE5
		xml = new ActiveXObject("Microsoft.XMLHTTP");
	  }
	return xml;
}
	
function __doAjax(url,showId,clickId){ alert();
	
}
function getChainTableField(parentId,table){ 
	var ajax = makeAjax();
	if(table!=''){ 
	$("#"+parentId+"Type").val("select");
	$("#"+parentId+"Type").attr('disabled', true);
	$("#"+parentId+"addMore").attr('disabled', true);
	$('#'+parentId).show(); // .controls
	var url = 'chain_table_fields?table='+table;		 
	ajax.open("POST",url,true);
	ajax.send();		 
	ajax.onreadystatechange=function(){
	if(ajax.readyState){
		 $('#'+parentId+' > .controls').html(ajax.responseText);
		}
	 }
	}else{
	   $("#"+parentId+"addMore").attr('disabled', false);
	   $("#"+parentId+"Type").attr('disabled', false);
	  $('#'+parentId+' > .controls').html();
	  $('#'+parentId).hide();
	}
}
function getAjaxTableField(parentId,table){
	var ajax = makeAjax();  
	if(table!=''){ 
	$("#"+parentId+"Type").val("select");
	$("#"+parentId+"Type").attr('disabled', true);
	$("#"+parentId+"addMore").attr('disabled', true);
	$('#'+parentId).show(); // .controls
	var url = 'chain_table_fields?table='+table+'&variable=ajax_field';		 
	ajax.open("POST",url,true);
	ajax.send();		 
	ajax.onreadystatechange=function(){
	if(ajax.readyState){
		 $('#'+parentId+' > .controls').html(ajax.responseText);
		}
	 }
	}else{
	   $("#"+parentId+"addMore").attr('disabled', false);
	   $("#"+parentId+"Type").attr('disabled', false);
	  $('#'+parentId+' > .controls').html();
	  $('#'+parentId).hide();
	}
}
function getControl(type){ $('#add-new-position').hide();
 $('#plug-edit-append').empty();
if(type!='text' && type!='number' && type!='password' && type!='textarea' && type!='file' && type!='date' && type!='time' && type!='datetime'){
 // if(type=='radio' && type=='checkbox' && type=='select' && type=='multiple-select'){
    if(type=='radio'){ $('#parent-control-label').html('<input type="radio">');}
    if(type=='checkbox'){ $('#parent-control-label').html('<input type="checkbox">');}
    if(type=='select'){ $('#parent-control-label').html('Option:');}
    $('#add-new-position').show();
}
var ajax = makeAjax();  
var url = 'control_type?type='+type;		 
ajax.open("POST",url,true);
ajax.send();		 
ajax.onreadystatechange=function(){
if(ajax.readyState){
     document.getElementById('showOP').innerHTML=ajax.responseText;
    }
 }
}
function getControl1(type,showDiv){ $('#add-new-position1').hide();
 $('#plug-edit-append1').empty();
	if(type!='text' && type!='number' && type!='password' && type!='textarea' && type!='file' && type!='date' && type!='time' && type!='datetime'){
    if(type=='radio'){ $('#parent-control-label1').html('<input type="radio">');}
    if(type=='checkbox'){ $('#parent-control-label1').html('<input type="checkbox">');}
    if(type=='select'){ $('#parent-control-label1').html('Option:');}
    $('#add-new-position1').show();
}
var ajax = makeAjax();  
var url = 'control_type1?type='+type;		 
ajax.open("POST",url,true);
ajax.send();		 
ajax.onreadystatechange=function(){
if(ajax.readyState){
     document.getElementById(showDiv).innerHTML=ajax.responseText;
    }
 }
}
$(document).ready(function(e) {  // SELECT BOX ADD
// Add
$("#add-new-position").click(function(){ 
        var appendRow = $("#plug-edit-append-row").html();
        $("#plug-edit-append").append(appendRow);
    });
// Edit  
});

function appendHtml(id){
var appendRow = $("#plug-edit-append-row1").html();
$("#plug-edit-append"+id).append(appendRow);
}

function deleteMe(id){
	if(confirm("Are you sure want to delete?")){
	$('#delete_id').val(id);
	$('#submit_delete').click();
	}else{ return false;
	}
}
function activeMe(id){
	if(confirm("Are you sure want to active?")){
	$('#active_id').val(id);
	$('#submit_active').click();
	}else{ return false;
	}
}
function inactiveMe(id){
	if(confirm("Are you sure want to de-active?")){
	$('#inactive_id').val(id);
	$('#submit_inactive').click();
	}else{ return false;
	}
}
function dynamicAjax(table,field,value,showId){ // Dynamic ajax control
	var ajax = makeAjax();  
	var url = '<?=$base_url?>index.php/dynamic/ajax/'+table+'/'+field+'/'+value+'/'+showId;		 
	ajax.open("POST",url,true);
	ajax.send();		 
	ajax.onreadystatechange=function(){
	if(ajax.readyState){
		if($('input#'+showId)){ 
			$('input#'+showId).val(ajax.responseText);
		}else {
			$('#'+showId).html(ajax.responseText);
		}
		 //document.getElementById(showId).value=ajax.responseText; // Type of 
		}
	 }
}
function editPop(showId,url){ // Dynamic ajax control
	var ajax = makeAjax();  
	var url = url;		 
	ajax.open("POST",url,true);
	ajax.send();		 
	ajax.onreadystatechange=function(){
	if(ajax.readyState){
			$('#'+showId).html(ajax.responseText);
		 //document.getElementById(showId).value=ajax.responseText; // Type of 
		}
	 }
}
</script>

    <?php 
	if((uri_string()!='enquiry/add') && ($this->uri->segment(1)!='enquiry' or $this->uri->segment(2)!='edit')){ # Because webcam will be conflict
	?>
    <!--<script src="<?=$base_url?>vendors/jquery-1.9.1.min.js"></script>-->
    
    <script src="<?=$base_url?>bootstrap/js/bootstrap.min.js"></script>
    <!--<script src="<?=$base_url?>vendors/easypiechart/jquery.easy-pie-chart.js"></script>
    <script src="<?=$base_url?>vendors/jGrowl/jquery.jgrowl.js"></script>-->
    
    <script src="<?=$base_url?>assets/scripts.js"></script>
    <script>
	// Export Print options 
	// ========================= // FIELD COOKIE VALUE //
	var fieldArrayKey = document.getCookie('fields_key');
	var fieldArrayKeyStr = '{"fieldKey" : ['+fieldArrayKey+']}';
	var obj = jQuery.parseJSON(fieldArrayKeyStr);	
	var printThisKeyField = obj.fieldKey;
	// ========================= // HIDE FIELDS // SESSION DATA
	
	var hideFieldStr = '{"targetKey": [<?=$_SESSION['hide_field']?>]}';
	var Hobj = jQuery.parseJSON(hideFieldStr);	
	var target = Hobj.targetKey;
	
	//alert(printThisKeyField);
	if(fieldArrayKey!=''){ // If choosed field
	  /*$(document).ready(function(){
		$('#example').DataTable( {
			dom: 'T<"clear">lfrtip',
			tableTools: {				
				"sSwfPath": "<?=$base_url?>assets/copy_csv_xls_pdf.swf",
				
				"aButtons": [
					{
						"sExtends":    "collection",
						"sButtonText": "<i class='icon-print'></i>",
						"aButtons":    [ 
							{
								"sExtends": "copy",
								"sButtonText": "Copy",
								"mColumns": printThisKeyField
							},
							{
								"sExtends": "csv",
								"sButtonText": "CSV",
								"mColumns": printThisKeyField
							},
							{
								"sExtends": "xls",
								"sButtonText": "Excel",
								"mColumns": printThisKeyField
							},
							{
								"sExtends": "pdf",
								"sButtonText": "PDF",
								"mColumns": printThisKeyField
							}
						]
					}
					
            	]
			},
			"columnDefs": [
				{
					"targets": target,
					"visible": false,
					"searchable": false
				}
			]
			
		} );
	} ); */
	}else{ // If not choosed field
	  $(document).ready(function(){
		$('#example').DataTable( {
			// Export Options
			"columnDefs": [
				{
					"targets": target,
					"visible": false,
					"searchable": false
				}
			],
			dom: 'T<"clear">lfrtip',
			tableTools: {				
				"sSwfPath": "<?=$base_url?>assets/copy_csv_xls_pdf.swf",
				// If We can choose button EXT with button
				"aButtons": [
                {
                    "sExtends":    "collection",
                    "sButtonText": "<i class='icon-print'></i>",
                    "aButtons":    [ "csv", "xls", "pdf", "copy", "print" ]
                }
            	]
			}
			
		} );
	} );
	}
	
	
	/*$(document).ready(function() { 		
		$('#examplepop').DataTable( {
			// Export Options
			dom: 'T<"clear">lfrtip',
			tableTools: {				
				"sSwfPath": "<?=$base_url?>assets/copy_csv_xls_pdf.swf",
				// If We can choose button EXT with button
			}
			
		});
	});*/
	
	
    $(function(){  
	//	$(".datepicker").  format: 'yyyy-mm-dd' });
		
        
    });
    // Tooltip
    $(function() {
        $('.tooltip').tooltip();	
        $('.tooltip-left').tooltip({ placement: 'left' });	
        $('.tooltip-right').tooltip({ placement: 'right' });	
        $('.tooltip-top').tooltip({ placement: 'top' });	
        $('.tooltip-bottom').tooltip({ placement: 'bottom' });

        $('.popover-left').popover({placement: 'left', trigger: 'hover'});
        $('.popover-right').popover({placement: 'right', trigger: 'hover'});
        $('.popover-top').popover({placement: 'top', trigger: 'hover'});
        $('.popover-bottom').popover({placement: 'bottom', trigger: 'hover'});

        $('.notification').click(function() {
            var $id = $(this).attr('id');
            switch($id) {
                case 'notification-sticky':
                    $.jGrowl("Stick this!", { sticky: true });
                break;

                case 'notification-header':
                    $.jGrowl("A message with a header", { header: 'Important' });
                break;

                default:
                    $.jGrowl("Hello world!");
                break;
            }
        });
    });
    </script>
    
    <?php if(!home() && basename(uri_string())!='setting'){ #  ?>
    <script src="<?=$base_url?>DataTables/media/js/jquery.js"></script>
    <script src="<?=$base_url?>DataTables/media/js/jquery.dataTables.js"></script> 
    <script src="<?=$base_url?>DataTables/media/js/dataTables.tableTools.js"></script> 
    
    <script src="<?=$base_url?>DataTables/media/js/dataTables.bootstrap.js"></script> 
    <script type="text/javascript" language="javascript" src="<?=$base_url?>DataTables/examples/resources/syntax/shCore.js"></script>
    <script type="text/javascript" language="javascript" src="<?=$base_url?>DataTables/examples/resources/demo.js"></script>
    <link href="<?=$base_url?>vendors/datepicker.css" rel="stylesheet" media="screen">
    <script src="<?=$base_url?>vendors/bootstrap-datepicker.js"></script>
    <link href="<?=$base_url?>bootstrap/css/timepicki.css" rel="stylesheet">
    <?php echo 
    '<script src="'.$base_url.'bootstrap/js/timepicki.js"></script>
	<script src="'.$base_url.'bootstrap/js/datetimepicker.js?t=20130302"></script>
	<link href="'.$base_url.'bootstrap/css/datetimepicker.css" rel="stylesheet">
    <script>
	$(".timepicker").timepicki();
	 $(".form_datetime").datetimepicker({
        format: "dd MM yyyy - HH:ii P",
        showMeridian: true,
        autoclose: true,
        todayBtn: true
    });
    </script>
    ';
    ?>
    
    <?php }else{?>
    <script src="<?=$base_url?>vendors/datatables/js/jquery.dataTables.min.js"></script>
	<script src="<?=$base_url?>assets/scripts.js"></script>
    <script src="<?=$base_url?>assets/DT_bootstrap.js"></script>
    <?php }?>
    <script type="text/javascript" language="javascript" class="init">
        $(document).ready(function() {
            $('#example tfoot th').each( function () {
                var title = $('#example thead th').eq( $(this).index() ).text();
                $(this).html( '<input type="text" placeholder="Search '+title+'" />' );
            } );
        
            // DataTable
            var table = $('#example').DataTable();
        
            // Apply the search for multiple option 
            /*table.columns().eq( 0 ).each( function ( colIdx ) {
                $( 'input', table.column( colIdx ).footer() ).on( 'keyup change', function () {
                    table
                        .column( colIdx )
                        .search( this.value )
                        .draw();
                } );
            } );*/
     });
	 
	  $(function() {
            $(".datepicker").datepicker({ format: 'dd-mm-yyyy',autoclose: true });
            $(".uniform_on").uniform();
            $(".chzn-select").chosen();
            $('.textarea').wysihtml5();

            $('#rootwizard').bootstrapWizard({onTabShow: function(tab, navigation, index) {
                var $total = navigation.find('li').length;
                var $current = index+1;
                var $percent = ($current/$total) * 100;
                $('#rootwizard').find('.bar').css({width:$percent+'%'});
                // If it's the last tab then hide the last button and show the finish instead
                if($current >= $total) {
                    $('#rootwizard').find('.pager .next').hide();
                    $('#rootwizard').find('.pager .finish').show();
                    $('#rootwizard').find('.pager .finish').removeClass('disabled');
                } else {
                    $('#rootwizard').find('.pager .next').show();
                    $('#rootwizard').find('.pager .finish').hide();
                }
            }});
            $('#rootwizard .finish').click(function() {
                alert('Finished!, Starting over!');
                $('#rootwizard').find("a[href*='tab1']").trigger('click');
            });
        });
    </script>
   
    <?php }?>
  
  <?php $base_url = $this->config->base_url();   
echo '<script type="text/javascript" src="'.$base_url.'assets/field-design/jquery-1.4.2.min.js"></script>
<script type="text/javascript" src="'.$base_url.'assets/field-design/jquery-ui-1.8.custom.min.js"></script>
<script type="text/javascript" src="'.$base_url.'assets/field-design/jquery.cookie.js"></script>
<link rel="stylesheet" type="text/css" href="'.$base_url.'assets/field-design/style.css" media="screen" />';

$page_url=current_url();
?>

<script type="text/javascript">

$(document).ready(function(){

	// Get items
	function getItems(exampleNr){
		
		var columns = [];
		$(exampleNr + ' ul.sortable-list').each(function(){
			var dataColumn = $(this).attr("data-column");
			columns [dataColumn]     = $(this).sortable('toArray').join(',');
			//columns.push($(this).sortable('toArray').join(','));				
		});
		return columns;
		//return columns.join('|'); // Join Sorting Values Using Array
	}


	// Example 2.1: Get items
	$('#example-2-1 .sortable-list').sortable({
		connectWith: '#example-2-1 .sortable-list'
	});

	$('#btn-get').click(function(){ // Ajax Sent Values And Id's 
		// Using PHP File
		var args = getItems('#example-2-1');
		
		$.ajax({url: "<?=$page_url?>/../field_sort", data:{argument:args}, success: function(result){
			var alertt = '<div class="alert alert-success"><strong>Well done!</strong> Fields has been updated successfully.</div>';
			$("#op").html(alertt);			
		}});
		
	});

});

</script>
 
    </body>

</html>
<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Dynamic extends CI_Controller {
	 
	public function index(){  
	  print_r($_REQUEST);   
	}
	public function ajax(){ $args = func_get_args();
	  if(count($args)==4){ $table=$args[0]; $field=$args[1]; $value=$args[2]; $showId=$args[3];
	  
	     $value = str_replace('%20',' ',$value);
	  		 
		 $sqlQ = mysql_query("SELECT * FROM ".$table." WHERE ".$field."='".$value."'");
		 if(mysql_num_rows($sqlQ)){
		 $fetch = mysql_fetch_object($sqlQ);
		 echo $fetch->$showId;
		 }
	  }
	}
}

/* End of file welcome.php */
/* Location: ./application/controllers/welcome.php */
// SELECT * FROM tbl_icr WHERE icr_no=ICR%2005
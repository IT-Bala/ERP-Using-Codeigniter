<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Login extends CI_Controller {

	public function index()
	{
		session_start();
		$this->load->helper('built');
		 $this->load->model('login_model');
		 $msg= $this->login_model->doLogin();
		 $data['msg']= $msg;
		 #header("location:../");
		
		
	    $data['title']= 'Login';
	    //$this->load->view('section/header.php',$data);
		$this->load->view('login',$data);
		//$this->load->view('section/footer.php');
	}
	public function logout(){ session_start();
	    $base_url = $this->config->base_url();
		$data['title']= 'Login';
		unset($_SESSION['user']);
		header("location: ".$base_url."index.php/login");
		#$this->load->view('login',$data);
	}
}

/* End of file welcome.php */
/* Location: ./application/controllers/welcome.php */
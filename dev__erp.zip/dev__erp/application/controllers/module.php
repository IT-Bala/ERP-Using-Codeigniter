<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Module extends CI_Controller {
	 public $dataSet=array('module'=>'module','model'=>'module_model','fieldTable'=>'tbl_fields','valueTable'=>'tbl_modules','optionTable'=>'tbl_field_option','unique_id'=>'module_id');
	
	 
	public function index(){  
	    $data = $this->dataSet;
		$data['base_url'] = $this->config->base_url().'index.php/'.$this->dataSet['module'].'/'; 
	    $data['title']       = 'Modules List';
		$data['add_button']  = 'Add New Module';
		$data['delete_msg']  = 'Module has been deleted successfully!';
		$data['active_msg']  = 'Module has been activated successfully!';
		$data['deactive_msg']= 'Module has been de-activated successfully!';
	    $this->load->view('section/header.php',$data); 
		$this->load->model($this->dataSet['model']);
		$model = $this->dataSet['model'];
		$this->$model->index($data);
		$this->load->view($this->dataSet['module'].'/index',$data);
		$this->load->view('section/footer.php');
	}
	public function add(){
	    $data = $this->dataSet;
		$data['base_url'] = $this->config->base_url().'index.php/'.$this->dataSet['module'].'/';
	    $data['title']= 'Add New Module';
		$data['subtitle']= 'Enter Module Information';
		$data['message']= 'New module has been created successfully!';
		$this->load->model($this->dataSet['module'].'_model');
	    $this->load->view('section/header.php',$data);
		$model = $this->dataSet['model'];
		$this->$model->add($data);
		$this->load->view($this->dataSet['module'].'/add-student.php');
		$this->load->view('section/footer.php');
	}
	public function edit(){ $args = func_get_args();
	    if(count($args[0])==0){ show_404('log_error');}else{
	    $data = $this->dataSet;
		$data['base_url'] = $this->config->base_url().'index.php/'.$this->dataSet['module'].'/';
	    $data['edit_id']=$args[0];
	    $data['title']= 'Edit Module';
		$data['subtitle']= 'Update Module Information';
		$data['message']= 'Module has been updated successfully!';
		$this->load->model($this->dataSet['module'].'_model');
	    $this->load->view('section/header.php',$data);
		$model = $this->dataSet['model'];
		$this->$model->update($data);
		$this->load->view($this->dataSet['module'].'/edit-student.php');
		$this->load->view('section/footer.php');
		}
	}
	public function setting(){
	    $data = $this->dataSet; 
	    $args = func_get_args();
	    $data['base_url'] = $this->config->base_url().'index.php/'.$this->dataSet['module'].'/';
	    $data['title']= $this->dataSet['module'].' Controls';
		$data['add_title']= 'Add '.ucfirst($this->dataSet['module']).' Field'; // add_title
		$data['edit_title']= 'Edit '.ucfirst($this->dataSet['module']).' Field'; // edit_title
	    $this->load->view('section/header.php',$data);
		$this->load->view($this->dataSet['module'].'/controls/setting.php');
		$this->load->view('section/footer.php');
	}
	public function chain_table_fields(){
	    $data = $this->dataSet; 
	    $args = func_get_args();
	    $data['base_url'] = $this->config->base_url().'index.php/'.$this->dataSet['module'].'/';
		$this->load->view($this->dataSet['module'].'/controls/chain_table_fields.php');
	}
	public function control_type(){
	    $data = $this->dataSet; 
	    $args = func_get_args();
	    $data['base_url'] = $this->config->base_url().'index.php/'.$this->dataSet['module'].'/';
		$this->load->view($this->dataSet['module'].'/controls/control_type.php');
	}
	public function control_type1(){
	    $data = $this->dataSet; 
	    $args = func_get_args();
	    $data['base_url'] = $this->config->base_url().'index.php/'.$this->dataSet['module'].'/';
		$this->load->view($this->dataSet['module'].'/controls/control_type1.php');
	}
}

/* End of file welcome.php */
/* Location: ./application/controllers/welcome.php */
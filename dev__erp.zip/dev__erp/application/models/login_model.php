<?php
class Login_model extends CI_Model{
	 public function doLogin(){ extract($_POST); $msg='';
		  if(isset($_POST['Login'])){
		   $sql = mysql_query("SELECT * FROM tbl_admin WHERE username='".$username."' AND password='".$password."'");
		   $sql1 = mysql_query("SELECT * FROM tbl_user WHERE username='".$username."' AND password='".$password."' AND status=1");
		   if(mysql_num_rows($sql)==1 or mysql_num_rows($sql1)==1){
			   if(mysql_num_rows($sql)==1){
			   $_SESSION['user'] = fetch_once("tbl_admin","username='".$username."' AND password='".$password."'");
			   }
			   if(mysql_num_rows($sql1)==1){
			   $_SESSION['user'] = fetch_once("tbl_user","username='".$username."' AND password='".$password."'");
			   }
			   $msg = success("Login Successfully!");
			   header("location:../");
		   }else{
			   $msg = error("Wrong username and password/Your account may de-activated!");
		   } 
		  } return $msg;
	 }
}
?>
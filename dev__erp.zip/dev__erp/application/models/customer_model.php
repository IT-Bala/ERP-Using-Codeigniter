<?php
class Customer_model extends CI_Model{
	public function index($datas){ extract($datas);
			if(isset($_POST['delete_id'])){
			  mysql_query("DELETE FROM $valueTable WHERE $unique_id=".$_POST['delete_id']);
			  $_SESSION['msg'] = success($delete_msg);
			}
			if(isset($_POST['active_id'])){
			  mysql_query("UPDATE $valueTable SET status=1 WHERE $unique_id=".$_POST['active_id']);
			  $_SESSION['msg'] = success($active_msg);
			}
			if(isset($_POST['inactive_id'])){
			  mysql_query("UPDATE $valueTable SET status=0 WHERE $unique_id=".$_POST['inactive_id']);
			  $_SESSION['msg'] = success($deactive_msg);
			}
	}
	 public function add($datas){ extract($datas);
		 	$msg='';
			$fields = $types = array();
			$select = mysql_query("SELECT * FROM $fieldTable WHERE link_table='".$valueTable."' and status=1"); while($fet = mysql_fetch_object($select)){ $fields[] = $fet->field; $types[] = $fet->type;}
			if(isset($_POST['SaveStudent'])){ $fieldsVal=array();
			   foreach($fields as $key=>$field){
				   if($types[$key]=='file'){  
					if($_FILES[$field]['name']!=''){
					$file = rand(100,10).time().$_FILES[$field]['name'];
					move_uploaded_file($_FILES[$field]['tmp_name'],'upload/'.$file);
					$fieldsVal[] = "$field='".mysql_real_escape_string($file)."'";
					}
				   }elseif($types[$key]=='radio'){  
					$fieldsVal[] = "$field='".implode(',',$_POST[$field])."'";
					
				   }elseif($types[$key]=='checkbox'){
					$fieldsVal[] = "$field='".implode(',',$_POST[$field])."'";
					
				   }else{
					$fieldsVal[] = "$field='".mysql_real_escape_string($_POST[$field])."'";
				   }
			   }
			   mysql_query("INSERT INTO $valueTable set ".implode(',',$fieldsVal));
			   $_SESSION['msg'] = success($message);
			   header("location:".$base_url);
			} 
	 }
	 public function update($datas){ extract($datas);
		    $msg='';
			$fields = $types = array();
			$select = mysql_query("SELECT * FROM $fieldTable WHERE link_table='".$valueTable."' and status=1"); while($fet = mysql_fetch_object($select)){ $fields[] = $fet->field; $types[] = $fet->type;}
			if(isset($_POST['UpdateStudent'])){ $fieldsVal=array();
			   foreach($fields as $key=>$field){
				   if($types[$key]=='file'){  
					if($_FILES[$field]['name']!=''){
					$file = rand(100,10).time().$_FILES[$field]['name'];
					move_uploaded_file($_FILES[$field]['tmp_name'],'upload/'.$file);
					$fieldsVal[] = "$field='".mysql_real_escape_string($file)."'";
					}else{
					 $file = $_POST['_'.$field];
					 $fieldsVal[] = "$field='".mysql_real_escape_string($file)."'";
					}
				   }elseif($types[$key]=='radio'){  
					$fieldsVal[] = "$field='".implode(',',$_POST[$field])."'";
					
				   }elseif($types[$key]=='checkbox'){
					$fieldsVal[] = "$field='".implode(',',$_POST[$field])."'";
					
				   }else{
					$fieldsVal[] = "$field='".mysql_real_escape_string($_POST[$field])."'";
				   }
			   }
			   mysql_query("UPDATE $valueTable SET ".implode(',',$fieldsVal)." WHERE $unique_id=".$edit_id);
			   $_SESSION['msg'] = success($message);
			   header("location:".$base_url);
			}
	 }
}
?>
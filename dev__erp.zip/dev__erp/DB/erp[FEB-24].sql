-- phpMyAdmin SQL Dump
-- version 4.5.1
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Feb 24, 2016 at 11:27 AM
-- Server version: 10.1.9-MariaDB
-- PHP Version: 5.5.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `erp`
--

-- --------------------------------------------------------

--
-- Table structure for table `tbl_admin`
--

CREATE TABLE `tbl_admin` (
  `user_id` int(11) NOT NULL,
  `username` varchar(255) NOT NULL,
  `password` text NOT NULL,
  `type` int(11) NOT NULL,
  `status` tinyint(4) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_admin`
--

INSERT INTO `tbl_admin` (`user_id`, `username`, `password`, `type`, `status`) VALUES
(1, 'admin', 'admin', 1, 0);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_fields`
--

CREATE TABLE `tbl_fields` (
  `field_id` int(11) NOT NULL,
  `link_table` varchar(255) NOT NULL,
  `label` varchar(255) NOT NULL,
  `field` varchar(255) NOT NULL,
  `type` varchar(255) NOT NULL,
  `required` tinyint(11) NOT NULL,
  `show_on_table` tinyint(4) NOT NULL DEFAULT '1',
  `field_column` tinyint(4) NOT NULL DEFAULT '1',
  `chain_table` varchar(255) NOT NULL,
  `chain_table_field` varchar(255) NOT NULL,
  `ajax_table` varchar(255) NOT NULL,
  `ajax_field` varchar(255) NOT NULL,
  `ajax_call_id` varchar(255) NOT NULL,
  `ajax_type` varchar(255) NOT NULL,
  `sorting` int(11) NOT NULL,
  `status` int(11) NOT NULL DEFAULT '1'
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COMMENT='tbl_students_field';

--
-- Dumping data for table `tbl_fields`
--

INSERT INTO `tbl_fields` (`field_id`, `link_table`, `label`, `field`, `type`, `required`, `show_on_table`, `field_column`, `chain_table`, `chain_table_field`, `ajax_table`, `ajax_field`, `ajax_call_id`, `ajax_type`, `sorting`, `status`) VALUES
(8, 'tbl_user', 'User Name', 'username', 'text', 1, 1, 1, '', '', '', '', '', '', 0, 1),
(10, 'tbl_user', 'Password', 'password', 'text', 1, 1, 1, '', '', '', '', '', '', 0, 1),
(11, 'tbl_user', 'Age', 'age', 'text', 0, 1, 1, '', '', '', '', '', '', 0, 1),
(68, 'tbl_modules', 'Add To Left Menu', 'left_menu', 'select', 0, 1, 1, '', '', '', '', '', 'onchange', 0, 1),
(60, 'tbl_user', 'Access Module', 'access_module', 'multiple-select', 0, 1, 1, 'tbl_modules', 'module', '', '', '', 'onchange', 0, 1),
(61, 'tbl_modules', 'Module', 'module', 'text', 1, 1, 1, '', '', '', '', '', 'onchange', 0, 1),
(62, 'tbl_modules', 'Controller', 'controller', 'text', 1, 1, 1, '', '', '', '', '', 'onchange', 0, 1),
(63, 'tbl_modules', 'Module Table', 'table_name', 'text', 1, 1, 1, '', '', '', '', '', 'onchange', 0, 1),
(64, 'tbl_modules', 'Table Primary Key', 'table_id', 'text', 0, 1, 1, '', '', '', '', '', 'onchange', 0, 1),
(65, 'tbl_modules', 'Sorting', 'sorting', 'text', 0, 1, 1, '', '', '', '', '', 'onchange', 0, 1),
(91, 'tbl_wages', 'Wage Items', 'wage_item', 'text', 0, 1, 3, '', '', '', '', '', 'onchange', 0, 1),
(92, 'tbl_wages', 'Wages Time', 'wage_time', 'time', 1, 1, 1, '', '', '', '', '', 'onchange', 0, 1),
(93, 'tbl_employee', 'name', 'name', 'text', 0, 1, 1, '', '', '', '', '', '', 0, 1),
(89, 'tbl_wages', 'wages name', 'wage_name', 'text', 1, 1, 1, '', '', '', '', '', 'onchange', 0, 1),
(90, 'tbl_wages', 'Wage Desc', 'wage_desc', 'text', 0, 1, 2, '', '', '', '', '', 'onchange', 0, 1),
(80, 'tbl_modules', 'Column', 'column', 'number', 0, 0, 1, '', '', '', '', '', 'onchange', 0, 1);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_field_option`
--

CREATE TABLE `tbl_field_option` (
  `field_option_id` int(11) NOT NULL,
  `field_id` int(11) NOT NULL,
  `value` text NOT NULL,
  `status` tinyint(4) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_field_option`
--

INSERT INTO `tbl_field_option` (`field_option_id`, `field_id`, `value`, `status`) VALUES
(35, 74, 'Female', 0),
(34, 74, 'Male', 0),
(33, 68, 'Yes', 0),
(30, 41, 'yes', 0),
(31, 41, 'no', 0);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_modules`
--

CREATE TABLE `tbl_modules` (
  `module_id` int(11) NOT NULL,
  `status` tinyint(4) NOT NULL,
  `module` text NOT NULL,
  `controller` text NOT NULL,
  `table_name` text NOT NULL,
  `table_id` text NOT NULL,
  `sorting` text NOT NULL,
  `left_menu` text NOT NULL,
  `column` tinyint(4) NOT NULL DEFAULT '1'
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_modules`
--

INSERT INTO `tbl_modules` (`module_id`, `status`, `module`, `controller`, `table_name`, `table_id`, `sorting`, `left_menu`, `column`) VALUES
(22, 0, 'Wages Management', 'Wages', 'tbl_wages', 'wage_id', '1', 'Yes', 3);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_module_creator`
--

CREATE TABLE `tbl_module_creator` (
  `creator_id` int(11) NOT NULL,
  `controller_code` text NOT NULL,
  `model_code` text NOT NULL,
  `status` tinyint(4) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_module_creator`
--

INSERT INTO `tbl_module_creator` (`creator_id`, `controller_code`, `model_code`, `status`) VALUES
(1, '<?php if ( ! defined(''BASEPATH'')) exit(''No direct script access allowed'');\r\n\r\nclass Sample_c extends CI_Controller {\r\n	 public $dataSet=array(''module''=>''Sample_c'',''model''=>''Sample_c_model'',''fieldTable''=>''tbl_fields'',''valueTable''=>''put_table_name'',''optionTable''=>''tbl_field_option'',''unique_id''=>''put_table_id'');\r\n	\r\n	public function index(){ \r\n	    $data = $this->dataSet;\r\n		$data[''base_url''] = $this->config->base_url().''index.php/''.$this->dataSet[''module''].''/''; \r\n	    $data[''title'']       = ''Sample_t List'';\r\n		$data[''subtitle'']    = ''Enter Sample_t Information'';\r\n		$data[''add_button'']  = ''Add New Sample_t'';\r\n		$data[''add_title'']   = ''Add New Sample_t'';\r\n		$data[''edit_title'']  = ''Edit Sample_t'';\r\n		$data[''delete_msg'']  = ''Sample_t has been deleted successfully!'';\r\n		$data[''active_msg'']  = ''Sample_t has been activated successfully!'';\r\n		$data[''deactive_msg'']= ''Sample_t has been de-activated successfully!'';\r\n	    $this->load->view(''section/header.php'',$data);\r\n		$this->load->model($this->dataSet[''model'']);\r\n		$model = $this->dataSet[''model''];\r\n		$this->$model->index($data);\r\n		$this->load->view($this->dataSet[''module''].''/index'',$data);\r\n		$this->load->view(''section/footer.php'');\r\n	}\r\n	public function add(){\r\n	    $data = $this->dataSet;\r\n		$data[''base_url''] = $this->config->base_url().''index.php/''.$this->dataSet[''module''].''/'';\r\n	    $data[''title'']= ''Add New Sample_t'';\r\n		$data[''subtitle'']= ''Enter Sample_t Information'';\r\n		$data[''message'']= ''New Sample_t has been created successfully!'';\r\n		$this->load->model($this->dataSet[''module''].''_model'');\r\n	    $this->load->view(''section/header.php'',$data);\r\n		$model = $this->dataSet[''model''];\r\n		$this->$model->add($data);\r\n		$this->load->view($this->dataSet[''module''].''/add-student.php'');\r\n		$this->load->view(''section/footer.php'');\r\n	}\r\n	public function edit(){ $args = func_get_args();\r\n	    if(count($args[0])==0){ show_404(''log_error'');}else{\r\n	    $data = $this->dataSet;\r\n		$data[''base_url''] = $this->config->base_url().''index.php/''.$this->dataSet[''module''].''/'';\r\n	    $data[''edit_id'']=$args[0];\r\n	    $data[''title'']= ''Edit Sample_t'';\r\n		$data[''subtitle'']= ''Update Sample_t Information'';\r\n		$data[''message'']= ''Sample_t has been updated successfully!'';\r\n		$this->load->model($this->dataSet[''module''].''_model'');\r\n	    $this->load->view(''section/header.php'',$data);\r\n		$model = $this->dataSet[''model''];\r\n		$this->$model->update($data);\r\n		$this->load->view($this->dataSet[''module''].''/edit-student.php'');\r\n		$this->load->view(''section/footer.php'');\r\n		}\r\n	}\r\n	public function setting(){\r\n	    $data = $this->dataSet; \r\n	    $args = func_get_args();\r\n		$data[''add_title''] = ''Add Sample_t Admission Field'';\r\n		$data[''edit_title''] = ''Edit Sample_t Admission Field'';\r\n	    $data[''base_url''] = $this->config->base_url().''index.php/''.$this->dataSet[''module''].''/'';\r\n	    $data[''title'']= ucfirst($this->dataSet[''module'']).'' Controls'';\r\n	    $this->load->view(''section/header.php'',$data);\r\n		$this->load->view($this->dataSet[''module''].''/controls/setting.php'');\r\n		$this->load->view(''section/footer.php'');\r\n	}\r\n	public function chain_table_fields(){\r\n	    $data = $this->dataSet; \r\n	    $args = func_get_args();\r\n	    $data[''base_url''] = $this->config->base_url().''index.php/''.$this->dataSet[''module''].''/'';\r\n		$this->load->view($this->dataSet[''module''].''/controls/chain_table_fields.php'');\r\n	}\r\n	public function control_type(){\r\n	    $data = $this->dataSet; \r\n	    $args = func_get_args();\r\n	    $data[''base_url''] = $this->config->base_url().''index.php/''.$this->dataSet[''module''].''/'';\r\n		$this->load->view($this->dataSet[''module''].''/controls/control_type.php'');\r\n	}\r\n	public function control_type1(){\r\n	    $data = $this->dataSet; \r\n	    $args = func_get_args();\r\n	    $data[''base_url''] = $this->config->base_url().''index.php/''.$this->dataSet[''module''].''/'';\r\n		$this->load->view($this->dataSet[''module''].''/controls/control_type1.php'');\r\n	}\r\n}\r\n\r\n/* End of file welcome.php */\r\n/* Location: ./application/controllers/welcome.php */', '<?php\r\nclass Sample_model extends CI_Model{\r\n	public function index($datas){ extract($datas);\r\n			if(isset($_POST[''delete_id''])){\r\n			  mysql_query("DELETE FROM $valueTable WHERE $unique_id=".$_POST[''delete_id'']);\r\n			  $_SESSION[''msg''] = success($delete_msg);\r\n			}\r\n			if(isset($_POST[''active_id''])){\r\n			  mysql_query("UPDATE $valueTable SET status=1 WHERE $unique_id=".$_POST[''active_id'']);\r\n			  $_SESSION[''msg''] = success($active_msg);\r\n			}\r\n			if(isset($_POST[''inactive_id''])){\r\n			  mysql_query("UPDATE $valueTable SET status=0 WHERE $unique_id=".$_POST[''inactive_id'']);\r\n			  $_SESSION[''msg''] = success($deactive_msg);\r\n			}\r\n	}\r\n	 public function add($datas){ extract($datas);\r\n		 	$msg='''';\r\n			$fields = $types = array();\r\n			$select = mysql_query("SELECT * FROM $fieldTable WHERE link_table=''".$valueTable."'' and status=1"); while($fet = mysql_fetch_object($select)){ $fields[] = $fet->field; $types[] = $fet->type;}\r\n			if(isset($_POST[''SaveStudent''])){ $fieldsVal=array();\r\n			   foreach($fields as $key=>$field){\r\n				   if($types[$key]==''file''){  \r\n					if($_FILES[$field][''name'']!=''''){\r\n					$file = rand(100,10).time().$_FILES[$field][''name''];\r\n					move_uploaded_file($_FILES[$field][''tmp_name''],''upload/''.$file);\r\n					$fieldsVal[] = "$field=''".mysql_real_escape_string($file)."''";\r\n					}\r\n				   }elseif($types[$key]==''radio''){  \r\n					$fieldsVal[] = "$field=''".implode('','',$_POST[$field])."''";\r\n					\r\n				   }elseif($types[$key]==''checkbox''){\r\n					$fieldsVal[] = "$field=''".implode('','',$_POST[$field])."''";\r\n					\r\n				   }else{\r\n					$fieldsVal[] = "$field=''".mysql_real_escape_string($_POST[$field])."''";\r\n				   }\r\n			   }\r\n			   mysql_query("INSERT INTO $valueTable set ".implode('','',$fieldsVal));\r\n			   $_SESSION[''msg''] = success($message);\r\n			   header("location:".$base_url);\r\n			} \r\n	 }\r\n	 public function update($datas){ extract($datas);\r\n		    $msg='''';\r\n			$fields = $types = array();\r\n			$select = mysql_query("SELECT * FROM $fieldTable WHERE link_table=''".$valueTable."'' and status=1"); while($fet = mysql_fetch_object($select)){ $fields[] = $fet->field; $types[] = $fet->type;}\r\n			if(isset($_POST[''UpdateStudent''])){ $fieldsVal=array();\r\n			   foreach($fields as $key=>$field){\r\n				   if($types[$key]==''file''){  \r\n					if($_FILES[$field][''name'']!=''''){\r\n					$file = rand(100,10).time().$_FILES[$field][''name''];\r\n					move_uploaded_file($_FILES[$field][''tmp_name''],''upload/''.$file);\r\n					$fieldsVal[] = "$field=''".mysql_real_escape_string($file)."''";\r\n					}else{\r\n					 $file = $_POST[''_''.$field];\r\n					 $fieldsVal[] = "$field=''".mysql_real_escape_string($file)."''";\r\n					}\r\n				   }elseif($types[$key]==''radio''){  \r\n					$fieldsVal[] = "$field=''".implode('','',$_POST[$field])."''";\r\n					\r\n				   }elseif($types[$key]==''checkbox''){\r\n					$fieldsVal[] = "$field=''".implode('','',$_POST[$field])."''";\r\n					\r\n				   }else{\r\n					$fieldsVal[] = "$field=''".mysql_real_escape_string($_POST[$field])."''";\r\n				   }\r\n			   }\r\n			   mysql_query("UPDATE $valueTable SET ".implode('','',$fieldsVal)." WHERE $unique_id=".$edit_id);\r\n			   $_SESSION[''msg''] = success($message);\r\n			   header("location:".$base_url);\r\n			}\r\n	 }\r\n}\r\n?>', 0);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_user`
--

CREATE TABLE `tbl_user` (
  `user_id` int(11) NOT NULL,
  `status` tinyint(4) NOT NULL,
  `username` text NOT NULL,
  `password` text NOT NULL,
  `age` text NOT NULL,
  `access_module` text NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_user`
--

INSERT INTO `tbl_user` (`user_id`, `status`, `username`, `password`, `age`, `access_module`) VALUES
(1, 1, 'sambath', 'sambath', '25', 'Employee Management,WagesType'),
(2, 0, 'bala', 'bala', '26', 'Employee Management,Employee Designation'),
(3, 0, 'anand', 'anand', '24', '');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_user_privilege`
--

CREATE TABLE `tbl_user_privilege` (
  `privilege_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `module_id` int(11) NOT NULL,
  `status` tinyint(4) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_visitors`
--

CREATE TABLE `tbl_visitors` (
  `visitor_id` int(11) NOT NULL,
  `status` tinyint(4) NOT NULL,
  `visitorid` text NOT NULL,
  `name` text NOT NULL,
  `id_proof_name` text NOT NULL,
  `address` text NOT NULL,
  `email` text NOT NULL,
  `phone` text NOT NULL,
  `coming_from` text NOT NULL,
  `purpose_of_visit` text NOT NULL,
  `to_whom_meet` text NOT NULL,
  `vihicle_no` text NOT NULL,
  `time_in` text NOT NULL,
  `time_out` text NOT NULL,
  `security_sign` text NOT NULL,
  `others` text NOT NULL,
  `photo` text NOT NULL,
  `thumb` text NOT NULL,
  `create_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_visitors`
--

INSERT INTO `tbl_visitors` (`visitor_id`, `status`, `visitorid`, `name`, `id_proof_name`, `address`, `email`, `phone`, `coming_from`, `purpose_of_visit`, `to_whom_meet`, `vihicle_no`, `time_in`, `time_out`, `security_sign`, `others`, `photo`, `thumb`, `create_date`) VALUES
(1, 1, '201', 'bala', 'voter id', 'chennai', '32deva@gmail.com', '933495849545', 'Andimadam', 'join', 'Correspondance', '32', '10:00', '5:00', 'bala', 'test', '', '', '2015-01-31 18:30:00'),
(4, 1, '2', 'karthikeyan', 'voter id', 'Hyderabad', 'karthick.ap@gmail.com', '8015368910', 'Bangalore', 'Admission', 'HM', 'AP56', '9:00AM', '6:PM', 'Ram', '', 'upload/original/5d17443bcc27e6774b0b796595449bfc.jpg', 'upload/thumbs/5d17443bcc27e6774b0b796595449bfc.jpg', '2015-02-06 03:41:02'),
(5, 0, '3', 'shilpa', 'drivinglicence', '', 'shilpask100@gmail.com', '984553163890', 'Nelmangala', 'enqiry', 'principal', 'KA-52 4441', '10.02AM', '11.03AM', 'shilpa', '', '', '', '2015-02-06 04:33:49'),
(6, 1, '123', 'name', 'firstname secondname', 'koramangala', 'firstname@gmail.com', '987654321', 'bangalore', 'enquiry', 'Rajan', '4567', '10.30', '', 'kumar', '', '', '', '2015-02-06 16:26:32'),
(7, 0, '4477', 'sundhar', 'pancnard', 'chennai', 'sundharmc@gmail.com', '8675834502', 'USA', 'client visit', 'surya', '447644', '8.am', '8 pm', 'bharat', 'bala', 'upload/original/b821f9dfe27a7a7d9b71ab3967d2c31d.jpg', 'upload/thumbs/b821f9dfe27a7a7d9b71ab3967d2c31d.jpg', '2015-02-08 17:48:08'),
(8, 1, '789', 'bbbb', '2020', 'koramangala', 'email@email.com', '8907896780', 'Pondy', 'Enquiry', 'Kumar', '7654 KA 01', '10:30', '', 'Mani', '', '', '', '2015-02-11 14:34:02'),
(9, 0, '001', 'Xerox', 'Passport', '#224/4,5th A main,16th Cross \nJ.P.Nagar 4th phase Bangalore', 'abpalanikarthik@gmail.com', '9994784068', 'Bangalore', 'Enquiry', 'Principal ', 'KA0345', '10:00AM', '12:30PM', 'Kumar', '', 'upload/original/a7010f9c3f8ffc165cafb90da49dccae.jpg', 'upload/thumbs/a7010f9c3f8ffc165cafb90da49dccae.jpg', '2015-02-16 16:40:23'),
(10, 0, '', 'ramya', 'voterid', 'nelmangala', 'ramya123@gmail.com', '9845531693', 'nelmangala', 'enquiry', 'principal', 'KA523125', '10:10am', '', 'ramya', '', '', '', '2015-02-20 04:40:26'),
(11, 0, '', 'ramya', 'voterid', 'nelmangala', 'ramya123@gmail.com', '9845531693', 'nelmangala', 'enquiry', 'principal', 'KA523125', '10:10am', '', 'ramya', '', '', '', '2015-02-20 04:41:43'),
(12, 0, '', '123', 'bre', 'koramangala', 'bre@gmail.com', '98765423', 'chennai', 'to meet kumar', 'kumar', '4534', '09:30', '', 'stalin', '', '', '', '2015-02-20 14:48:34'),
(13, 0, '', 'test1', 'test', '123 south street ', 'test11@gmail.com', '987867889', 'bangalore', 'enquiry', 'principal', 'KA523125', '10:10am', '', 'ramya', '123', '', '', '2015-02-25 14:59:52'),
(14, 0, '', 'test1', 'test', '123 south', 'test12@gmail.com', '987867889', 'bangalore', 'enquiry', 'principal', 'KA523125', '10:10am', '', 'test', '', '', '', '2015-03-04 16:46:04'),
(15, 0, '', 'karthee', 'PAN', '', 'karthee@', '9902084004', 'chennai', 'training', 'HR', 'TN89', '13:30', '', 'pop', '', '', '', '2015-03-24 08:02:46'),
(16, 0, '', 'srinivas', '123', '1923 south end c main 9th blk jayanagar east bangalore', 'srinivas.5189@gmail.com', '8026591098', 'chennai', 'enquiry', 'principal', 'KA523125', '22:46', '', 'ramya', ' visitor', 'upload/original/7cf99f99914e927d86b01838f9efdfbb.jpg', 'upload/thumbs/7cf99f99914e927d86b01838f9efdfbb.jpg', '2015-03-29 17:17:31'),
(17, 0, '', 'Ram', 'PAN', 'chennai', 'ravielanji@yahoo.com', '9990909012', 'Bangalore', 'Admission', 'HeadMaster', 'NIL', '19:07', '', 'x123', '', '', '', '2015-04-06 13:38:44'),
(18, 0, '', 'test1', 'test', '1923 sou', 'test117@gmail.com', '9878678899', 'bangalore', 'enquiry', 'principal', 'KA523125', '23:17', '', 'ramya', ' visitor', '', '', '2015-04-07 17:48:25');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_wages`
--

CREATE TABLE `tbl_wages` (
  `wage_id` bigint(20) NOT NULL,
  `last_modified_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `create_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `status` tinyint(4) NOT NULL DEFAULT '1',
  `wage_name` text NOT NULL,
  `wage_desc` text NOT NULL,
  `wage_item` text NOT NULL,
  `wage_time` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_wages`
--

INSERT INTO `tbl_wages` (`wage_id`, `last_modified_date`, `create_date`, `status`, `wage_name`, `wage_desc`, `wage_item`, `wage_time`) VALUES
(1, '2016-02-23 12:57:34', '2016-02-23 12:57:34', 1, 'test', 'Good', '4', '06 : 27 : PM'),
(2, '2016-02-24 08:33:24', '2016-02-24 08:16:47', 1, 'test', 'Good', '5', '01 : 46 : PM'),
(3, '2016-02-24 08:33:47', '2016-02-24 08:33:47', 1, 'demo', '', '', '02 : 03 : PM');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tbl_admin`
--
ALTER TABLE `tbl_admin`
  ADD PRIMARY KEY (`user_id`);

--
-- Indexes for table `tbl_fields`
--
ALTER TABLE `tbl_fields`
  ADD PRIMARY KEY (`field_id`);

--
-- Indexes for table `tbl_field_option`
--
ALTER TABLE `tbl_field_option`
  ADD PRIMARY KEY (`field_option_id`);

--
-- Indexes for table `tbl_modules`
--
ALTER TABLE `tbl_modules`
  ADD PRIMARY KEY (`module_id`);

--
-- Indexes for table `tbl_module_creator`
--
ALTER TABLE `tbl_module_creator`
  ADD PRIMARY KEY (`creator_id`);

--
-- Indexes for table `tbl_user`
--
ALTER TABLE `tbl_user`
  ADD PRIMARY KEY (`user_id`);

--
-- Indexes for table `tbl_user_privilege`
--
ALTER TABLE `tbl_user_privilege`
  ADD PRIMARY KEY (`privilege_id`);

--
-- Indexes for table `tbl_visitors`
--
ALTER TABLE `tbl_visitors`
  ADD PRIMARY KEY (`visitor_id`);

--
-- Indexes for table `tbl_wages`
--
ALTER TABLE `tbl_wages`
  ADD PRIMARY KEY (`wage_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `tbl_admin`
--
ALTER TABLE `tbl_admin`
  MODIFY `user_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `tbl_fields`
--
ALTER TABLE `tbl_fields`
  MODIFY `field_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=94;
--
-- AUTO_INCREMENT for table `tbl_field_option`
--
ALTER TABLE `tbl_field_option`
  MODIFY `field_option_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=36;
--
-- AUTO_INCREMENT for table `tbl_modules`
--
ALTER TABLE `tbl_modules`
  MODIFY `module_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=23;
--
-- AUTO_INCREMENT for table `tbl_module_creator`
--
ALTER TABLE `tbl_module_creator`
  MODIFY `creator_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `tbl_user`
--
ALTER TABLE `tbl_user`
  MODIFY `user_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `tbl_user_privilege`
--
ALTER TABLE `tbl_user_privilege`
  MODIFY `privilege_id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `tbl_visitors`
--
ALTER TABLE `tbl_visitors`
  MODIFY `visitor_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;
--
-- AUTO_INCREMENT for table `tbl_wages`
--
ALTER TABLE `tbl_wages`
  MODIFY `wage_id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
